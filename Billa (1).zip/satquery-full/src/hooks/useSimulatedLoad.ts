import { useEffect, useState } from 'react';
import { prefersReducedMotion } from '@/lib/utils';

/**
 * Brief local "loading" beat so secondary views show their skeleton state
 * instead of snapping in. There is no fetch behind it.
 */
export function useSimulatedLoad(ms = 420, deps: unknown[] = []): boolean {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const delay = prefersReducedMotion() ? 0 : ms;
    const timer = window.setTimeout(() => setLoading(false), delay);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return loading;
}
