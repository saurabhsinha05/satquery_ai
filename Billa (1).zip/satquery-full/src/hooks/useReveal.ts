import { useEffect, useRef } from 'react';
import { prefersReducedMotion } from '@/lib/utils';

/**
 * Scroll reveal that fails safe.
 *
 * The revealed state is the element's *natural* state — we only ever add a
 * `data-reveal="armed"` attribute to hide it, and remove it to show it. So if
 * the observer never fires, or transitions are unavailable, the content is
 * visible rather than stuck at opacity 0.
 */
export function useReveal<T extends HTMLElement = HTMLDivElement>() {
  const ref = useRef<T | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;

    const show = () => el.removeAttribute('data-reveal');

    if (prefersReducedMotion() || typeof IntersectionObserver === 'undefined') {
      show();
      return undefined;
    }

    // Already on screen at mount — no need to animate it in.
    if (el.getBoundingClientRect().top < window.innerHeight * 0.92) {
      show();
      return undefined;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            show();
            observer.disconnect();
          }
        }
      },
      { threshold: 0.06, rootMargin: '0px 0px -8% 0px' },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return ref;
}

/** True while the element is on screen — used to drive the workflow autoplay. */
export function useInView<T extends HTMLElement = HTMLDivElement>(
  onChange: (inView: boolean) => void,
) {
  const ref = useRef<T | null>(null);
  const handler = useRef(onChange);
  handler.current = onChange;

  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    if (typeof IntersectionObserver === 'undefined') {
      handler.current(true);
      return undefined;
    }
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => handler.current(entry.isIntersecting)),
      { threshold: 0.25 },
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return ref;
}
