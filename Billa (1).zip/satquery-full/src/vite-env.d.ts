/// <reference types="vite/client" />

/**
 * Browser-visible environment. Only `VITE_`-prefixed values exist here —
 * backend secrets (Copernicus, OpenAI, LangSmith, Supabase service role) must
 * never be added to this interface.
 */
interface ImportMetaEnv {
  readonly VITE_API_BASE_URL?: string;
  readonly VITE_MAPBOX_ACCESS_TOKEN?: string;
  readonly VITE_SUPABASE_URL?: string;
  readonly VITE_SUPABASE_PUBLISHABLE_KEY?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
