import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useReducer,
  useRef,
  type ReactNode,
} from 'react';
import {
  buildPlan,
  buildResult,
  getScenarioById,
  isNewAnalysisQuery,
  resolveFollowUp,
  resolveScenario,
} from '@/lib/demoAgent';
import type {
  AgentStep,
  ChatAttachment,
  ChatMessage,
  HistoryEntry,
  SavedResultEntry,
  WorkspaceView,
} from '@/lib/types';
import { formatClock, formatDay, prefersReducedMotion, uid } from '@/lib/utils';
import {
  initialState,
  workspaceReducer,
  type Action,
  type Toast,
  type WorkspaceState,
} from './workspaceReducer';
import {
  ApiError,
  getActivity,
  getSavedAnalyses,
  probeBackend,
  runAgent,
  saveAnalysis as saveAnalysisApi,
  streamAgent,
} from '@/lib/api';
import { liveStepsFromEvents } from '@/lib/liveSteps';
import type { AgentEvent, AgentResponse } from '@/lib/contract';

interface WorkspaceContextValue {
  state: WorkspaceState;
  dispatch: React.Dispatch<Action>;
  submitQuery: (text: string) => void;
  resetWorkspace: () => void;
  goToView: (view: WorkspaceView) => void;
  restoreHistory: (id: string) => void;
  openSavedResult: (id: string) => void;
  saveCurrentResult: () => void;
  attachFile: (attachment: ChatAttachment | null) => void;
  confirmDrawnArea: (label: string) => void;
  showToast: (text: string, tone?: Toast['tone']) => void;
  isBusy: boolean;
  /** True when a real backend answered the capability probe. */
  isLive: boolean;
  refreshActivity: () => Promise<void>;
  refreshSaved: () => Promise<void>;
}

const WorkspaceContext = createContext<WorkspaceContextValue | null>(null);

/** Index of the plan step that triggers the result panel reveal. */
const REVEAL_AT_STEP = 4;

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(workspaceReducer, initialState);
  const runToken = useRef(0);
  const timers = useRef<number[]>([]);
  const toastTimer = useRef<number | undefined>(undefined);
  const cancelStreamRef = useRef<(() => void) | null>(null);

  const clearTimers = useCallback(() => {
    timers.current.forEach((t) => window.clearTimeout(t));
    timers.current = [];
  }, []);

  useEffect(
    () => () => {
      clearTimers();
      if (toastTimer.current) window.clearTimeout(toastTimer.current);
    },
    [clearTimers],
  );

  // Closed on unmount so a navigated-away run does not keep a socket open.
  useEffect(
    () => () => {
      cancelStreamRef.current?.();
    },
    [],
  );

  const wait = useCallback((ms: number) => {
    return new Promise<void>((resolve) => {
      const id = window.setTimeout(resolve, ms);
      timers.current.push(id);
    });
  }, []);

  const showToast = useCallback((text: string, tone: Toast['tone'] = 'info') => {
    const toast: Toast = { id: uid('toast'), text, tone };
    dispatch({ type: 'toast', toast });
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => dispatch({ type: 'toast', toast: null }), 3200);
  }, []);

  /* ── The simulated agent run ───────────────────────────────────────────── */

  const runAnalysis = useCallback(
    async (text: string) => {
      const token = (runToken.current += 1);
      const alive = () => runToken.current === token;
      const reduced = prefersReducedMotion();
      const scale = reduced ? 0.15 : 1;

      const scenario = resolveScenario(text);
      const plan: AgentStep[] = buildPlan(scenario);
      const planMessageId = uid('msg');

      dispatch({ type: 'set-status', status: 'thinking' });

      // Small beat before the agent replies — reads as consideration.
      await wait(420 * scale);
      if (!alive()) return;

      const planMessage: ChatMessage = {
        id: planMessageId,
        role: 'agent',
        text: scenario.ack,
        time: formatClock(),
        variant: 'plan',
        planTitle: scenario.planTitle,
        steps: plan,
      };
      dispatch({ type: 'add-message', message: planMessage });
      dispatch({ type: 'set-status', status: 'working' });

      const result = buildResult(scenario);
      dispatch({ type: 'set-result', result, scenarioId: scenario.id });

      for (let i = 0; i < plan.length; i += 1) {
        if (!alive()) return;
        dispatch({ type: 'set-steps', id: planMessageId, stepIndex: i, status: 'active' });

        if (i === REVEAL_AT_STEP) {
          dispatch({ type: 'reveal-result' });
        }

        await wait(plan[i].duration * scale);
        if (!alive()) return;
        dispatch({ type: 'set-steps', id: planMessageId, stepIndex: i, status: 'complete' });
        await wait(90 * scale);
      }

      if (!alive()) return;

      dispatch({
        type: 'add-message',
        message: {
          id: uid('msg'),
          role: 'agent',
          text: scenario.handoff,
          time: formatClock(),
          variant: 'result',
          resultId: result.id,
        },
      });
      dispatch({ type: 'set-status', status: 'complete' });
      dispatch({ type: 'set-suggestions', suggestions: scenario.suggestions });

      const historyEntry: HistoryEntry = {
        id: uid('hist'),
        title: scenario.shortLabel,
        query: text,
        date: formatDay(new Date()),
        kind: scenario.kind,
        scenarioId: scenario.id,
        messageCount: 3,
      };
      dispatch({ type: 'add-history', entry: historyEntry });
    },
    [wait],
  );

  const runFollowUp = useCallback(
    async (text: string) => {
      if (!state.result) return;
      const token = (runToken.current += 1);
      const alive = () => runToken.current === token;
      const reduced = prefersReducedMotion();

      dispatch({ type: 'set-status', status: 'thinking' });
      const pendingId = uid('msg');
      dispatch({
        type: 'add-message',
        message: {
          id: pendingId,
          role: 'agent',
          text: '',
          time: formatClock(),
          variant: 'text',
          pending: true,
        },
      });

      await wait(reduced ? 120 : 700);
      if (!alive()) return;

      const response = resolveFollowUp(text, state.result);
      dispatch({
        type: 'patch-message',
        id: pendingId,
        patch: { text: response.reply, pending: false, time: formatClock() },
      });
      if (response.action) {
        dispatch({ type: 'map-action', action: response.action });
      }
      dispatch({ type: 'set-suggestions', suggestions: response.chips ?? [] });
      dispatch({ type: 'set-status', status: 'complete' });
    },
    [state.result, wait],
  );

  /* ── Backend detection ─────────────────────────────────────────────────── */

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const capabilities = await probeBackend();
      if (cancelled) return;
      if (capabilities) {
        dispatch({ type: 'backend-mode', mode: 'live', capabilities });
      } else {
        dispatch({
          type: 'backend-mode',
          mode: 'demo',
          error:
            'No SatQuery backend is reachable, so the workspace is running its local demo engine. Start the backend and set VITE_API_BASE_URL to connect to real Copernicus data.',
        });
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const isLive = state.backend.mode === 'live';

  const refreshActivity = useCallback(async () => {
    if (state.backend.mode !== 'live') return;
    try {
      const { activity, persistence } = await getActivity();
      dispatch({ type: 'backend-activity', activity, persistence });
    } catch {
      /* the panel shows its empty state rather than stale content */
    }
  }, [state.backend.mode]);

  const refreshSaved = useCallback(async () => {
    if (state.backend.mode !== 'live') return;
    try {
      const { saved, persistence } = await getSavedAnalyses();
      dispatch({ type: 'backend-saved', saved, persistence });
    } catch {
      /* same */
    }
  }, [state.backend.mode]);

  useEffect(() => {
    if (state.backend.mode !== 'live') return;
    void refreshActivity();
    void refreshSaved();
  }, [state.backend.mode, refreshActivity, refreshSaved]);

  /* ── The real agent run ────────────────────────────────────────────────── */

  const runLive = useCallback(
    async (text: string) => {
      const planMessageId = uid('msg');
      const events: AgentEvent[] = [];

      dispatch({ type: 'set-status', status: 'thinking' });
      dispatch({
        type: 'add-message',
        message: {
          id: planMessageId,
          role: 'agent',
          text: 'Working on it.',
          time: formatClock(),
          variant: 'plan',
          planTitle: 'Agent progress',
          steps: [],
        },
      });

      const applyEvents = (finished: boolean) => {
        dispatch({
          type: 'patch-message',
          id: planMessageId,
          patch: { steps: liveStepsFromEvents(events, finished) },
        });
      };

      const finish = (response: AgentResponse) => {
        events.push({
          event: 'agent.completed',
          runId: response.runId,
          at: new Date().toISOString(),
          message:
            response.status === 'failed'
              ? (response.errors[0] ?? 'The run failed.')
              : 'Analysis complete.',
        });
        applyEvents(true);
        dispatch({ type: 'backend-response', response });
        dispatch({
          type: 'add-message',
          message: {
            id: uid('msg'),
            role: 'agent',
            text: response.answer,
            time: formatClock(),
            variant: 'result',
            resultId: response.runId,
          },
        });
        dispatch({
          type: 'set-status',
          status: response.status === 'failed' ? 'error' : 'complete',
        });
        if (response.status === 'failed') dispatch({ type: 'set-error', on: true });
        void refreshActivity();
      };

      try {
        const accepted = await runAgent({ query: text });
        dispatch({ type: 'backend-run-started', runId: accepted.runId });
        dispatch({ type: 'set-status', status: 'working' });

        cancelStreamRef.current?.();
        cancelStreamRef.current = streamAgent(accepted.runId, {
          onEvent: (event) => {
            events.push(event);
            dispatch({ type: 'backend-event', event });
            applyEvents(false);
          },
          onComplete: finish,
          onError: (message) => {
            dispatch({
              type: 'add-message',
              message: {
                id: uid('msg'),
                role: 'agent',
                text: message,
                time: formatClock(),
                variant: 'text',
              },
            });
            dispatch({ type: 'set-status', status: 'error' });
            dispatch({ type: 'set-error', on: true });
          },
        });
      } catch (e) {
        const message =
          e instanceof ApiError
            ? e.message
            : 'The analysis could not be started. Check that the backend is running.';
        dispatch({
          type: 'patch-message',
          id: planMessageId,
          patch: { text: message, variant: 'text', steps: undefined },
        });
        dispatch({ type: 'set-status', status: 'error' });
        dispatch({ type: 'set-error', on: true });
      }
    },
    [refreshActivity],
  );

  const submitQuery = useCallback(
    (raw: string) => {
      const text = raw.trim();
      if (!text) return;
      if (state.agentStatus === 'thinking' || state.agentStatus === 'working') return;

      clearTimers();
      dispatch({ type: 'set-view', view: 'workspace' });
      dispatch({ type: 'set-error', on: false });
      dispatch({ type: 'set-suggestions', suggestions: [] });

      const userMessage: ChatMessage = {
        id: uid('msg'),
        role: 'user',
        text,
        time: formatClock(),
        attachment: state.attachment ?? undefined,
        aoiLabel: state.aoiLabel ?? undefined,
      };
      dispatch({ type: 'add-message', message: userMessage });
      dispatch({ type: 'set-query', query: text });
      dispatch({ type: 'set-attachment', attachment: null });

      // A reachable backend is always the source of truth. The local demo
      // engine only runs when no backend answered the capability probe.
      if (state.backend.mode === 'live') {
        void runLive(text);
        return;
      }

      const startsNew = !state.result || isNewAnalysisQuery(text);
      if (startsNew) {
        void runAnalysis(text);
      } else {
        void runFollowUp(text);
      }
    },
    [
      clearTimers,
      runAnalysis,
      runFollowUp,
      runLive,
      state.agentStatus,
      state.aoiLabel,
      state.attachment,
      state.backend.mode,
      state.result,
    ],
  );

  const resetWorkspace = useCallback(() => {
    runToken.current += 1;
    clearTimers();
    dispatch({ type: 'reset-workspace' });
  }, [clearTimers]);

  const goToView = useCallback((view: WorkspaceView) => {
    dispatch({ type: 'set-view', view });
  }, []);

  /** Rebuild a finished conversation instantly, no animation. */
  const restoreScenario = useCallback(
    (scenarioId: string, query: string) => {
      runToken.current += 1;
      clearTimers();
      const scenario = getScenarioById(scenarioId);
      const result = buildResult(scenario);
      const steps = buildPlan(scenario).map((s) => ({ ...s, status: 'complete' as const }));

      const messages: ChatMessage[] = [
        { id: uid('msg'), role: 'user', text: query, time: '10:21 AM' },
        {
          id: uid('msg'),
          role: 'agent',
          text: scenario.ack,
          time: '10:21 AM',
          variant: 'plan',
          planTitle: scenario.planTitle,
          steps,
        },
        {
          id: uid('msg'),
          role: 'agent',
          text: scenario.handoff,
          time: '10:25 AM',
          variant: 'result',
          resultId: result.id,
        },
      ];

      dispatch({
        type: 'restore-session',
        messages,
        result,
        scenarioId: scenario.id,
        suggestions: scenario.suggestions,
      });
    },
    [clearTimers],
  );

  const restoreHistory = useCallback(
    (id: string) => {
      const entry = state.history.find((h) => h.id === id);
      if (!entry) return;
      restoreScenario(entry.scenarioId, entry.query);
      showToast(`Restored "${entry.title}"`, 'success');
    },
    [restoreScenario, showToast, state.history],
  );

  const openSavedResult = useCallback(
    (id: string) => {
      const entry = state.savedResults.find((s) => s.id === id);
      if (!entry) return;
      const scenario = getScenarioById(entry.scenarioId);
      restoreScenario(entry.scenarioId, scenario.query);
      showToast(`Opened "${entry.title}"`, 'success');
    },
    [restoreScenario, showToast, state.savedResults],
  );

  const saveCurrentResult = useCallback(() => {
    const liveRunId = state.backend.response?.runId;
    if (state.backend.mode === 'live' && liveRunId) {
      void (async () => {
        try {
          await saveAnalysisApi(liveRunId);
          showToast('Saved to Saved Results', 'success');
          await refreshSaved();
        } catch (e) {
          showToast(
            e instanceof ApiError ? e.message : 'Could not save this analysis.',
            'warn',
          );
        }
      })();
      return;
    }

    if (!state.result || !state.activeScenarioId) return;
    const scenario = getScenarioById(state.activeScenarioId);
    const entry: SavedResultEntry = {
      id: uid('saved'),
      title: state.result.shortLabel,
      date: formatDay(new Date()),
      description: state.result.insight,
      kind: state.result.kind,
      scenarioId: scenario.id,
      tag: state.result.metadata.find((m) => m.label === 'Primary Index')?.value ?? 'Demo',
    };
    dispatch({ type: 'save-result', entry });
    showToast('Saved to Saved Results', 'success');
  }, [
    refreshSaved,
    showToast,
    state.activeScenarioId,
    state.backend.mode,
    state.backend.response?.runId,
    state.result,
  ]);

  const attachFile = useCallback(
    (attachment: ChatAttachment | null) => {
      dispatch({ type: 'set-attachment', attachment });
      if (attachment) showToast(`${attachment.name} attached to your next question`, 'success');
    },
    [showToast],
  );

  const confirmDrawnArea = useCallback(
    (label: string) => {
      dispatch({ type: 'set-aoi-label', label });
      dispatch({ type: 'set-draw-mode', on: false });
      showToast('Area selected — it will be used for your next question', 'success');
    },
    [showToast],
  );

  const isBusy = state.agentStatus === 'thinking' || state.agentStatus === 'working';

  const value = useMemo<WorkspaceContextValue>(
    () => ({
      state,
      dispatch,
      submitQuery,
      resetWorkspace,
      goToView,
      restoreHistory,
      openSavedResult,
      saveCurrentResult,
      attachFile,
      confirmDrawnArea,
      showToast,
      isBusy,
      isLive,
      refreshActivity,
      refreshSaved,
    }),
    [
      isLive,
      refreshActivity,
      refreshSaved,
      attachFile,
      confirmDrawnArea,
      goToView,
      isBusy,
      openSavedResult,
      resetWorkspace,
      restoreHistory,
      saveCurrentResult,
      showToast,
      state,
      submitQuery,
    ],
  );

  return <WorkspaceContext.Provider value={value}>{children}</WorkspaceContext.Provider>;
}

export function useWorkspace(): WorkspaceContextValue {
  const ctx = useContext(WorkspaceContext);
  if (!ctx) throw new Error('useWorkspace must be used inside <WorkspaceProvider>');
  return ctx;
}
