import type {
  AgentStatus,
  AlertEntry,
  AnalysisResult,
  AoiEntry,
  ChatAttachment,
  ChatMessage,
  HistoryEntry,
  MapAction,
  MapState,
  SavedResultEntry,
  WorkspaceView,
} from '@/lib/types';
import { ALERTS, AOIS, HISTORY, SAVED_RESULTS } from '@/lib/demoData';
import type {
  ActivityEvent as BackendActivityEvent,
  AgentEvent,
  AgentResponse,
  BackendCapabilities,
  SavedAnalysis,
} from '@/lib/contract';

export const INITIAL_MAP_STATE: MapState = {
  zoom: 1,
  offsetX: 0,
  offsetY: 0,
  highOnly: false,
  focus: 'none',
  baselineYear: null,
};

export interface Toast {
  id: string;
  text: string;
  tone: 'info' | 'success' | 'warn';
}

/**
 * How the workspace is being driven.
 *
 * `checking` while we probe for a backend, `live` when one answered, `demo`
 * when none did. In `live` mode the backend response is the only source of
 * truth — no demo content is rendered alongside it.
 */
export type BackendMode = 'checking' | 'live' | 'demo';

export interface BackendState {
  mode: BackendMode;
  capabilities: BackendCapabilities | null;
  /** Reason the backend is unreachable, shown verbatim to the user. */
  error: string | null;
  runId: string | null;
  /** Live agent events, newest last. */
  events: AgentEvent[];
  response: AgentResponse | null;
  activity: BackendActivityEvent[];
  saved: SavedAnalysis[];
  persistence: boolean;
}

export const initialBackendState: BackendState = {
  mode: 'checking',
  capabilities: null,
  error: null,
  runId: null,
  events: [],
  response: null,
  activity: [],
  saved: [],
  persistence: false,
};

export interface WorkspaceState {
  backend: BackendState;
  view: WorkspaceView;
  messages: ChatMessage[];
  currentQuery: string;
  agentStatus: AgentStatus;
  result: AnalysisResult | null;
  resultVisible: boolean;
  mapState: MapState;
  activeScenarioId: string | null;
  suggestions: string[];
  drawMode: boolean;
  aoiLabel: string | null;
  attachment: ChatAttachment | null;
  demoMode: boolean;
  history: HistoryEntry[];
  savedResults: SavedResultEntry[];
  alerts: AlertEntry[];
  aois: AoiEntry[];
  toast: Toast | null;
  fullscreen: boolean;
  reportOpen: boolean;
  examplesOpen: boolean;
  /** Mobile: which pane the user is looking at. */
  mobilePane: 'chat' | 'result';
  errored: boolean;
}

export const initialState: WorkspaceState = {
  backend: initialBackendState,
  view: 'workspace',
  messages: [],
  currentQuery: '',
  agentStatus: 'idle',
  result: null,
  resultVisible: false,
  mapState: INITIAL_MAP_STATE,
  activeScenarioId: null,
  suggestions: [],
  drawMode: false,
  aoiLabel: null,
  attachment: null,
  demoMode: false,
  history: HISTORY,
  savedResults: SAVED_RESULTS,
  alerts: ALERTS,
  aois: AOIS,
  toast: null,
  fullscreen: false,
  reportOpen: false,
  examplesOpen: false,
  mobilePane: 'chat',
  errored: false,
};

export type Action =
  | { type: 'backend-mode'; mode: BackendMode; capabilities?: BackendCapabilities | null; error?: string | null }
  | { type: 'backend-run-started'; runId: string }
  | { type: 'backend-event'; event: AgentEvent }
  | { type: 'backend-response'; response: AgentResponse }
  | { type: 'backend-activity'; activity: BackendActivityEvent[]; persistence: boolean }
  | { type: 'backend-saved'; saved: SavedAnalysis[]; persistence: boolean }
  | { type: 'backend-clear-run' }
  | { type: 'set-view'; view: WorkspaceView }
  | { type: 'set-query'; query: string }
  | { type: 'add-message'; message: ChatMessage }
  | { type: 'patch-message'; id: string; patch: Partial<ChatMessage> }
  | { type: 'set-steps'; id: string; stepIndex: number; status: 'active' | 'complete' }
  | { type: 'set-status'; status: AgentStatus }
  | { type: 'set-result'; result: AnalysisResult | null; scenarioId: string | null }
  | { type: 'reveal-result' }
  | { type: 'set-suggestions'; suggestions: string[] }
  | { type: 'map-action'; action: MapAction }
  | { type: 'set-map'; patch: Partial<MapState> }
  | { type: 'toggle-layer'; layerId: string; visible?: boolean }
  | { type: 'set-draw-mode'; on: boolean }
  | { type: 'set-aoi-label'; label: string | null }
  | { type: 'set-attachment'; attachment: ChatAttachment | null }
  | { type: 'set-demo-mode'; on: boolean }
  | { type: 'reset-workspace' }
  | { type: 'restore-session'; messages: ChatMessage[]; result: AnalysisResult; scenarioId: string; suggestions: string[] }
  | { type: 'save-result'; entry: SavedResultEntry }
  | { type: 'remove-saved'; id: string }
  | { type: 'add-history'; entry: HistoryEntry }
  | { type: 'clear-history' }
  | { type: 'read-alert'; id: string }
  | { type: 'read-all-alerts' }
  | { type: 'add-aoi'; entry: AoiEntry }
  | { type: 'remove-aoi'; id: string }
  | { type: 'toast'; toast: Toast | null }
  | { type: 'set-fullscreen'; on: boolean }
  | { type: 'set-report'; on: boolean }
  | { type: 'set-examples'; on: boolean }
  | { type: 'set-mobile-pane'; pane: 'chat' | 'result' }
  | { type: 'set-error'; on: boolean };

const FOCUS_ZOOM = 2.4;

export function workspaceReducer(state: WorkspaceState, action: Action): WorkspaceState {
  switch (action.type) {
    case 'backend-mode':
      return {
        ...state,
        backend: {
          ...state.backend,
          mode: action.mode,
          capabilities: action.capabilities ?? state.backend.capabilities,
          error: action.error ?? null,
        },
      };

    case 'backend-run-started':
      return {
        ...state,
        backend: { ...state.backend, runId: action.runId, events: [], response: null },
      };

    case 'backend-event':
      return {
        ...state,
        backend: { ...state.backend, events: [...state.backend.events, action.event] },
      };

    case 'backend-response':
      return {
        ...state,
        backend: { ...state.backend, response: action.response },
        resultVisible: Boolean(action.response.map || action.response.analysis),
      };

    case 'backend-activity':
      return {
        ...state,
        backend: {
          ...state.backend,
          activity: action.activity,
          persistence: action.persistence,
        },
      };

    case 'backend-saved':
      return {
        ...state,
        backend: { ...state.backend, saved: action.saved, persistence: action.persistence },
      };

    case 'backend-clear-run':
      return {
        ...state,
        backend: { ...state.backend, runId: null, events: [], response: null },
      };

    case 'set-view':
      return { ...state, view: action.view };

    case 'set-query':
      return { ...state, currentQuery: action.query };

    case 'add-message':
      return { ...state, messages: [...state.messages, action.message] };

    case 'patch-message':
      return {
        ...state,
        messages: state.messages.map((m) => (m.id === action.id ? { ...m, ...action.patch } : m)),
      };

    case 'set-steps':
      return {
        ...state,
        messages: state.messages.map((m) => {
          if (m.id !== action.id || !m.steps) return m;
          return {
            ...m,
            steps: m.steps.map((step, index) =>
              index === action.stepIndex ? { ...step, status: action.status } : step,
            ),
          };
        }),
      };

    case 'set-status':
      return { ...state, agentStatus: action.status };

    case 'set-result':
      return {
        ...state,
        result: action.result,
        activeScenarioId: action.scenarioId,
        mapState: INITIAL_MAP_STATE,
      };

    case 'reveal-result':
      return { ...state, resultVisible: true };

    case 'set-suggestions':
      return { ...state, suggestions: action.suggestions };

    case 'set-map':
      return { ...state, mapState: { ...state.mapState, ...action.patch } };

    case 'map-action': {
      const a = action.action;
      if (a.type === 'high-only') {
        return { ...state, mapState: { ...state.mapState, highOnly: a.on } };
      }
      if (a.type === 'focus') {
        return {
          ...state,
          mapState: { ...state.mapState, focus: a.region, zoom: FOCUS_ZOOM },
        };
      }
      if (a.type === 'baseline') {
        return { ...state, mapState: { ...state.mapState, baselineYear: a.year } };
      }
      if (a.type === 'reset') {
        return { ...state, mapState: INITIAL_MAP_STATE };
      }
      if (a.type === 'toggle-layer' && state.result) {
        return {
          ...state,
          result: {
            ...state.result,
            layers: state.result.layers.map((l) =>
              l.id === a.layerId ? { ...l, visible: a.visible } : l,
            ),
          },
        };
      }
      return state;
    }

    case 'toggle-layer': {
      if (!state.result) return state;
      return {
        ...state,
        result: {
          ...state.result,
          layers: state.result.layers.map((l) =>
            l.id === action.layerId ? { ...l, visible: action.visible ?? !l.visible } : l,
          ),
        },
      };
    }

    case 'set-draw-mode':
      return { ...state, drawMode: action.on };

    case 'set-aoi-label':
      return { ...state, aoiLabel: action.label };

    case 'set-attachment':
      return { ...state, attachment: action.attachment };

    case 'set-demo-mode':
      return { ...state, demoMode: action.on };

    case 'reset-workspace':
      return {
        ...state,
        backend: { ...state.backend, runId: null, events: [], response: null },
        view: 'workspace',
        messages: [],
        currentQuery: '',
        agentStatus: 'idle',
        result: null,
        resultVisible: false,
        mapState: INITIAL_MAP_STATE,
        activeScenarioId: null,
        suggestions: [],
        drawMode: false,
        aoiLabel: null,
        attachment: null,
        fullscreen: false,
        reportOpen: false,
        mobilePane: 'chat',
        errored: false,
      };

    case 'restore-session':
      return {
        ...state,
        view: 'workspace',
        messages: action.messages,
        result: action.result,
        activeScenarioId: action.scenarioId,
        resultVisible: true,
        agentStatus: 'complete',
        mapState: INITIAL_MAP_STATE,
        suggestions: action.suggestions,
        mobilePane: 'chat',
        errored: false,
      };

    case 'save-result':
      if (state.savedResults.some((s) => s.id === action.entry.id)) return state;
      return { ...state, savedResults: [action.entry, ...state.savedResults] };

    case 'remove-saved':
      return { ...state, savedResults: state.savedResults.filter((s) => s.id !== action.id) };

    case 'add-history':
      return { ...state, history: [action.entry, ...state.history] };

    case 'clear-history':
      return { ...state, history: [] };

    case 'read-alert':
      return {
        ...state,
        alerts: state.alerts.map((a) => (a.id === action.id ? { ...a, unread: false } : a)),
      };

    case 'read-all-alerts':
      return { ...state, alerts: state.alerts.map((a) => ({ ...a, unread: false })) };

    case 'add-aoi':
      return { ...state, aois: [action.entry, ...state.aois] };

    case 'remove-aoi':
      return { ...state, aois: state.aois.filter((a) => a.id !== action.id) };

    case 'toast':
      return { ...state, toast: action.toast };

    case 'set-fullscreen':
      return { ...state, fullscreen: action.on };

    case 'set-report':
      return { ...state, reportOpen: action.on };

    case 'set-examples':
      return { ...state, examplesOpen: action.on };

    case 'set-mobile-pane':
      return { ...state, mobilePane: action.pane };

    case 'set-error':
      return { ...state, errored: action.on, agentStatus: action.on ? 'error' : 'idle' };

    default:
      return state;
  }
}
