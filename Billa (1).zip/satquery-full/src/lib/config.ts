/**
 * Frontend configuration.
 *
 * Only `VITE_`-prefixed variables exist in the browser bundle. The Copernicus
 * secret, the OpenAI key, the LangSmith key and the Supabase service-role key
 * are backend-only and must never appear here — if you find yourself wanting
 * one of them in this file, the call belongs on the backend instead.
 */

function readEnv(key: string): string {
  const value = (import.meta.env as Record<string, string | undefined>)[key];
  return typeof value === 'string' ? value.trim() : '';
}

/** Base URL of the agent backend. Empty means "same origin", via the dev proxy. */
export const API_BASE_URL = readEnv('VITE_API_BASE_URL').replace(/\/$/, '');

export const MAPBOX_TOKEN = readEnv('VITE_MAPBOX_ACCESS_TOKEN');

export const SUPABASE_URL = readEnv('VITE_SUPABASE_URL');
export const SUPABASE_PUBLISHABLE_KEY = readEnv('VITE_SUPABASE_PUBLISHABLE_KEY');

export const hasMapbox = (): boolean => MAPBOX_TOKEN.length > 0;
export const hasSupabaseClient = (): boolean =>
  SUPABASE_URL.length > 0 && SUPABASE_PUBLISHABLE_KEY.length > 0;

/** Absolute URL for a backend path, honouring VITE_API_BASE_URL. */
export function apiUrl(path: string): string {
  const clean = path.startsWith('/') ? path : `/${path}`;
  return `${API_BASE_URL}${clean}`;
}

const SESSION_KEY = 'satquery.sessionId';

/**
 * Stable per-browser session id. It scopes activity and history for signed-out
 * users, and lets a follow-up question resolve against the previous turn.
 */
export function sessionId(): string {
  try {
    const existing = window.localStorage.getItem(SESSION_KEY);
    if (existing) return existing;
    const fresh =
      typeof crypto !== 'undefined' && 'randomUUID' in crypto
        ? crypto.randomUUID()
        : `s_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    window.localStorage.setItem(SESSION_KEY, fresh);
    return fresh;
  } catch {
    // Private mode or blocked storage — a per-tab id is still useful.
    return `s_${Math.random().toString(36).slice(2)}`;
  }
}
