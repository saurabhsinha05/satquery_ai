import { API_BASE_URL, apiUrl, sessionId } from './config';
import { accessToken } from './supabaseClient';
import type {
  ActivityEvent,
  AgentEvent,
  AgentResponse,
  BackendCapabilities,
  SavedAnalysis,
} from './contract';

/**
 * The single API abstraction.
 *
 * Every network call the product makes goes through this module — components
 * never call `fetch` directly. That keeps auth headers, session scoping and
 * error shaping in one place, and makes the backend swappable.
 */

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code: string,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

async function headers(json = true): Promise<Record<string, string>> {
  const token = await accessToken();
  return {
    ...(json ? { 'Content-Type': 'application/json' } : {}),
    'X-SatQuery-Session': sessionId(),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(apiUrl(path), {
      ...init,
      headers: { ...(await headers(init.method !== 'GET' && init.body !== undefined)), ...init.headers },
    });
  } catch {
    throw new ApiError(
      'Could not reach the SatQuery backend. Check that it is running and that VITE_API_BASE_URL points at it.',
      0,
      'network_error',
    );
  }

  if (!res.ok) {
    let message = `Request failed with ${res.status}.`;
    let code = 'request_failed';
    try {
      const body = (await res.json()) as { error?: { message?: string; code?: string } };
      if (body.error?.message) message = body.error.message;
      if (body.error?.code) code = body.error.code;
    } catch {
      /* keep the generic message */
    }
    throw new ApiError(message, res.status, code);
  }

  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

/* ─────────────────────────────── Capabilities ────────────────────────────── */

export interface CapabilitiesResponse extends BackendCapabilities {
  analysisMethods: string[];
}

export function getCapabilities(): Promise<CapabilitiesResponse> {
  return request<CapabilitiesResponse>('/api/capabilities');
}

/**
 * Is a backend reachable at all? Used once at workspace mount to decide
 * between the live product and the offline demo engine.
 */
export async function probeBackend(): Promise<CapabilitiesResponse | null> {
  try {
    return await getCapabilities();
  } catch {
    return null;
  }
}

/* ────────────────────────────────── Agent ────────────────────────────────── */

export interface RunAcceptedResponse {
  runId: string;
  sessionId: string;
  status: 'running';
  streamUrl: string;
  capabilities: BackendCapabilities;
}

export function runAgent(params: {
  query: string;
  bbox?: [number, number, number, number];
}): Promise<RunAcceptedResponse> {
  return request<RunAcceptedResponse>('/api/agent/run', {
    method: 'POST',
    body: JSON.stringify({
      query: params.query,
      sessionId: sessionId(),
      ...(params.bbox ? { bbox: params.bbox } : {}),
    }),
  });
}

export interface StreamHandlers {
  onEvent: (event: AgentEvent) => void;
  onComplete: (response: AgentResponse) => void;
  onError: (message: string) => void;
}

/**
 * Subscribes to a run's Server-Sent Events.
 *
 * EventSource cannot carry an Authorization header, and the stream endpoint is
 * addressed by an unguessable run id issued to this caller, so the stream is
 * opened unauthenticated by design. Returns a function that closes it.
 */
export function streamAgent(runId: string, handlers: StreamHandlers): () => void {
  const url = `${API_BASE_URL}/api/agent/stream/${encodeURIComponent(runId)}`;
  let source: EventSource | null = null;
  let closed = false;

  try {
    source = new EventSource(url);
  } catch {
    handlers.onError('This browser could not open the agent event stream.');
    return () => undefined;
  }

  source.onmessage = (message) => {
    if (closed) return;
    try {
      const event = JSON.parse(message.data) as AgentEvent;
      handlers.onEvent(event);
      if (event.event === 'agent.completed' && event.data) {
        handlers.onComplete(event.data as AgentResponse);
      }
      if (event.event === 'agent.error') {
        handlers.onError(event.message);
      }
    } catch {
      /* ignore a malformed frame rather than tearing the stream down */
    }
  };

  source.onerror = () => {
    if (closed) return;
    // The browser retries automatically; a closed stream after completion is normal.
    if (source?.readyState === EventSource.CLOSED) {
      closed = true;
      source.close();
    }
  };

  return () => {
    closed = true;
    source?.close();
  };
}

export interface RunSnapshot {
  runId: string;
  status: AgentResponse['status'];
  events: AgentEvent[];
  response: AgentResponse | null;
}

/** Polling fallback for environments where SSE is blocked. */
export function getRunSnapshot(runId: string): Promise<RunSnapshot> {
  return request<RunSnapshot>(`/api/agent/run/${encodeURIComponent(runId)}`);
}

/* ───────────────────────────────── Workspace ─────────────────────────────── */

export function getAnalysis(runId: string): Promise<{ analysis: AgentResponse }> {
  return request(`/api/analyses/${encodeURIComponent(runId)}`);
}

export function getDatasets(): Promise<{ collections: unknown[] }> {
  return request('/api/datasets');
}

export function getActivity(): Promise<{ activity: ActivityEvent[]; persistence: boolean }> {
  return request('/api/activity');
}

export function getSavedAnalyses(): Promise<{ saved: SavedAnalysis[]; persistence: boolean }> {
  return request('/api/saved');
}

export function saveAnalysis(runId: string, title?: string): Promise<{ saved: SavedAnalysis }> {
  return request('/api/saved', {
    method: 'POST',
    body: JSON.stringify({ runId, ...(title ? { title } : {}) }),
  });
}

/** Absolute URL for a backend-served raster, for Mapbox image sources. */
export function imageryUrl(layerUrl: string): string {
  if (/^https?:\/\//i.test(layerUrl)) return layerUrl;
  return apiUrl(layerUrl);
}

/* ───────────────────────── Convenience: run and wait ─────────────────────── */

/**
 * Starts a run and streams it to completion. Used by the workspace; the
 * caller gets every intermediate event so the UI can narrate the real work.
 */
export async function runAndStream(
  params: { query: string; bbox?: [number, number, number, number] },
  handlers: StreamHandlers,
): Promise<{ runId: string; cancel: () => void }> {
  const accepted = await runAgent(params);
  const cancel = streamAgent(accepted.runId, handlers);
  return { runId: accepted.runId, cancel };
}
