/**
 * Domain types for the SatQuery AI frontend.
 *
 * Everything here is satisfied today by the local demo engine
 * (`src/lib/demoAgent.ts`). The shapes are deliberately backend-friendly so a
 * real service can be swapped in later without touching the UI layer.
 */

export type AnalysisKind = 'urban' | 'vegetation' | 'water' | 'landuse' | 'generic';

export type StepStatus = 'pending' | 'active' | 'complete';

export interface AgentStep {
  id: string;
  label: string;
  /** Simulated duration in ms for the PENDING → ACTIVE → COMPLETE transition. */
  duration: number;
  status: StepStatus;
}

export type LayerKind = 'change' | 'target' | 'baseline' | 'basemap';

export interface MapLayer {
  id: string;
  name: string;
  kind: LayerKind;
  visible: boolean;
  /** Optional colour chip shown next to the layer name. */
  swatch?: string;
}

export interface LegendEntry {
  label: string;
  color: string;
}

export interface MetadataEntry {
  label: string;
  value: string;
}

export interface ScenePalette {
  /** Change-intensity ramp, hottest first. */
  high: string;
  mid: string;
  low: string;
  /** AOI boundary stroke. */
  boundary: string;
  /** Base terrain tint. */
  terrain: string;
  water: string;
}

export interface ReportSection {
  heading: string;
  body: string;
}

export interface AnalysisResult {
  id: string;
  kind: AnalysisKind;
  /** e.g. "Urban Expansion (2021–2026)" */
  title: string;
  place: string;
  period: string;
  /** Seed string for the deterministic procedural renderer. */
  seed: string;
  palette: ScenePalette;
  layers: MapLayer[];
  legend: LegendEntry[];
  metadata: MetadataEntry[];
  insight: string;
  insightBullets: string[];
  report: ReportSection[];
  /** Short label used by cards and history rows. */
  shortLabel: string;
}

export type ChatRole = 'user' | 'agent';

export interface ChatAttachment {
  name: string;
  size: number;
  format: 'KML' | 'GeoJSON';
}

export interface ChatMessage {
  id: string;
  role: ChatRole;
  text: string;
  time: string;
  /** `plan` renders the agent plan card; `result` renders the "open result" nudge. */
  variant?: 'text' | 'plan' | 'result';
  planTitle?: string;
  steps?: AgentStep[];
  resultId?: string;
  attachment?: ChatAttachment;
  aoiLabel?: string;
  /** True while the agent is still "thinking" about this message. */
  pending?: boolean;
}

/** Camera state for the simulated map. */
export interface MapState {
  zoom: number;
  offsetX: number;
  offsetY: number;
  /** Only render the highest change class (driven by a follow-up query). */
  highOnly: boolean;
  /** Optional focus quadrant applied by a follow-up query. */
  focus: 'none' | 'east' | 'west' | 'north' | 'south' | 'core';
  /** Adds a further-back baseline to the composite. */
  baselineYear: number | null;
}

export type MapAction =
  | { type: 'high-only'; on: boolean }
  | { type: 'focus'; region: MapState['focus'] }
  | { type: 'baseline'; year: number }
  | { type: 'reset' }
  | { type: 'toggle-layer'; layerId: string; visible: boolean };

export interface FollowUpResponse {
  reply: string;
  action?: MapAction;
  chips?: string[];
}

export interface HistoryEntry {
  id: string;
  title: string;
  query: string;
  date: string;
  kind: AnalysisKind;
  scenarioId: string;
  messageCount: number;
}

export interface SavedResultEntry {
  id: string;
  title: string;
  date: string;
  description: string;
  kind: AnalysisKind;
  scenarioId: string;
  tag: string;
}

export interface DatasetEntry {
  id: string;
  name: string;
  provider: string;
  summary: string;
  resolution: string;
  revisit: string;
  bands: string;
  coverage: string;
  status: 'Available' | 'Indexing' | 'Limited';
  accent: string;
  icon: 'layers' | 'satellite' | 'radar' | 'globe';
}

export interface AoiEntry {
  id: string;
  name: string;
  area: string;
  lastAnalyzed: string;
  status: 'Monitoring' | 'Idle' | 'Draft';
  kind: AnalysisKind;
  bbox: string;
  seed: string;
}

export interface AlertEntry {
  id: string;
  title: string;
  region: string;
  detail: string;
  time: string;
  severity: 'high' | 'medium' | 'low';
  kind: AnalysisKind;
  unread: boolean;
}

export type WorkspaceView =
  | 'workspace'
  | 'history'
  | 'saved'
  | 'datasets'
  | 'aoi'
  | 'alerts'
  | 'settings';

export type AgentStatus = 'idle' | 'thinking' | 'working' | 'complete' | 'error';
