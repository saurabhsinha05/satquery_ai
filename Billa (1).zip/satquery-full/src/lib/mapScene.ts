/**
 * Procedural scene generation for the simulated Earth-observation view.
 *
 * There is no imagery here and no tile server. Every feature is synthesised
 * from a seeded PRNG so that a given scenario always renders identically —
 * which is what you want on a demo stage. Nothing in this file is a
 * measurement or a representation of a real place.
 */

import type { AnalysisKind } from './types';
import { hashSeed, makeRng } from './utils';

export const WORLD = { w: 1600, h: 1000 };

export type ChangeClass = 0 | 1 | 2; // 0 = high, 1 = moderate, 2 = low

export interface Pt {
  x: number;
  y: number;
}

export interface Segment {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  w: number;
  cls: ChangeClass;
}

export interface Blob {
  x: number;
  y: number;
  r: number;
  cls: ChangeClass;
  /** 0..1 — softness of the blob edge. */
  soft: number;
}

export interface Patch {
  points: Pt[];
  cls: ChangeClass;
}

export interface WaterBody {
  x: number;
  y: number;
  rx: number;
  ry: number;
  rot: number;
  /** 0..1 how much of the body is seasonal margin. */
  margin: number;
}

export type SceneStructure = 'dendritic' | 'patches' | 'hydro';

export interface Scene {
  seed: string;
  structure: SceneStructure;
  core: Pt;
  boundary: Pt[];
  /** Change signal — the headline layer. */
  segments: Segment[];
  blobs: Blob[];
  patches: Patch[];
  /** Earlier-epoch footprint, rendered muted. */
  baselineSegments: Segment[];
  baselinePatches: Patch[];
  water: WaterBody[];
  ridges: Pt[][];
  /** Focus targets used by follow-up queries. */
  anchors: Record<'core' | 'east' | 'west' | 'north' | 'south', Pt>;
}

const STRUCTURE_BY_KIND: Record<AnalysisKind, SceneStructure> = {
  urban: 'dendritic',
  vegetation: 'patches',
  water: 'hydro',
  landuse: 'patches',
  generic: 'dendritic',
};

/** Irregular closed blob used for the AOI outline and land-cover patches. */
function makeBlobPolygon(
  rng: () => number,
  cx: number,
  cy: number,
  radius: number,
  wobble: number,
  points = 26,
): Pt[] {
  const pts: Pt[] = [];
  // Two overlaid low-frequency waves keep the outline organic but smooth.
  const p1 = rng() * Math.PI * 2;
  const p2 = rng() * Math.PI * 2;
  const f1 = 2 + Math.floor(rng() * 2);
  const f2 = 4 + Math.floor(rng() * 3);
  for (let i = 0; i < points; i += 1) {
    const a = (i / points) * Math.PI * 2;
    const r =
      radius *
      (1 +
        wobble * 0.6 * Math.sin(a * f1 + p1) +
        wobble * 0.34 * Math.sin(a * f2 + p2) +
        wobble * 0.12 * (rng() - 0.5));
    pts.push({ x: cx + Math.cos(a) * r * 1.18, y: cy + Math.sin(a) * r });
  }
  return pts;
}

interface BranchOptions {
  rng: () => number;
  segments: Segment[];
  blobs: Blob[];
  /** Directional bias, in radians, that growth prefers. */
  bias: number;
  biasStrength: number;
}

function growBranch(
  opts: BranchOptions,
  origin: Pt,
  angle: number,
  length: number,
  depth: number,
  maxDepth: number,
): void {
  const { rng, segments, blobs } = opts;
  const steps = Math.max(3, Math.round(6 - depth));
  const stepLen = length / steps;
  let cursor = { ...origin };
  let heading = angle;

  const widthByDepth = [4.6, 3.0, 2.0, 1.35, 0.9, 0.65];
  const classByDepth: ChangeClass[] = [0, 0, 0, 1, 1, 2];

  for (let i = 0; i < steps; i += 1) {
    // Curve gently, and lean toward the growth bias.
    const towardBias = Math.atan2(
      Math.sin(opts.bias - heading),
      Math.cos(opts.bias - heading),
    );
    heading += (rng() - 0.5) * 0.42 + towardBias * opts.biasStrength * 0.16;

    const next = {
      x: cursor.x + Math.cos(heading) * stepLen,
      y: cursor.y + Math.sin(heading) * stepLen * 0.78,
    };

    segments.push({
      x1: cursor.x,
      y1: cursor.y,
      x2: next.x,
      y2: next.y,
      w: widthByDepth[Math.min(depth, widthByDepth.length - 1)] * (0.8 + rng() * 0.5),
      cls: classByDepth[Math.min(depth, classByDepth.length - 1)],
    });

    // Settlement nodes cluster on the network.
    if (rng() < 0.55) {
      blobs.push({
        x: next.x + (rng() - 0.5) * 22,
        y: next.y + (rng() - 0.5) * 16,
        r: (8 + rng() * 26) * (1 - depth * 0.13),
        cls: classByDepth[Math.min(depth, classByDepth.length - 1)],
        soft: 0.5 + rng() * 0.5,
      });
    }

    cursor = next;

    // Spawn children part-way along the branch.
    if (depth < maxDepth && i > 0 && rng() < 0.62) {
      const spread = 0.42 + rng() * 0.6;
      const dir = rng() < 0.5 ? -1 : 1;
      growBranch(
        opts,
        cursor,
        heading + spread * dir,
        length * (0.42 + rng() * 0.26),
        depth + 1,
        maxDepth,
      );
    }
  }
}

function buildDendritic(rng: () => number, core: Pt, bias: number) {
  const segments: Segment[] = [];
  const blobs: Blob[] = [];
  const opts: BranchOptions = { rng, segments, blobs, bias, biasStrength: 1 };

  const spokes = 9 + Math.floor(rng() * 3);
  for (let i = 0; i < spokes; i += 1) {
    const base = (i / spokes) * Math.PI * 2 + rng() * 0.25;
    // Branches aimed with the bias run further — this is what makes growth
    // read as directional ("towards the east and south-east").
    const alignment = Math.cos(base - bias);
    const length = (200 + rng() * 130) * (1 + alignment * 0.55);
    growBranch(opts, core, base, length, 0, 4);
  }

  // Dense core.
  for (let i = 0; i < 90; i += 1) {
    const a = rng() * Math.PI * 2;
    const d = Math.pow(rng(), 1.7) * 130;
    blobs.push({
      x: core.x + Math.cos(a) * d * 1.25,
      y: core.y + Math.sin(a) * d,
      r: 10 + rng() * 30,
      cls: d < 70 ? 0 : 1,
      soft: 0.55 + rng() * 0.45,
    });
  }

  // Detached satellite settlements, weighted toward the bias direction.
  for (let i = 0; i < 26; i += 1) {
    const a = bias + (rng() - 0.5) * 2.4;
    const d = 220 + rng() * 330;
    blobs.push({
      x: core.x + Math.cos(a) * d * 1.2,
      y: core.y + Math.sin(a) * d * 0.85,
      r: 12 + rng() * 34,
      cls: rng() < 0.35 ? 1 : 2,
      soft: 0.6 + rng() * 0.4,
    });
  }

  return { segments, blobs };
}

function buildPatches(rng: () => number, core: Pt, bias: number, count: number): Patch[] {
  const patches: Patch[] = [];
  for (let i = 0; i < count; i += 1) {
    const a = rng() * Math.PI * 2;
    const alignment = Math.cos(a - bias);
    const d = 60 + Math.pow(rng(), 0.75) * 480;
    const cx = core.x + Math.cos(a) * d * 1.25;
    const cy = core.y + Math.sin(a) * d * 0.9;
    const size = 22 + rng() * 96;
    // Patches aligned with the driver direction are more severe.
    const severity = rng() * 0.7 + alignment * 0.35;
    const cls: ChangeClass = severity > 0.62 ? 0 : severity > 0.3 ? 1 : 2;
    patches.push({
      points: makeBlobPolygon(rng, cx, cy, size, 0.42, 16),
      cls,
    });
  }
  return patches;
}

function buildHydro(rng: () => number, core: Pt): { water: WaterBody[]; patches: Patch[] } {
  const water: WaterBody[] = [];
  const patches: Patch[] = [];

  // A few large reservoirs.
  for (let i = 0; i < 4; i += 1) {
    const a = rng() * Math.PI * 2;
    const d = 120 + rng() * 380;
    water.push({
      x: core.x + Math.cos(a) * d * 1.2,
      y: core.y + Math.sin(a) * d * 0.85,
      rx: 70 + rng() * 90,
      ry: 42 + rng() * 60,
      rot: rng() * Math.PI,
      margin: 0.1 + rng() * 0.18,
    });
  }

  // Many small tank-cascade bodies.
  for (let i = 0; i < 46; i += 1) {
    const a = rng() * Math.PI * 2;
    const d = 70 + Math.pow(rng(), 0.7) * 560;
    const rx = 14 + rng() * 40;
    water.push({
      x: core.x + Math.cos(a) * d * 1.25,
      y: core.y + Math.sin(a) * d * 0.9,
      rx,
      ry: rx * (0.5 + rng() * 0.45),
      rot: rng() * Math.PI,
      margin: 0.2 + rng() * 0.5,
    });
  }

  for (const body of water) {
    const cls: ChangeClass = body.margin > 0.5 ? 2 : body.margin > 0.28 ? 1 : 0;
    patches.push({
      points: makeBlobPolygon(rng, body.x, body.y, Math.max(body.rx, body.ry) * 1.12, 0.24, 18),
      cls,
    });
  }

  return { water, patches };
}

const sceneCache = new Map<string, Scene>();

export function generateScene(seed: string, kind: AnalysisKind): Scene {
  const cacheKey = `${seed}::${kind}`;
  const cached = sceneCache.get(cacheKey);
  if (cached) return cached;

  const rng = makeRng(hashSeed(cacheKey));
  const structure = STRUCTURE_BY_KIND[kind];

  const core: Pt = {
    x: WORLD.w * (0.44 + rng() * 0.08),
    y: WORLD.h * (0.46 + rng() * 0.08),
  };

  // Growth bias — east / south-east for the flagship urban scenario.
  const bias =
    structure === 'dendritic' ? 0.32 + rng() * 0.22 : rng() * Math.PI * 2;

  let segments: Segment[] = [];
  let blobs: Blob[] = [];
  let patches: Patch[] = [];
  let water: WaterBody[] = [];
  let baselineSegments: Segment[] = [];
  let baselinePatches: Patch[] = [];

  if (structure === 'dendritic') {
    const built = buildDendritic(rng, core, bias);
    segments = built.segments;
    blobs = built.blobs;
    // Baseline epoch: the same skeleton, pulled back toward the core.
    baselineSegments = segments
      .filter((s) => s.cls === 0)
      .map((s) => ({
        x1: core.x + (s.x1 - core.x) * 0.66,
        y1: core.y + (s.y1 - core.y) * 0.66,
        x2: core.x + (s.x2 - core.x) * 0.66,
        y2: core.y + (s.y2 - core.y) * 0.66,
        w: s.w * 0.85,
        cls: s.cls,
      }));
  } else if (structure === 'patches') {
    patches = buildPatches(rng, core, bias, 78);
    baselinePatches = patches.slice(0, 34).map((p) => ({
      cls: 2,
      points: p.points.map((pt) => ({
        x: core.x + (pt.x - core.x) * 0.82,
        y: core.y + (pt.y - core.y) * 0.82,
      })),
    }));
    const built = buildDendritic(rng, core, bias);
    // Keep a faint road skeleton for spatial context.
    segments = built.segments.filter((s) => s.cls === 0).map((s) => ({ ...s, w: s.w * 0.5 }));
  } else {
    const built = buildHydro(rng, core);
    water = built.water;
    patches = built.patches;
    baselinePatches = patches.map((p) => ({
      cls: 2,
      points: p.points.map((pt) => ({
        x: pt.x + (pt.x - core.x) * 0.06,
        y: pt.y + (pt.y - core.y) * 0.06,
      })),
    }));
    const skeleton = buildDendritic(rng, core, bias);
    segments = skeleton.segments.filter((s) => s.cls === 0).map((s) => ({ ...s, w: s.w * 0.45 }));
  }

  if (structure !== 'hydro') {
    // Rivers / drainage for context.
    for (let i = 0; i < 3; i += 1) {
      const a = rng() * Math.PI * 2;
      water.push({
        x: core.x + Math.cos(a) * (260 + rng() * 220),
        y: core.y + Math.sin(a) * (180 + rng() * 180),
        rx: 55 + rng() * 70,
        ry: 26 + rng() * 34,
        rot: rng() * Math.PI,
        margin: 0.16,
      });
    }
  }

  const ridges: Pt[][] = [];
  for (let i = 0; i < 7; i += 1) {
    const line: Pt[] = [];
    const y0 = WORLD.h * (0.1 + rng() * 0.8);
    const amp = 22 + rng() * 60;
    const freq = 0.0028 + rng() * 0.0032;
    const phase = rng() * Math.PI * 2;
    for (let x = -60; x <= WORLD.w + 60; x += 34) {
      line.push({ x, y: y0 + Math.sin(x * freq + phase) * amp });
    }
    ridges.push(line);
  }

  const boundary = makeBlobPolygon(rng, core.x, core.y, 380, 0.2, 30);

  const scene: Scene = {
    seed,
    structure,
    core,
    boundary,
    segments,
    blobs,
    patches,
    baselineSegments,
    baselinePatches,
    water,
    ridges,
    anchors: {
      core,
      east: { x: core.x + 300, y: core.y + 90 },
      west: { x: core.x - 300, y: core.y - 40 },
      north: { x: core.x + 40, y: core.y - 240 },
      south: { x: core.x - 30, y: core.y + 250 },
    },
  };

  sceneCache.set(cacheKey, scene);
  return scene;
}
