/**
 * demoAgent — the local, deterministic "agent" behind SatQuery AI.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 *  NOTHING IN THIS FILE TALKS TO A NETWORK.
 *  No API keys, no satellite services, no LLM calls, no database.
 *  Every number, string and visual is illustrative demo content, generated
 *  locally so the frontend can be exercised end-to-end without a backend.
 *
 *  This module is intentionally UI-free. When a real backend arrives, replace
 *  `resolveScenario` / `resolveFollowUp` with service calls that return the
 *  same shapes and the interface layer keeps working untouched.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import type {
  AgentStep,
  AnalysisKind,
  AnalysisResult,
  FollowUpResponse,
  MapLayer,
  ScenePalette,
} from './types';
import { uid } from './utils';

/** Shown wherever demo output could be mistaken for a measurement. */
export const DEMO_DISCLAIMER =
  'Illustrative demo output. Generated locally in the browser — not computed from live satellite imagery.';

export const DEMO_DISCLAIMER_SHORT = 'Demo analysis — illustrative values, not measurements.';

const PALETTES: Record<AnalysisKind, ScenePalette> = {
  urban: {
    high: '#FF4D3D',
    mid: '#FF9F1C',
    low: '#F2E14C',
    boundary: '#2ACB93',
    terrain: '#0B1A1E',
    water: '#0E2A3C',
  },
  vegetation: {
    high: '#E8613F',
    mid: '#C9A238',
    low: '#5CA84E',
    boundary: '#38D9EE',
    terrain: '#08171A',
    water: '#0D2636',
  },
  water: {
    high: '#38D9EE',
    mid: '#3E8BE0',
    low: '#8AA6C8',
    boundary: '#2ACB93',
    terrain: '#0A1620',
    water: '#0B3550',
  },
  landuse: {
    high: '#C05FB8',
    mid: '#DC8A28',
    low: '#35A87C',
    boundary: '#2ACB93',
    terrain: '#0A1820',
    water: '#0E2A3C',
  },
  generic: {
    high: '#2ACB93',
    mid: '#38D9EE',
    low: '#7FA8C4',
    boundary: '#2ACB93',
    terrain: '#0A1620',
    water: '#0E2A3C',
  },
};

export interface DemoScenario {
  id: string;
  kind: AnalysisKind;
  /** Canonical phrasing of the query, used by History and example prompts. */
  query: string;
  place: string;
  period: string;
  /** First thing the agent says back. */
  ack: string;
  planTitle: string;
  planSteps: Array<{ label: string; duration: number }>;
  title: string;
  shortLabel: string;
  legend: Array<{ label: string; color: string }>;
  layers: Array<Omit<MapLayer, 'visible'> & { visible?: boolean }>;
  metadata: Array<{ label: string; value: string }>;
  insight: string;
  insightBullets: string[];
  report: Array<{ heading: string; body: string }>;
  /** Message shown when results land. */
  handoff: string;
  suggestions: string[];
  keywords: string[];
}

/* ────────────────────────────────────────────────────────────────────────── */
/*  Scenarios                                                                 */
/* ────────────────────────────────────────────────────────────────────────── */

const URBAN: DemoScenario = {
  id: 'urban-ranchi',
  kind: 'urban',
  query: 'Show me urban expansion around Ranchi from 2021 to 2026.',
  place: 'Ranchi, Jharkhand',
  period: '2021 – 2026',
  ack: "Got it. I'll analyze urban expansion around Ranchi between 2021 and 2026.",
  planTitle: "Here's my plan:",
  planSteps: [
    { label: 'Understand your query', duration: 500 },
    { label: 'Find relevant satellite data', duration: 800 },
    { label: 'Process imagery (cloud mask, composite)', duration: 900 },
    { label: 'Run analysis (NDBI + Change Detection)', duration: 1000 },
    { label: 'Generate visualization & insights', duration: 800 },
    { label: 'Deliver results', duration: 600 },
  ],
  title: 'Urban Expansion (2021 – 2026)',
  shortLabel: 'Urban Expansion — Ranchi',
  legend: [
    { label: 'High Expansion', color: '#FF4D3D' },
    { label: 'Moderate Expansion', color: '#FF9F1C' },
    { label: 'Low Expansion', color: '#F2E14C' },
  ],
  layers: [
    { id: 'change', name: 'Urban Expansion (2021 – 2026)', kind: 'change', swatch: '#FF4D3D' },
    { id: 'target', name: 'Built-up Area (2026)', kind: 'target', swatch: '#FF9F1C' },
    { id: 'baseline', name: 'Built-up Area (2021)', kind: 'baseline', swatch: '#8098A5', visible: false },
    { id: 'basemap', name: 'Base Map (Sentinel-2)', kind: 'basemap', swatch: '#2ACB93' },
  ],
  metadata: [
    { label: 'Area Analyzed', value: '~1,256 km²' },
    { label: 'Primary Index', value: 'NDBI' },
    { label: 'Time Period', value: '2021 – 2026' },
    { label: 'Resolution', value: '10 m / pixel' },
  ],
  insight:
    'Significant urban expansion detected, especially towards the east and southeast of Ranchi.',
  insightBullets: [
    'New built-up clusters follow the NH-33 and Ring Road corridors outward from the core.',
    'Infill densification dominates inside the municipal boundary; greenfield growth dominates outside it.',
    'A smaller secondary front appears north-west, close to the industrial belt.',
  ],
  report: [
    {
      heading: 'What the agent was asked',
      body: 'Detect and describe where built-up surface has grown around Ranchi between 2021 and 2026, and characterise the direction and intensity of that growth.',
    },
    {
      heading: 'How a run like this would work',
      body: 'Query parsing → AOI resolution → Sentinel-2 L2A scene search for two seasonal windows → cloud masking and median compositing → NDBI thresholding per epoch → post-classification change detection → vectorisation and intensity binning.',
    },
    {
      heading: 'Illustrative findings',
      body: 'The east and south-east sectors carry the highest change intensity, consistent with corridor-led growth. Moderate change forms a broken ring at the urban fringe. Low-intensity change is scattered and would need field or high-resolution confirmation.',
    },
    {
      heading: 'Caveats',
      body: 'This report is demo content produced by the local frontend engine for interface evaluation. It is not derived from satellite imagery and must not be cited as a measurement.',
    },
  ],
  handoff: 'Analysis complete. Here are the results.',
  suggestions: [
    'Show only the areas with high expansion.',
    'Compare this with 2019.',
    'Zoom into the eastern region.',
  ],
  keywords: [
    'urban',
    'expansion',
    'built-up',
    'builtup',
    'built up',
    'city growth',
    'sprawl',
    'ndbi',
    'ranchi',
    'settlement',
    'construction',
  ],
};

const VEGETATION: DemoScenario = {
  id: 'vegetation-jharkhand',
  kind: 'vegetation',
  query: 'Where has vegetation decreased in Jharkhand?',
  place: 'Jharkhand',
  period: '2020 – 2026',
  ack: "Understood. I'll look for vegetation loss across Jharkhand and rank it by severity.",
  planTitle: "Here's my plan:",
  planSteps: [
    { label: 'Understand your query', duration: 500 },
    { label: 'Find relevant satellite data', duration: 800 },
    { label: 'Process imagery (cloud mask, seasonal composite)', duration: 900 },
    { label: 'Run analysis (NDVI + Trend Detection)', duration: 1000 },
    { label: 'Generate visualization & insights', duration: 800 },
    { label: 'Deliver results', duration: 600 },
  ],
  title: 'Vegetation Change (2020 – 2026)',
  shortLabel: 'Vegetation Change — Jharkhand',
  legend: [
    { label: 'Severe Loss', color: '#E8613F' },
    { label: 'Moderate Loss', color: '#C9A238' },
    { label: 'Stable / Gain', color: '#5CA84E' },
  ],
  layers: [
    { id: 'change', name: 'Vegetation Loss (2020 – 2026)', kind: 'change', swatch: '#E8613F' },
    { id: 'target', name: 'Canopy Cover (2026)', kind: 'target', swatch: '#5CA84E' },
    { id: 'baseline', name: 'Canopy Cover (2020)', kind: 'baseline', swatch: '#8098A5', visible: false },
    { id: 'basemap', name: 'Base Map (Sentinel-2)', kind: 'basemap', swatch: '#2ACB93' },
  ],
  metadata: [
    { label: 'Area Analyzed', value: '~4,380 km²' },
    { label: 'Primary Index', value: 'NDVI' },
    { label: 'Time Period', value: '2020 – 2026' },
    { label: 'Resolution', value: '10 m / pixel' },
  ],
  insight:
    'Vegetation decline concentrates along the mining belt and the southern forest fringe, with stable canopy in the protected interior.',
  insightBullets: [
    'The sharpest loss patches sit adjacent to existing quarry and haul-road footprints.',
    'Fringe thinning is gradual and would benefit from a longer time series to separate drought years.',
    'Interior blocks read as stable to slightly gaining — likely regrowth in earlier-cleared parcels.',
  ],
  report: [
    {
      heading: 'What the agent was asked',
      body: 'Identify where vegetation has decreased across Jharkhand and describe the spatial pattern of that decrease.',
    },
    {
      heading: 'How a run like this would work',
      body: 'AOI resolution → multi-year Sentinel-2 seasonal composites → NDVI per epoch → per-pixel trend fitting → significance masking → severity binning and vectorisation.',
    },
    {
      heading: 'Illustrative findings',
      body: 'Loss is spatially clustered rather than diffuse, which in a real study would point at a small number of identifiable drivers rather than broad regional stress.',
    },
    {
      heading: 'Caveats',
      body: 'Demo content generated locally by the frontend for interface evaluation. Not derived from imagery; not a measurement.',
    },
  ],
  handoff: 'Analysis complete. Here are the results.',
  suggestions: [
    'Show only the areas with high expansion.',
    'Zoom into the eastern region.',
    'Compare this with 2019.',
  ],
  keywords: [
    'vegetation',
    'ndvi',
    'forest',
    'deforestation',
    'canopy',
    'green cover',
    'tree',
    'jharkhand',
    'crop',
    'biomass',
  ],
};

const WATER: DemoScenario = {
  id: 'water-bengaluru',
  kind: 'water',
  query: 'Detect water-body changes near Bengaluru.',
  place: 'Bengaluru, Karnataka',
  period: '2019 – 2026',
  ack: "On it. I'll map water-body extent near Bengaluru and flag where it has changed.",
  planTitle: "Here's my plan:",
  planSteps: [
    { label: 'Understand your query', duration: 500 },
    { label: 'Find relevant satellite data', duration: 800 },
    { label: 'Process imagery (cloud mask, water mask)', duration: 900 },
    { label: 'Run analysis (NDWI + Extent Comparison)', duration: 1000 },
    { label: 'Generate visualization & insights', duration: 800 },
    { label: 'Deliver results', duration: 600 },
  ],
  title: 'Water Body Change (2019 – 2026)',
  shortLabel: 'Water Body Change — Bengaluru',
  legend: [
    { label: 'Permanent Water', color: '#38D9EE' },
    { label: 'Seasonal Water', color: '#3E8BE0' },
    { label: 'Lost Extent', color: '#8AA6C8' },
  ],
  layers: [
    { id: 'change', name: 'Extent Change (2019 – 2026)', kind: 'change', swatch: '#38D9EE' },
    { id: 'target', name: 'Water Extent (2026)', kind: 'target', swatch: '#3E8BE0' },
    { id: 'baseline', name: 'Water Extent (2019)', kind: 'baseline', swatch: '#8098A5', visible: false },
    { id: 'basemap', name: 'Base Map (Sentinel-2)', kind: 'basemap', swatch: '#2ACB93' },
  ],
  metadata: [
    { label: 'Area Analyzed', value: '~2,190 km²' },
    { label: 'Primary Index', value: 'NDWI' },
    { label: 'Time Period', value: '2019 – 2026' },
    { label: 'Resolution', value: '10 m / pixel' },
  ],
  insight:
    'Several tank-cascade water bodies show reduced dry-season extent, while a few large reservoirs stay stable year-round.',
  insightBullets: [
    'Smaller peri-urban tanks show the largest proportional change — typical of encroachment or silting.',
    'Large reservoirs hold a stable permanent core with a thin seasonal margin.',
    'A handful of new small bodies appear where quarry pits have filled.',
  ],
  report: [
    {
      heading: 'What the agent was asked',
      body: 'Map water bodies near Bengaluru and detect where their extent has changed between 2019 and 2026.',
    },
    {
      heading: 'How a run like this would work',
      body: 'AOI resolution → dry- and wet-season Sentinel-2 composites → NDWI water masking → permanent vs seasonal classification → extent differencing between epochs.',
    },
    {
      heading: 'Illustrative findings',
      body: 'Change is dominated by small bodies at the urban fringe rather than by the large reservoirs, which is the pattern a peri-urban tank system usually shows.',
    },
    {
      heading: 'Caveats',
      body: 'Demo content generated locally by the frontend for interface evaluation. Not derived from imagery; not a measurement.',
    },
  ],
  handoff: 'Analysis complete. Here are the results.',
  suggestions: [
    'Zoom into the eastern region.',
    'Compare this with 2019.',
    'Show only the areas with high expansion.',
  ],
  keywords: [
    'water',
    'lake',
    'tank',
    'reservoir',
    'ndwi',
    'wetland',
    'river',
    'flood',
    'bengaluru',
    'bangalore',
    'shoreline',
  ],
};

const LANDUSE: DemoScenario = {
  id: 'landuse-region',
  kind: 'landuse',
  query: 'Compare land-use change in this region over the last 5 years.',
  place: 'Selected region',
  period: '2021 – 2026',
  ack: "Sure. I'll compare land-use classes across the selected region over the last five years.",
  planTitle: "Here's my plan:",
  planSteps: [
    { label: 'Understand your query', duration: 500 },
    { label: 'Find relevant satellite data', duration: 800 },
    { label: 'Process imagery (harmonise, cloud mask)', duration: 900 },
    { label: 'Run analysis (Land-cover classification)', duration: 1000 },
    { label: 'Generate visualization & insights', duration: 800 },
    { label: 'Deliver results', duration: 600 },
  ],
  title: 'Land-Use Change (2021 – 2026)',
  shortLabel: 'Land-Use Change — Region',
  legend: [
    { label: 'Built-up Gain', color: '#C05FB8' },
    { label: 'Cropland Shift', color: '#DC8A28' },
    { label: 'Vegetation Gain', color: '#35A87C' },
  ],
  layers: [
    { id: 'change', name: 'Class Transitions (2021 – 2026)', kind: 'change', swatch: '#C05FB8' },
    { id: 'target', name: 'Land Cover (2026)', kind: 'target', swatch: '#DC8A28' },
    { id: 'baseline', name: 'Land Cover (2021)', kind: 'baseline', swatch: '#8098A5', visible: false },
    { id: 'basemap', name: 'Base Map (Sentinel-2)', kind: 'basemap', swatch: '#2ACB93' },
  ],
  metadata: [
    { label: 'Area Analyzed', value: '~980 km²' },
    { label: 'Primary Index', value: 'Multi-index' },
    { label: 'Time Period', value: '2021 – 2026' },
    { label: 'Resolution', value: '10 m / pixel' },
  ],
  insight:
    'The dominant transition is cropland to built-up along transport corridors, with scattered vegetation gain on former fallow land.',
  insightBullets: [
    'Corridor-adjacent parcels account for most of the built-up gain.',
    'Vegetation gain appears on parcels that read as fallow in the earlier epoch.',
    'Class boundaries at the fringe are the least stable and carry the most uncertainty.',
  ],
  report: [
    {
      heading: 'What the agent was asked',
      body: 'Compare land-use classes across the selected region between 2021 and 2026 and summarise the dominant transitions.',
    },
    {
      heading: 'How a run like this would work',
      body: 'AOI resolution → harmonised annual composites → supervised land-cover classification per epoch → transition matrix → dominant-transition mapping.',
    },
    {
      heading: 'Illustrative findings',
      body: 'A small number of transition types account for most of the changed area, which is the usual signature of corridor-led peri-urban change.',
    },
    {
      heading: 'Caveats',
      body: 'Demo content generated locally by the frontend for interface evaluation. Not derived from imagery; not a measurement.',
    },
  ],
  handoff: 'Analysis complete. Here are the results.',
  suggestions: [
    'Show only the areas with high expansion.',
    'Zoom into the eastern region.',
    'Compare this with 2019.',
  ],
  keywords: [
    'land use',
    'land-use',
    'landuse',
    'land cover',
    'landcover',
    'compare',
    'transition',
    'classification',
    'lulc',
  ],
};

export const SCENARIOS: DemoScenario[] = [URBAN, VEGETATION, WATER, LANDUSE];

export const DEMO_QUERY = URBAN.query;

export const EXAMPLE_PROMPTS: Array<{ label: string; hint: string; kind: AnalysisKind }> = [
  { label: URBAN.query, hint: 'Change detection', kind: 'urban' },
  { label: VEGETATION.query, hint: 'NDVI trend', kind: 'vegetation' },
  { label: WATER.query, hint: 'Water extent', kind: 'water' },
  { label: LANDUSE.query, hint: 'Land-cover comparison', kind: 'landuse' },
];

/** A larger set surfaced by the Examples sheet and the landing page. */
export const EXAMPLE_LIBRARY: Array<{ group: string; items: string[] }> = [
  {
    group: 'Urban growth',
    items: [
      URBAN.query,
      'How much has the built-up area grown along the NH-33 corridor?',
      'Which fringe wards changed the most since 2021?',
    ],
  },
  {
    group: 'Vegetation & forests',
    items: [
      VEGETATION.query,
      'Show canopy loss near the mining belt.',
      'Has plantation cover recovered since 2020?',
    ],
  },
  {
    group: 'Water',
    items: [
      WATER.query,
      'Which lakes shrank the most in the dry season?',
      'Map seasonal versus permanent water in this district.',
    ],
  },
  {
    group: 'Land use',
    items: [
      LANDUSE.query,
      'What replaced cropland in this region?',
      'Summarise the dominant land-cover transitions.',
    ],
  },
];

/* ────────────────────────────────────────────────────────────────────────── */
/*  Resolution                                                                */
/* ────────────────────────────────────────────────────────────────────────── */

const GENERIC_FALLBACK: DemoScenario = {
  ...LANDUSE,
  id: 'generic-observation',
  kind: 'generic',
  title: 'Earth Observation Summary',
  shortLabel: 'Earth Observation Summary',
  place: 'Selected area of interest',
  ack: "Got it. I'll interpret that as a change-detection question and put together a general Earth-observation summary for the area.",
  legend: [
    { label: 'Strong Change', color: '#2ACB93' },
    { label: 'Moderate Change', color: '#38D9EE' },
    { label: 'Low Change', color: '#7FA8C4' },
  ],
  layers: [
    { id: 'change', name: 'Detected Change', kind: 'change', swatch: '#2ACB93' },
    { id: 'target', name: 'Recent Composite', kind: 'target', swatch: '#38D9EE' },
    { id: 'baseline', name: 'Earlier Composite', kind: 'baseline', swatch: '#8098A5', visible: false },
    { id: 'basemap', name: 'Base Map (Sentinel-2)', kind: 'basemap', swatch: '#2ACB93' },
  ],
  metadata: [
    { label: 'Area Analyzed', value: '~1,040 km²' },
    { label: 'Primary Index', value: 'Multi-index' },
    { label: 'Time Period', value: '2021 – 2026' },
    { label: 'Resolution', value: '10 m / pixel' },
  ],
  insight:
    'This build ships four fully worked demo scenarios. Your question was handled with a general change summary — try one of the suggested prompts for the richest walkthrough.',
  insightBullets: [
    'Urban expansion, vegetation change, water-body change and land-use change each have a complete demo path.',
    'Follow-up questions such as "show only high change" or "zoom into the eastern region" work on any result.',
  ],
  report: [
    {
      heading: 'About this response',
      body: 'The local demo engine did not recognise a specific analysis type in your question, so it produced a general change summary. In a backed build this is where a language model would negotiate the intent with you.',
    },
    {
      heading: 'Caveats',
      body: 'Demo content generated locally by the frontend for interface evaluation. Not derived from imagery; not a measurement.',
    },
  ],
  suggestions: [URBAN.query, VEGETATION.query, WATER.query],
  keywords: [],
};

/** Pick the scenario whose keywords best match a free-text query. */
export function resolveScenario(rawQuery: string): DemoScenario {
  const query = rawQuery.toLowerCase();
  let best: { scenario: DemoScenario; score: number } | null = null;

  for (const scenario of SCENARIOS) {
    let score = 0;
    for (const keyword of scenario.keywords) {
      if (query.includes(keyword)) score += keyword.includes(' ') ? 3 : 2;
    }
    if (query.includes(scenario.place.split(',')[0].toLowerCase())) score += 2;
    if (!best || score > best.score) best = { scenario, score };
  }

  if (!best || best.score === 0) return GENERIC_FALLBACK;
  return best.scenario;
}

export function getScenarioById(id: string): DemoScenario {
  return SCENARIOS.find((s) => s.id === id) ?? GENERIC_FALLBACK;
}

/** Fresh plan instance — every step starts pending. */
export function buildPlan(scenario: DemoScenario): AgentStep[] {
  return scenario.planSteps.map((step, index) => ({
    id: `${scenario.id}-step-${index}`,
    label: step.label,
    duration: step.duration,
    status: 'pending' as const,
  }));
}

/** Fresh result instance with its own layer visibility state. */
export function buildResult(scenario: DemoScenario, seedSuffix = ''): AnalysisResult {
  return {
    id: uid('res'),
    kind: scenario.kind,
    title: scenario.title,
    place: scenario.place,
    period: scenario.period,
    seed: `${scenario.id}${seedSuffix}`,
    palette: PALETTES[scenario.kind],
    layers: scenario.layers.map((layer) => ({ ...layer, visible: layer.visible ?? true })),
    legend: scenario.legend,
    metadata: scenario.metadata,
    insight: scenario.insight,
    insightBullets: scenario.insightBullets,
    report: scenario.report,
    shortLabel: scenario.shortLabel,
  };
}

export function getPalette(kind: AnalysisKind): ScenePalette {
  return PALETTES[kind];
}

/* ────────────────────────────────────────────────────────────────────────── */
/*  Follow-up conversation                                                    */
/* ────────────────────────────────────────────────────────────────────────── */

interface FollowUpRule {
  test: (q: string) => boolean;
  build: (result: AnalysisResult) => FollowUpResponse;
}

const FOLLOW_UP_RULES: FollowUpRule[] = [
  {
    test: (q) =>
      /(only|just).*(high|severe|strong|intense)|high[- ]?(expansion|change|loss)\s*only|filter.*high/.test(
        q,
      ),
    build: (result) => ({
      reply: `Filtered the ${result.title.toLowerCase()} layer down to the highest intensity class. The moderate and low classes are hidden — the map now shows only the strongest change signal.`,
      action: { type: 'high-only', on: true },
      chips: ['Show all classes again', 'Zoom into the eastern region'],
    }),
  },
  {
    test: (q) => /(show|bring).*(all|every).*(class|intensity|level)|unfilter|reset the filter/.test(q),
    build: () => ({
      reply: 'Restored all intensity classes on the change layer.',
      action: { type: 'high-only', on: false },
      chips: ['Zoom into the eastern region', 'Compare this with 2019'],
    }),
  },
  {
    test: (q) => /(compare|against|versus|vs\.?).*(19|2019)|baseline.*2019/.test(q),
    build: (result) => ({
      reply: `Added a 2019 baseline composite underneath the current result. You'll see the earlier extent in muted grey beneath the ${result.period} change layer, so the two epochs read against each other.`,
      action: { type: 'baseline', year: 2019 },
      chips: ['Show only the areas with high expansion', 'Reset the view'],
    }),
  },
  {
    test: (q) => /(zoom|focus|look).*(east|eastern)/.test(q),
    build: () => ({
      reply: 'Zoomed into the eastern sector. This is where the change signal is densest in this scenario.',
      action: { type: 'focus', region: 'east' },
      chips: ['Reset the view', 'Show only the areas with high expansion'],
    }),
  },
  {
    test: (q) => /(zoom|focus|look).*(west|western)/.test(q),
    build: () => ({
      reply: 'Zoomed into the western sector.',
      action: { type: 'focus', region: 'west' },
      chips: ['Reset the view', 'Zoom into the eastern region'],
    }),
  },
  {
    test: (q) => /(zoom|focus|look).*(north)/.test(q),
    build: () => ({
      reply: 'Zoomed into the northern sector.',
      action: { type: 'focus', region: 'north' },
      chips: ['Reset the view'],
    }),
  },
  {
    test: (q) => /(zoom|focus|look).*(south)/.test(q),
    build: () => ({
      reply: 'Zoomed into the southern sector.',
      action: { type: 'focus', region: 'south' },
      chips: ['Reset the view'],
    }),
  },
  {
    test: (q) => /(zoom|focus|look).*(cent(re|er)|core|downtown|city)/.test(q),
    build: () => ({
      reply: 'Centred on the urban core.',
      action: { type: 'focus', region: 'core' },
      chips: ['Reset the view', 'Zoom into the eastern region'],
    }),
  },
  {
    test: (q) => /(reset|default|zoom out|full extent|whole area)/.test(q),
    build: () => ({
      reply: 'Reset the map to the full area of interest with every class visible.',
      action: { type: 'reset' },
      chips: ['Show only the areas with high expansion', 'Compare this with 2019'],
    }),
  },
  {
    test: (q) => /(hide|turn off|remove).*(base ?map|basemap)/.test(q),
    build: () => ({
      reply: 'Base map hidden. The change layer now sits on a plain background.',
      action: { type: 'toggle-layer', layerId: 'basemap', visible: false },
      chips: ['Show the base map', 'Reset the view'],
    }),
  },
  {
    test: (q) => /(show|turn on|enable).*(base ?map|basemap)/.test(q),
    build: () => ({
      reply: 'Base map is back on.',
      action: { type: 'toggle-layer', layerId: 'basemap', visible: true },
    }),
  },
  {
    test: (q) => /(explain|why|how).*(work|analy|method|index|ndbi|ndvi|ndwi)/.test(q),
    build: (result) => ({
      reply: `In a backed build this run would resolve your area of interest, search a satellite archive for two cloud-free windows, composite them, compute the driving index, then difference the epochs and bin the result into intensity classes. What you're looking at is the interface for that workflow — the ${result.title} layer here is locally generated demo content, not a computed product.`,
      chips: ['Show only the areas with high expansion', 'Open the full report'],
    }),
  },
  {
    test: (q) => /(export|download|save|report|pdf)/.test(q),
    build: () => ({
      reply: 'Use Download in the result header for a demo export, or "View Full Report" under Insights for the written summary. Both are generated locally in this build.',
      chips: ['Reset the view'],
    }),
  },
];

export function resolveFollowUp(rawQuery: string, result: AnalysisResult): FollowUpResponse {
  const query = rawQuery.toLowerCase().trim();
  for (const rule of FOLLOW_UP_RULES) {
    if (rule.test(query)) return rule.build(result);
  }

  return {
    reply: `I've kept the ${result.title} result on screen. This build understands a fixed set of follow-ups — try filtering to the highest intensity class, adding a 2019 baseline, or zooming into a compass direction.`,
    chips: [
      'Show only the areas with high expansion.',
      'Compare this with 2019.',
      'Zoom into the eastern region.',
    ],
  };
}

/** True when a message should start a brand new analysis rather than refine one. */
export function isNewAnalysisQuery(rawQuery: string): boolean {
  const query = rawQuery.toLowerCase();
  const refinement =
    /^(show only|only show|just show|filter|zoom|focus|compare|hide|turn off|turn on|reset|explain|why|how does|export|download)/.test(
      query.trim(),
    );
  if (refinement) return false;
  return SCENARIOS.some((scenario) => scenario.keywords.some((k) => query.includes(k)));
}
