/**
 * Procedural Earth textures built on top of a real coastline mask.
 *
 * Nothing is downloaded: the land/ocean geometry comes from the bundled mask
 * in `landMask.ts`, and biome colour, bathymetry, ice, clouds and night lights
 * are all synthesised here. Built once, then reused by every globe on screen.
 */

import { MASK_W, MASK_H, decodeLandMask } from './landMask';
import { hashSeed, makeRng } from './utils';

export const TEX_W = 1024;
export const TEX_H = 512;

export interface EarthTextures {
  /** RGB triplets, TEX_W * TEX_H * 3 */
  day: Uint8Array;
  /** 0-255 night-light intensity */
  lights: Uint8Array;
  /** 0-255 cloud coverage */
  clouds: Uint8Array;
}

/* ── noise ────────────────────────────────────────────────────────────────── */

function valueNoise(w: number, h: number, cells: number, seed: string): Float32Array {
  const rng = makeRng(hashSeed(seed));
  const cw = cells + 1;
  const ch = Math.max(2, Math.round(cells / 2) + 1);
  const grid = new Float32Array(cw * ch);
  for (let i = 0; i < grid.length; i += 1) grid[i] = rng();

  const out = new Float32Array(w * h);
  for (let y = 0; y < h; y += 1) {
    const gy = (y / h) * (ch - 1);
    const y0 = Math.floor(gy);
    const fy = gy - y0;
    const sy = fy * fy * (3 - 2 * fy);
    for (let x = 0; x < w; x += 1) {
      const gx = (x / w) * (cw - 1);
      const x0 = Math.floor(gx);
      const fx = gx - x0;
      const sx = fx * fx * (3 - 2 * fx);
      const x1 = (x0 + 1) % (cw - 1);
      const a = grid[y0 * cw + x0];
      const b = grid[y0 * cw + x1];
      const c = grid[(y0 + 1) * cw + x0];
      const d = grid[(y0 + 1) * cw + x1];
      out[y * w + x] = (a + (b - a) * sx) * (1 - sy) + (c + (d - c) * sx) * sy;
    }
  }
  return out;
}

function fbm(w: number, h: number, seed: string, octaves = 4): Float32Array {
  const out = new Float32Array(w * h);
  let amp = 1;
  let total = 0;
  for (let o = 0; o < octaves; o += 1) {
    const layer = valueNoise(w, h, 6 * 2 ** o, `${seed}:${o}`);
    for (let i = 0; i < out.length; i += 1) out[i] += layer[i] * amp;
    total += amp;
    amp *= 0.5;
  }
  for (let i = 0; i < out.length; i += 1) out[i] /= total;
  return out;
}

function mix(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/* ── build ────────────────────────────────────────────────────────────────── */

let cached: EarthTextures | null = null;

export function buildEarthTextures(): EarthTextures {
  if (cached) return cached;

  const mask = decodeLandMask();
  const day = new Uint8Array(TEX_W * TEX_H * 3);
  const lights = new Uint8Array(TEX_W * TEX_H);
  const clouds = new Uint8Array(TEX_W * TEX_H);

  const terrain = fbm(TEX_W, TEX_H, 'earth-terrain', 4);
  const arid = fbm(TEX_W, TEX_H, 'earth-arid', 3);
  const cloudField = fbm(TEX_W, TEX_H, 'earth-clouds', 5);
  const rng = makeRng(hashSeed('earth-lights'));

  // Coast proximity, measured on the low-res mask: a texel counts as coastal
  // when any neighbour within `reach` is ocean.
  const coastal = new Uint8Array(MASK_W * MASK_H);
  const shelf = new Uint8Array(MASK_W * MASK_H);
  const reach = 2;
  for (let y = 0; y < MASK_H; y += 1) {
    for (let x = 0; x < MASK_W; x += 1) {
      const i = y * MASK_W + x;
      let sawLand = false;
      let sawSea = false;
      for (let dy = -reach; dy <= reach; dy += 1) {
        const yy = y + dy;
        if (yy < 0 || yy >= MASK_H) continue;
        for (let dx = -reach; dx <= reach; dx += 1) {
          const xx = (x + dx + MASK_W) % MASK_W;
          if (mask[yy * MASK_W + xx]) sawLand = true;
          else sawSea = true;
        }
      }
      if (mask[i] && sawSea) coastal[i] = 1;
      if (!mask[i] && sawLand) shelf[i] = 1;
    }
  }

  for (let y = 0; y < TEX_H; y += 1) {
    // +90 at the top row, -90 at the bottom.
    const lat = 90 - ((y + 0.5) / TEX_H) * 180;
    const absLat = Math.abs(lat);
    const my = Math.min(MASK_H - 1, Math.floor(((y + 0.5) / TEX_H) * MASK_H));

    for (let x = 0; x < TEX_W; x += 1) {
      const i = y * TEX_W + x;
      const mx = Math.min(MASK_W - 1, Math.floor(((x + 0.5) / TEX_W) * MASK_W));
      const mi = my * MASK_W + mx;
      const isLand = mask[mi] === 1;
      const n = terrain[i];
      const a = arid[i];

      let r: number;
      let g: number;
      let b: number;

      if (isLand) {
        // Biome by latitude, pushed around by two noise fields.
        const tropical = Math.max(0, 1 - absLat / 26);
        const temperate = Math.max(0, 1 - Math.abs(absLat - 42) / 30);
        const desertBand = Math.max(0, 1 - Math.abs(absLat - 25) / 15) * (a > 0.52 ? 1 : 0.15);
        const polar = Math.max(0, (absLat - 58) / 22);

        // green base
        r = mix(30, 58, n);
        g = mix(96, 132, n);
        b = mix(52, 66, n);

        if (tropical > 0) {
          r = mix(r, 26, tropical * 0.8);
          g = mix(g, 112, tropical * 0.8);
          b = mix(b, 48, tropical * 0.8);
        }
        if (temperate > 0) {
          r = mix(r, 74, temperate * 0.45);
          g = mix(g, 122, temperate * 0.45);
          b = mix(b, 58, temperate * 0.45);
        }
        if (desertBand > 0) {
          r = mix(r, 168, desertBand * 0.85);
          g = mix(g, 142, desertBand * 0.85);
          b = mix(b, 86, desertBand * 0.85);
        }
        if (polar > 0) {
          const t = Math.min(1, polar);
          r = mix(r, 226, t);
          g = mix(g, 240, t);
          b = mix(b, 244, t);
        }
        if (coastal[mi]) {
          r = mix(r, 122, 0.22);
          g = mix(g, 156, 0.22);
          b = mix(b, 96, 0.22);
        }

        // City lights cluster on temperate, non-polar, coastal-ish land.
        const habitability = (1 - polar) * (0.35 + 0.65 * (1 - desertBand)) * (coastal[mi] ? 1 : 0.55);
        if (rng() < 0.05 * habitability) {
          lights[i] = Math.min(255, 90 + Math.floor(rng() * 165));
        } else if (rng() < 0.1 * habitability) {
          lights[i] = 30 + Math.floor(rng() * 50);
        }
      } else {
        // Teal-leaning ocean with a lighter shelf near coastlines.
        const depth = 0.35 + 0.65 * n;
        r = mix(4, 12, depth);
        g = mix(38, 74, depth);
        b = mix(58, 96, depth);
        if (shelf[mi]) {
          r = mix(r, 24, 0.55);
          g = mix(g, 122, 0.55);
          b = mix(b, 142, 0.55);
        }
        if (absLat > 68) {
          const t = Math.min(1, (absLat - 68) / 14);
          r = mix(r, 214, t);
          g = mix(g, 236, t);
          b = mix(b, 242, t);
        }
      }

      day[i * 3] = r;
      day[i * 3 + 1] = g;
      day[i * 3 + 2] = b;

      // Cloud bands: heavy at the ITCZ and mid latitudes, thin over deserts.
      const band =
        0.55 * Math.exp(-((lat / 12) ** 2)) +
        0.5 * Math.exp(-(((absLat - 52) / 18) ** 2)) +
        0.18;
      const c = cloudField[i] * band * 1.5 - 0.28;
      clouds[i] = c > 0 ? Math.min(255, Math.floor(c * 320)) : 0;
    }
  }

  cached = { day, lights, clouds };
  return cached;
}
