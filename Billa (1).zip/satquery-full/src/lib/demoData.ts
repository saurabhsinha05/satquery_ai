/**
 * Static demo content for the secondary workspace screens.
 * Local, illustrative, and clearly labelled as such in the UI.
 */

import type {
  AlertEntry,
  AoiEntry,
  DatasetEntry,
  HistoryEntry,
  SavedResultEntry,
} from './types';

export const DEMO_USER = {
  name: 'Arjun Verma',
  initials: 'A',
  role: 'Geospatial Analyst',
  org: 'SatQuery Demo Workspace',
  email: 'arjun@satquery.demo',
};

export const HISTORY: HistoryEntry[] = [
  {
    id: 'h1',
    title: 'Urban Expansion — Ranchi',
    query: 'Show me urban expansion around Ranchi from 2021 to 2026.',
    date: 'Aug 24, 2026',
    kind: 'urban',
    scenarioId: 'urban-ranchi',
    messageCount: 6,
  },
  {
    id: 'h2',
    title: 'Vegetation Change — Jharkhand',
    query: 'Where has vegetation decreased in Jharkhand?',
    date: 'Aug 23, 2026',
    kind: 'vegetation',
    scenarioId: 'vegetation-jharkhand',
    messageCount: 4,
  },
  {
    id: 'h3',
    title: 'Water Body Detection — Bengaluru',
    query: 'Detect water-body changes near Bengaluru.',
    date: 'Aug 21, 2026',
    kind: 'water',
    scenarioId: 'water-bengaluru',
    messageCount: 5,
  },
  {
    id: 'h4',
    title: 'Land-Use Change — Ranchi District',
    query: 'Compare land-use change in this region over the last 5 years.',
    date: 'Aug 18, 2026',
    kind: 'landuse',
    scenarioId: 'landuse-region',
    messageCount: 3,
  },
];

export const SAVED_RESULTS: SavedResultEntry[] = [
  {
    id: 's1',
    title: 'Urban Expansion — Ranchi',
    date: 'Aug 24, 2026',
    description:
      'Built-up growth concentrated east and south-east of the core, following the highway corridors.',
    kind: 'urban',
    scenarioId: 'urban-ranchi',
    tag: 'NDBI',
  },
  {
    id: 's2',
    title: 'Vegetation Change — Jharkhand',
    date: 'Aug 23, 2026',
    description:
      'Canopy decline clustered along the mining belt; protected interior blocks read as stable.',
    kind: 'vegetation',
    scenarioId: 'vegetation-jharkhand',
    tag: 'NDVI',
  },
  {
    id: 's3',
    title: 'Water Body Change — Bengaluru',
    date: 'Aug 21, 2026',
    description:
      'Peri-urban tanks show the largest proportional extent change; major reservoirs stay stable.',
    kind: 'water',
    scenarioId: 'water-bengaluru',
    tag: 'NDWI',
  },
];

export const DATASETS: DatasetEntry[] = [
  {
    id: 'sentinel-2',
    name: 'Sentinel-2',
    provider: 'Copernicus / ESA',
    summary: 'Multispectral optical imagery — the default source for index-based change detection.',
    resolution: '10 / 20 / 60 m',
    revisit: '5 days',
    bands: '13 bands (VNIR – SWIR)',
    coverage: '2015 – present',
    status: 'Available',
    accent: '#2ACB93',
    icon: 'layers',
  },
  {
    id: 'landsat',
    name: 'Landsat 8/9',
    provider: 'USGS / NASA',
    summary: 'Long-term Earth observation record, useful when the question reaches back decades.',
    resolution: '15 / 30 / 100 m',
    revisit: '8 days (combined)',
    bands: '11 bands (incl. thermal)',
    coverage: '2013 – present',
    status: 'Available',
    accent: '#38D9EE',
    icon: 'satellite',
  },
  {
    id: 'sentinel-1',
    name: 'Sentinel-1',
    provider: 'Copernicus / ESA',
    summary: 'C-band radar imagery — sees through cloud, which matters through the monsoon.',
    resolution: '5 × 20 m (IW)',
    revisit: '6 – 12 days',
    bands: 'VV / VH polarisation',
    coverage: '2014 – present',
    status: 'Available',
    accent: '#FF9F1C',
    icon: 'radar',
  },
  {
    id: 'srtm',
    name: 'SRTM / Copernicus DEM',
    provider: 'NASA / ESA',
    summary: 'Elevation and terrain context used for slope masking and hydrology.',
    resolution: '30 m',
    revisit: 'Static',
    bands: 'Elevation',
    coverage: '2000 / 2011 – 2015',
    status: 'Limited',
    accent: '#8098A5',
    icon: 'globe',
  },
  {
    id: 'bhuvan',
    name: 'Bhuvan / IRS Archives',
    provider: 'ISRO / NRSC',
    summary: 'Indian Earth-observation archives and thematic layers for national-scale work.',
    resolution: 'Varies',
    revisit: 'Varies',
    bands: 'Multiple sensors',
    coverage: '1988 – present',
    status: 'Indexing',
    accent: '#E36BD4',
    icon: 'globe',
  },
  {
    id: 'viirs',
    name: 'VIIRS Night Lights',
    provider: 'NOAA',
    summary: 'Night-time radiance, a useful proxy signal for settlement growth and activity.',
    resolution: '500 m',
    revisit: 'Daily',
    bands: 'Day/Night Band',
    coverage: '2012 – present',
    status: 'Available',
    accent: '#F2E14C',
    icon: 'satellite',
  },
];

export const AOIS: AoiEntry[] = [
  {
    id: 'aoi-ranchi',
    name: 'Ranchi Urban Region',
    area: '~1,256 km²',
    lastAnalyzed: 'Aug 24, 2026',
    status: 'Monitoring',
    kind: 'urban',
    bbox: '85.21°E, 23.24°N → 85.48°E, 23.47°N',
    seed: 'urban-ranchi',
  },
  {
    id: 'aoi-forest',
    name: 'Jharkhand Forest Belt',
    area: '~4,380 km²',
    lastAnalyzed: 'Aug 23, 2026',
    status: 'Monitoring',
    kind: 'vegetation',
    bbox: '84.62°E, 22.71°N → 86.04°E, 23.68°N',
    seed: 'vegetation-jharkhand',
  },
  {
    id: 'aoi-water',
    name: 'Bengaluru Water Bodies',
    area: '~2,190 km²',
    lastAnalyzed: 'Aug 21, 2026',
    status: 'Idle',
    kind: 'water',
    bbox: '77.42°E, 12.79°N → 77.79°E, 13.14°N',
    seed: 'water-bengaluru',
  },
  {
    id: 'aoi-draft',
    name: 'Untitled AOI (drawn)',
    area: '~412 km²',
    lastAnalyzed: 'Not analyzed yet',
    status: 'Draft',
    kind: 'landuse',
    bbox: 'Drawn on map',
    seed: 'landuse-region',
  },
];

export const ALERTS: AlertEntry[] = [
  {
    id: 'a1',
    title: 'Urban expansion detected',
    region: 'Ranchi region',
    detail:
      'Built-up signal crossed the monitoring threshold in the eastern fringe cells of this AOI.',
    time: 'Today, 09:12',
    severity: 'high',
    kind: 'urban',
    unread: true,
  },
  {
    id: 'a2',
    title: 'Vegetation decline',
    region: 'Jharkhand',
    detail: 'Canopy index trending down across the southern forest fringe for a third window.',
    time: 'Yesterday, 18:40',
    severity: 'medium',
    kind: 'vegetation',
    unread: true,
  },
  {
    id: 'a3',
    title: 'Water body change',
    region: 'Bengaluru',
    detail: 'Dry-season extent for four peri-urban tanks fell below the seasonal envelope.',
    time: 'Aug 22, 07:05',
    severity: 'medium',
    kind: 'water',
    unread: false,
  },
  {
    id: 'a4',
    title: 'New imagery available',
    region: 'Ranchi Urban Region',
    detail: 'A fresh low-cloud optical window is available for this AOI and is ready to analyze.',
    time: 'Aug 20, 11:30',
    severity: 'low',
    kind: 'landuse',
    unread: false,
  },
];

export const USE_CASES = [
  {
    title: 'Urban planning',
    body: 'Watch where a city is actually growing, not where the master plan says it should.',
    icon: 'buildings' as const,
  },
  {
    title: 'Forest & vegetation',
    body: 'Track canopy loss and regrowth across a whole state without stitching scenes by hand.',
    icon: 'trees' as const,
  },
  {
    title: 'Water resources',
    body: 'Follow lakes, tanks and reservoirs through the seasons and spot the ones in trouble.',
    icon: 'droplet' as const,
  },
  {
    title: 'Disaster response',
    body: 'Ask what changed after an event and get an annotated answer instead of a raw archive.',
    icon: 'siren' as const,
  },
  {
    title: 'Agriculture',
    body: 'Compare cropping patterns season over season across districts.',
    icon: 'wheat' as const,
  },
  {
    title: 'Infrastructure',
    body: 'Check how corridors reshape the land around them over five- and ten-year windows.',
    icon: 'route' as const,
  },
];

export const HOW_IT_WORKS = [
  {
    step: 1,
    title: 'Understand Query',
    body: 'Interprets your question and understands intent.',
    icon: 'message' as const,
  },
  {
    step: 2,
    title: 'Find Satellite Data',
    body: 'Finds relevant datasets across multiple sources.',
    icon: 'satellite' as const,
  },
  {
    step: 3,
    title: 'Process Imagery',
    body: 'Applies cloud masking, filters, and preprocessing.',
    icon: 'cloud' as const,
  },
  {
    step: 4,
    title: 'Run Analysis',
    body: 'Performs geospatial analysis and change detection.',
    icon: 'chart' as const,
  },
  {
    step: 5,
    title: 'Deliver Insights',
    body: 'Generates visual, evidence-backed results you can trust.',
    icon: 'report' as const,
  },
];

export const CAPABILITIES = [
  { title: 'AI Agentic', subtitle: 'Orchestration' },
  { title: 'Multi-source', subtitle: 'Satellite Data' },
  { title: 'Accurate', subtitle: '& Traceable' },
  { title: 'Built for', subtitle: 'Impact' },
];
