import type { AgentEvent, AgentEventName } from './contract';
import type { AgentStep } from './types';

/**
 * Turns the backend's event stream into the plan the chat renders.
 *
 * Every label here is the backend's own message — nothing is invented on the
 * client, so what the user reads is literally what the agent reported doing.
 * Events are collapsed by stage so a chatty node (imagery rendering, say)
 * updates one line rather than adding ten.
 */

/** Which events collapse into the same visible stage. */
const STAGE_OF: Partial<Record<AgentEventName, string>> = {
  'agent.started': 'understand',
  'query.understood': 'understand',
  'location.resolved': 'locate',
  'map.planned': 'plan',
  'dataset.search.started': 'discover',
  'dataset.search.completed': 'discover',
  'dataset.selected': 'select',
  'imagery.selected': 'select',
  'analysis.started': 'process',
  'analysis.progress': 'process',
  'analysis.completed': 'process',
  'map.updated': 'map',
  'evidence.generated': 'evidence',
  'workspace.updated': 'deliver',
  'agent.completed': 'deliver',
  'agent.error': 'error',
};

const STAGE_ORDER = [
  'understand',
  'locate',
  'plan',
  'discover',
  'select',
  'process',
  'map',
  'evidence',
  'deliver',
  'error',
];

export function liveStepsFromEvents(events: AgentEvent[], finished: boolean): AgentStep[] {
  const latest = new Map<string, { message: string; at: string; failed: boolean }>();

  for (const event of events) {
    const stage = STAGE_OF[event.event];
    if (!stage) continue;
    latest.set(stage, {
      message: event.message,
      at: event.at,
      failed: event.event === 'agent.error',
    });
  }

  const stages = STAGE_ORDER.filter((s) => latest.has(s));
  return stages.map((stage, index) => {
    const entry = latest.get(stage)!;
    const isLast = index === stages.length - 1;
    return {
      id: `live-${stage}`,
      label: entry.message,
      duration: 0,
      status: entry.failed
        ? 'complete'
        : isLast && !finished
          ? 'active'
          : 'complete',
    } satisfies AgentStep;
  });
}

/** The most recent backend message, for the top-bar status line. */
export function latestMessage(events: AgentEvent[]): string | null {
  for (let i = events.length - 1; i >= 0; i -= 1) {
    if (events[i].message) return events[i].message;
  }
  return null;
}
