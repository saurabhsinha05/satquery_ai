/**
 * Canvas renderer for the simulated Earth-observation view.
 *
 * Layers are rasterised once into an offscreen world canvas and then blitted
 * per frame under a pan/zoom transform, so dragging the map stays smooth even
 * with a few thousand glow primitives in the scene.
 *
 * This draws a *stylised illustration*. It is not imagery and not a product.
 */

import type { ScenePalette } from './types';
import { WORLD, type Blob, type ChangeClass, type Patch, type Scene, type Segment } from './mapScene';
import { hashSeed, makeRng } from './utils';

export interface LayerVisibility {
  change: boolean;
  target: boolean;
  baseline: boolean;
  basemap: boolean;
}

export interface RenderOptions {
  highOnly: boolean;
  baselineYear: number | null;
  /** Render scale relative to WORLD — 1 for the main map, ~0.3 for thumbnails. */
  quality?: number;
}

function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean;
  const n = parseInt(full, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function rgba(hex: string, alpha: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function classColor(palette: ScenePalette, cls: ChangeClass): string {
  return cls === 0 ? palette.high : cls === 1 ? palette.mid : palette.low;
}

/* ── Terrain ─────────────────────────────────────────────────────────────── */

const noiseCache = new Map<string, HTMLCanvasElement>();

function noiseTile(seed: string, size = 150): HTMLCanvasElement {
  const cached = noiseCache.get(seed);
  if (cached) return cached;

  const c = document.createElement('canvas');
  c.width = size;
  c.height = Math.round(size * (WORLD.h / WORLD.w));
  const ctx = c.getContext('2d');
  if (!ctx) return c;

  const rng = makeRng(hashSeed(`noise:${seed}`));
  const img = ctx.createImageData(c.width, c.height);
  // Two octaves of smoothed value noise, cheap but plausible as terrain.
  const coarse: number[] = [];
  const cw = Math.ceil(c.width / 6) + 2;
  const ch = Math.ceil(c.height / 6) + 2;
  for (let i = 0; i < cw * ch; i += 1) coarse.push(rng());

  for (let y = 0; y < c.height; y += 1) {
    for (let x = 0; x < c.width; x += 1) {
      const gx = x / 6;
      const gy = y / 6;
      const x0 = Math.floor(gx);
      const y0 = Math.floor(gy);
      const fx = gx - x0;
      const fy = gy - y0;
      const a = coarse[y0 * cw + x0];
      const b = coarse[y0 * cw + x0 + 1];
      const cc = coarse[(y0 + 1) * cw + x0];
      const d = coarse[(y0 + 1) * cw + x0 + 1];
      const sx = fx * fx * (3 - 2 * fx);
      const sy = fy * fy * (3 - 2 * fy);
      const top = a + (b - a) * sx;
      const bottom = cc + (d - cc) * sx;
      const base = top + (bottom - top) * sy;
      const detail = rng() * 0.18;
      const v = Math.round((base * 0.82 + detail) * 255);
      const idx = (y * c.width + x) * 4;
      img.data[idx] = v;
      img.data[idx + 1] = v;
      img.data[idx + 2] = v;
      img.data[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  noiseCache.set(seed, c);
  return c;
}

function drawTerrain(ctx: CanvasRenderingContext2D, scene: Scene, palette: ScenePalette): void {
  const { w, h } = WORLD;

  const base = ctx.createLinearGradient(0, 0, w, h);
  base.addColorStop(0, '#050D12');
  base.addColorStop(0.45, palette.terrain);
  base.addColorStop(1, '#04090D');
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, w, h);

  // Soft landform texture.
  ctx.save();
  ctx.globalAlpha = 0.42;
  ctx.globalCompositeOperation = 'overlay';
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(noiseTile(scene.seed), 0, 0, w, h);
  ctx.restore();

  // Terrain shading tint.
  ctx.save();
  ctx.globalAlpha = 0.34;
  ctx.globalCompositeOperation = 'multiply';
  const tint = ctx.createRadialGradient(scene.core.x, scene.core.y, 60, scene.core.x, scene.core.y, w * 0.8);
  tint.addColorStop(0, '#2C4A44');
  tint.addColorStop(1, '#081116');
  ctx.fillStyle = tint;
  ctx.fillRect(0, 0, w, h);
  ctx.restore();

  // Ridge / contour lines.
  ctx.save();
  ctx.lineWidth = 1;
  ctx.strokeStyle = 'rgba(140, 190, 200, 0.09)';
  for (const line of scene.ridges) {
    ctx.beginPath();
    line.forEach((pt, i) => (i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y)));
    ctx.stroke();
  }
  ctx.restore();

  // Water bodies.
  ctx.save();
  for (const body of scene.water) {
    ctx.save();
    ctx.translate(body.x, body.y);
    ctx.rotate(body.rot);
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, Math.max(body.rx, body.ry));
    g.addColorStop(0, rgba(palette.water, 0.95));
    g.addColorStop(0.72, rgba(palette.water, 0.7));
    g.addColorStop(1, rgba(palette.water, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(0, 0, body.rx, body.ry, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  // Graticule.
  ctx.save();
  ctx.strokeStyle = 'rgba(120, 170, 185, 0.05)';
  ctx.lineWidth = 1;
  for (let x = 0; x <= w; x += 100) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
    ctx.stroke();
  }
  for (let y = 0; y <= h; y += 100) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }
  ctx.restore();
}

/* ── Feature layers ──────────────────────────────────────────────────────── */

function strokeSegments(
  ctx: CanvasRenderingContext2D,
  segments: Segment[],
  color: (cls: ChangeClass) => string,
  widthScale: number,
  glow: number,
): void {
  ctx.save();
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  if (glow > 0) {
    ctx.globalCompositeOperation = 'lighter';
    ctx.shadowBlur = glow;
  }
  for (const s of segments) {
    const c = color(s.cls);
    ctx.strokeStyle = c;
    ctx.shadowColor = c;
    ctx.lineWidth = s.w * widthScale;
    ctx.beginPath();
    ctx.moveTo(s.x1, s.y1);
    ctx.lineTo(s.x2, s.y2);
    ctx.stroke();
  }
  ctx.restore();
}

function fillBlobs(
  ctx: CanvasRenderingContext2D,
  blobs: Blob[],
  palette: ScenePalette,
  alpha: number,
): void {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const b of blobs) {
    const color = classColor(palette, b.cls);
    const g = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, b.r);
    g.addColorStop(0, rgba(color, alpha * (0.9 - b.soft * 0.25)));
    g.addColorStop(0.55, rgba(color, alpha * 0.35 * b.soft));
    g.addColorStop(1, rgba(color, 0));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function tracePatch(ctx: CanvasRenderingContext2D, patch: Patch): void {
  ctx.beginPath();
  patch.points.forEach((pt, i) => (i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y)));
  ctx.closePath();
}

function fillPatches(
  ctx: CanvasRenderingContext2D,
  patches: Patch[],
  palette: ScenePalette,
  alpha: number,
  stroke: boolean,
): void {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  for (const p of patches) {
    const color = classColor(palette, p.cls);
    tracePatch(ctx, p);
    ctx.fillStyle = rgba(color, alpha);
    ctx.fill();
    if (stroke) {
      ctx.lineWidth = 1;
      ctx.strokeStyle = rgba(color, Math.min(1, alpha * 1.5));
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawCoreGlow(ctx: CanvasRenderingContext2D, scene: Scene, palette: ScenePalette): void {
  ctx.save();
  ctx.globalCompositeOperation = 'lighter';
  const g = ctx.createRadialGradient(scene.core.x, scene.core.y, 0, scene.core.x, scene.core.y, 150);
  g.addColorStop(0, rgba('#FFE7CE', 0.3));
  g.addColorStop(0.14, rgba(palette.high, 0.34));
  g.addColorStop(0.48, rgba(palette.high, 0.11));
  g.addColorStop(1, rgba(palette.mid, 0));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(scene.core.x, scene.core.y, 150, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/* ── Composite ───────────────────────────────────────────────────────────── */

/**
 * Rasterise the requested layers into a single world-space canvas.
 * Callers cache this and re-run only when visibility or options change.
 */
export function renderWorld(
  scene: Scene,
  palette: ScenePalette,
  visibility: LayerVisibility,
  options: RenderOptions,
): HTMLCanvasElement {
  const quality = options.quality ?? 1;
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(WORLD.w * quality);
  canvas.height = Math.round(WORLD.h * quality);
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  ctx.scale(quality, quality);

  // Backdrop is always painted so hiding the base map leaves a clean field
  // rather than a transparent hole.
  ctx.fillStyle = '#04090D';
  ctx.fillRect(0, 0, WORLD.w, WORLD.h);

  if (visibility.basemap) {
    drawTerrain(ctx, scene, palette);
  } else {
    const g = ctx.createRadialGradient(
      scene.core.x,
      scene.core.y,
      40,
      scene.core.x,
      scene.core.y,
      WORLD.w * 0.7,
    );
    g.addColorStop(0, '#07131A');
    g.addColorStop(1, '#03080B');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, WORLD.w, WORLD.h);
  }

  // Earlier-epoch footprint, deliberately desaturated.
  if (visibility.baseline || options.baselineYear) {
    ctx.save();
    ctx.globalAlpha = options.baselineYear ? 0.85 : 0.7;
    strokeSegments(ctx, scene.baselineSegments, () => 'rgba(196, 214, 222, 0.5)', 0.9, 5);
    ctx.globalCompositeOperation = 'lighter';
    for (const p of scene.baselinePatches) {
      tracePatch(ctx, p);
      ctx.fillStyle = 'rgba(170, 196, 208, 0.1)';
      ctx.fill();
      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(196, 214, 222, 0.3)';
      ctx.stroke();
    }
    ctx.restore();
  }

  // Current-epoch extent — a broad warm footprint behind the change signal.
  if (visibility.target) {
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    const halo = ctx.createRadialGradient(
      scene.core.x,
      scene.core.y,
      20,
      scene.core.x,
      scene.core.y,
      520,
    );
    halo.addColorStop(0, rgba(palette.mid, 0.2));
    halo.addColorStop(0.55, rgba(palette.mid, 0.07));
    halo.addColorStop(1, rgba(palette.mid, 0));
    ctx.fillStyle = halo;
    ctx.fillRect(0, 0, WORLD.w, WORLD.h);
    ctx.restore();

    if (scene.structure === 'hydro') {
      fillPatches(ctx, scene.patches, palette, 0.1, false);
    } else {
      fillBlobs(
        ctx,
        scene.blobs.filter((_, i) => i % 2 === 0),
        palette,
        0.16,
      );
    }
  }

  // The headline change layer.
  if (visibility.change) {
    const filter = (cls: ChangeClass) => !options.highOnly || cls === 0;
    const segments = scene.segments.filter((s) => filter(s.cls));
    const blobs = scene.blobs.filter((b) => filter(b.cls));
    const patches = scene.patches.filter((p) => filter(p.cls));

    if (scene.structure === 'dendritic') {
      // Taper opacity down the class ramp so overlapping additive strokes stay
      // red-dominant instead of saturating toward gold.
      const rampAlpha: Record<ChangeClass, number> = { 0: 0.52, 1: 0.36, 2: 0.24 };
      strokeSegments(ctx, segments, (cls) => rgba(classColor(palette, cls), rampAlpha[cls]), 1, 6);
      fillBlobs(ctx, blobs, palette, 0.2);
      // Hot filament highlight on top of the trunk roads.
      strokeSegments(
        ctx,
        segments.filter((s) => s.cls === 0),
        () => 'rgba(255, 214, 178, 0.26)',
        0.3,
        4,
      );
      if (!options.highOnly) drawCoreGlow(ctx, scene, palette);
    } else {
      strokeSegments(ctx, segments, () => 'rgba(150, 190, 205, 0.14)', 0.7, 0);
      fillPatches(ctx, patches, palette, 0.2, true);
    }
  }

  // Sensor-ish finishing: faint banding + vignette.
  ctx.save();
  ctx.globalAlpha = 0.05;
  ctx.fillStyle = '#9FD8E4';
  for (let y = 0; y < WORLD.h; y += 4) ctx.fillRect(0, y, WORLD.w, 1);
  ctx.restore();

  ctx.save();
  const vig = ctx.createRadialGradient(
    WORLD.w / 2,
    WORLD.h / 2,
    WORLD.h * 0.32,
    WORLD.w / 2,
    WORLD.h / 2,
    WORLD.w * 0.78,
  );
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, 'rgba(0,0,0,0.5)');
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, WORLD.w, WORLD.h);
  ctx.restore();

  return canvas;
}

/** AOI outline — drawn live each frame so the dash pattern stays crisp at any zoom. */
export function strokeBoundary(
  ctx: CanvasRenderingContext2D,
  scene: Scene,
  palette: ScenePalette,
  scale: number,
): void {
  ctx.save();
  ctx.beginPath();
  scene.boundary.forEach((pt, i) => (i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y)));
  ctx.closePath();

  ctx.fillStyle = rgba(palette.boundary, 0.045);
  ctx.fill();

  ctx.setLineDash([10 / scale, 7 / scale]);
  ctx.lineWidth = 1.8 / scale;
  ctx.strokeStyle = rgba(palette.boundary, 0.85);
  ctx.shadowColor = rgba(palette.boundary, 0.6);
  ctx.shadowBlur = 9 / scale;
  ctx.stroke();
  ctx.restore();
}
