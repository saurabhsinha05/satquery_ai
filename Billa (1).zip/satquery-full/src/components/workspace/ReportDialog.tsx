import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { DEMO_DISCLAIMER } from '@/lib/demoAgent';
import type { AnalysisResult } from '@/lib/types';

export function ReportDialog({
  open,
  onClose,
  result,
}: {
  open: boolean;
  onClose: () => void;
  result: AnalysisResult | null;
}) {
  if (!result) return null;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={result.title}
      description={`${result.place} · ${result.period}`}
      size="lg"
      footer={
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      }
    >
      <div className="space-y-6">
        <div className="flex flex-wrap gap-2">
          <Badge tone="neutral" className="font-mono uppercase tracking-wider">
            Demo report
          </Badge>
          {result.metadata.map((m) => (
            <Badge key={m.label} tone="neutral">
              {m.label}: {m.value}
            </Badge>
          ))}
        </div>

        <div>
          <h3 className="text-[13px] font-semibold text-ink">Summary</h3>
          <p className="mt-2 text-[13.5px] leading-relaxed text-ink-soft text-pretty">
            {result.insight}
          </p>
          <ul className="mt-3 space-y-2">
            {result.insightBullets.map((b) => (
              <li key={b} className="flex gap-2.5 text-[13px] leading-relaxed text-ink-mute">
                <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-brand-400/70" aria-hidden />
                <span className="text-pretty">{b}</span>
              </li>
            ))}
          </ul>
        </div>

        {result.report.map((section) => (
          <div key={section.heading}>
            <h3 className="text-[13px] font-semibold text-ink">{section.heading}</h3>
            <p className="mt-2 text-[13px] leading-relaxed text-ink-mute text-pretty">
              {section.body}
            </p>
          </div>
        ))}

        <p className="rounded-xl border border-edge/70 bg-black/25 px-4 py-3 text-[11.5px] leading-relaxed text-ink-dim">
          {DEMO_DISCLAIMER}
        </p>
      </div>
    </Modal>
  );
}
