import { ArrowUpRight } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { EXAMPLE_LIBRARY } from '@/lib/demoAgent';

export function ExamplesDialog({
  open,
  onClose,
  onPick,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (query: string) => void;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Example questions"
      description="The four headline scenarios have full demo walkthroughs. The rest show how the agent handles variation."
      size="lg"
    >
      <div className="space-y-6">
        {EXAMPLE_LIBRARY.map((group) => (
          <div key={group.group}>
            <p className="mb-2.5 font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink-dim">
              {group.group}
            </p>
            <ul className="space-y-1.5">
              {group.items.map((item, index) => (
                <li key={item}>
                  <button
                    type="button"
                    onClick={() => {
                      onPick(item);
                      onClose();
                    }}
                    className="group flex w-full items-center gap-3 rounded-xl border border-edge/50 bg-panel/40 px-3.5 py-2.5 text-left transition-all duration-200 ease-premium hover:border-brand-500/30 hover:bg-panel-raised/60"
                  >
                    <span className="flex-1 text-[13px] text-ink-mute group-hover:text-ink-soft">
                      {item}
                    </span>
                    {index === 0 && (
                      <span className="shrink-0 rounded border border-brand-500/25 bg-brand-500/[0.08] px-1.5 py-0.5 font-mono text-[9.5px] uppercase tracking-wider text-brand-300">
                        Full demo
                      </span>
                    )}
                    <ArrowUpRight className="h-3.5 w-3.5 shrink-0 text-ink-faint transition-all duration-200 ease-premium group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-brand-300" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Modal>
  );
}
