import { Suspense, lazy, useMemo, useState } from 'react';
import {
  Bookmark,
  Clock,
  Database,
  Download,
  FileSearch,
  Layers,
  Lightbulb,
  Maximize2,
  Minimize2,
  Satellite,
  Sigma,
  TriangleAlert,
  X,
} from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button, IconButton } from '@/components/ui/Button';
import { Tooltip } from '@/components/ui/Tooltip';
import type { AgentResponse, Evidence, EvidenceKind } from '@/lib/contract';
import { cn } from '@/lib/utils';
import { useWorkspace } from '@/state/WorkspaceContext';
// Mapbox GL is ~1.5 MB; it loads only when a result actually needs a map.
const MapboxView = lazy(() =>
  import('./MapboxView').then((m) => ({ default: m.MapboxView })),
);

/**
 * The live result panel.
 *
 * Every value on this screen came from the backend response for the current
 * run. Where the backend returned nothing, the section shows an explicit empty
 * or error state — there is no fallback content and no placeholder number.
 */

const EVIDENCE_LABEL: Record<EvidenceKind, string> = {
  observation: 'What the satellite data shows',
  computation: 'What was calculated',
  inference: 'What the model inferred',
  uncertainty: 'What remains uncertain',
  source: 'Sources',
};

const EVIDENCE_ORDER: EvidenceKind[] = [
  'observation',
  'computation',
  'inference',
  'uncertainty',
  'source',
];

function Section({
  icon,
  title,
  badge,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  badge?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-edge/60 bg-panel/40 p-4">
      <div className="mb-3 flex items-center gap-2.5">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-500/[0.1] text-brand-300">
          {icon}
        </span>
        <h3 className="flex-1 text-[13px] font-semibold text-ink">{title}</h3>
        {badge}
      </div>
      {children}
    </section>
  );
}

function EmptyLine({ children }: { children: React.ReactNode }) {
  return <p className="text-[12.5px] leading-relaxed text-ink-dim">{children}</p>;
}

export function LiveResultPanel({
  response,
  onClose,
  className,
}: {
  response: AgentResponse;
  onClose?: () => void;
  className?: string;
}) {
  const { state, dispatch, saveCurrentResult } = useWorkspace();
  const [evidenceOpen, setEvidenceOpen] = useState(false);

  const analysis = response.analysis;
  const map = response.map;
  const statistics = response.workspace.statistics;
  const timeline = response.workspace.timeline;

  const evidenceByKind = useMemo(() => {
    const grouped = new Map<EvidenceKind, Evidence[]>();
    for (const item of response.evidence) {
      const list = grouped.get(item.kind) ?? [];
      list.push(item);
      grouped.set(item.kind, list);
    }
    return grouped;
  }, [response.evidence]);

  const download = () => {
    const blob = new Blob([JSON.stringify(response, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `satquery-${response.runId.slice(0, 8)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const statusTone =
    analysis?.status === 'completed'
      ? 'brand'
      : analysis?.status === 'partial'
        ? 'amber'
        : analysis?.status === 'error' || analysis?.status === 'no_data'
          ? 'red'
          : 'neutral';

  return (
    <section aria-label="Analysis result" className={cn('flex min-h-0 flex-col bg-panel/25', className)}>
      <header className="flex h-[52px] shrink-0 items-center gap-2 border-b border-edge/60 px-3.5">
        <h2 className="text-[13.5px] font-semibold text-ink">Result</h2>
        {analysis && (
          <Badge tone={statusTone} className="font-mono uppercase tracking-wider">
            {analysis.status.replace(/_/g, ' ')}
          </Badge>
        )}

        <div className="ml-auto flex items-center gap-0.5">
          <Tooltip label="Download the full response">
            <IconButton label="Download" size="sm" onClick={download}>
              <Download className="h-4 w-4" strokeWidth={1.8} />
            </IconButton>
          </Tooltip>
          <Tooltip label="Save this analysis">
            <IconButton label="Save" size="sm" onClick={saveCurrentResult}>
              <Bookmark className="h-4 w-4" strokeWidth={1.8} />
            </IconButton>
          </Tooltip>
          <Tooltip label={state.fullscreen ? 'Exit fullscreen' : 'Fullscreen'}>
            <IconButton
              label={state.fullscreen ? 'Exit fullscreen' : 'Fullscreen'}
              size="sm"
              onClick={() => dispatch({ type: 'set-fullscreen', on: !state.fullscreen })}
            >
              {state.fullscreen ? (
                <Minimize2 className="h-4 w-4" strokeWidth={1.8} />
              ) : (
                <Maximize2 className="h-4 w-4" strokeWidth={1.8} />
              )}
            </IconButton>
          </Tooltip>
          {onClose && (
            <IconButton label="Close result panel" size="sm" onClick={onClose} className="xl:hidden">
              <X className="h-4 w-4" />
            </IconButton>
          )}
        </div>
      </header>

      <div className="sq-scroll min-h-0 flex-1 space-y-4 overflow-y-auto px-3.5 py-4">
        {/* Query summary — resolved intent, place, extent, period */}
        <div>
          <h3 className="text-[14.5px] font-semibold tracking-[-0.01em] text-ink">
            {response.query.location?.placeName ?? 'Area of interest'}
          </h3>
          <dl className="mt-3 grid grid-cols-2 gap-2">
            {[
              ['Intent', response.query.intent.replace(/_/g, ' ')],
              ['Method', response.query.requestedAnalysis.replace(/_/g, ' ')],
              [
                'Period',
                response.query.dateRange
                  ? `${response.query.dateRange.from} → ${response.query.dateRange.to}`
                  : 'Not resolved',
              ],
              [
                'Extent',
                response.query.location
                  ? response.query.location.bbox.map((v) => v.toFixed(2)).join(', ')
                  : 'Not resolved',
              ],
            ].map(([label, value]) => (
              <div key={label} className="rounded-xl border border-edge/60 bg-panel/40 px-3 py-2">
                <dt className="text-[10px] uppercase tracking-wider text-ink-faint">{label}</dt>
                <dd className="mt-0.5 break-words text-[12px] font-medium capitalize text-ink-soft">
                  {value}
                </dd>
              </div>
            ))}
          </dl>
        </div>

        {/* Map */}
        {map ? (
          <Suspense
            fallback={
              <div
                className={cn(
                  'sq-skeleton rounded-xl',
                  state.fullscreen ? 'h-[58vh]' : 'aspect-[4/3] xl:aspect-[5/4]',
                )}
              />
            }
          >
            <MapboxView
              mapState={map}
              fullscreen={state.fullscreen}
              onToggleFullscreen={() => dispatch({ type: 'set-fullscreen', on: !state.fullscreen })}
              className={state.fullscreen ? 'h-[58vh]' : 'aspect-[4/3] xl:aspect-[5/4]'}
            />
          </Suspense>
        ) : (
          <div className="rounded-xl border border-edge/60 bg-panel/40 p-5 text-center">
            <EmptyLine>
              No map was produced for this query. The agent did not reach the map stage.
            </EmptyLine>
          </div>
        )}

        {/* Legend — mirrors the measured classes exactly */}
        {map?.legend.map((legend) => (
          <div key={legend.id} className="rounded-2xl border border-edge/60 bg-panel/40 p-4">
            <p className="mb-2.5 text-[12px] font-semibold text-ink">{legend.title}</p>
            <ul className="space-y-1.5">
              {legend.entries.map((entry) => (
                <li key={entry.label} className="flex items-center gap-2.5">
                  <span
                    className="h-2.5 w-2.5 shrink-0 rounded-[3px]"
                    style={{ backgroundColor: entry.color }}
                  />
                  <span className="flex-1 truncate text-[12px] text-ink-mute">{entry.label}</span>
                  {entry.areaKm2 !== undefined && (
                    <span className="font-mono text-[11px] text-ink-soft">
                      {entry.areaKm2} km²
                      {entry.fraction !== undefined && (
                        <span className="ml-1.5 text-ink-dim">
                          {(entry.fraction * 100).toFixed(1)}%
                        </span>
                      )}
                    </span>
                  )}
                </li>
              ))}
            </ul>
            {legend.note && <p className="mt-2.5 text-[11px] text-ink-faint">{legend.note}</p>}
          </div>
        ))}

        {/* Imagery metadata */}
        {map && map.imagery.length > 0 && (
          <Section icon={<Satellite className="h-3.5 w-3.5" strokeWidth={1.8} />} title="Imagery">
            <ul className="space-y-2">
              {map.imagery.map((img) => (
                <li key={img.id} className="rounded-xl border border-edge/50 bg-black/20 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[12.5px] font-medium text-ink">{img.label}</span>
                    <Badge tone="neutral" className="font-mono uppercase">
                      {img.epoch}
                    </Badge>
                  </div>
                  <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[11px]">
                    <div className="flex gap-1.5">
                      <dt className="text-ink-faint">Source</dt>
                      <dd className="text-ink-mute">{img.source}</dd>
                    </div>
                    <div className="flex gap-1.5">
                      <dt className="text-ink-faint">Resolution</dt>
                      <dd className="text-ink-mute">{img.resolution ?? 'n/a'}</dd>
                    </div>
                    <div className="flex gap-1.5">
                      <dt className="text-ink-faint">Acquired</dt>
                      <dd className="text-ink-mute">
                        {img.acquisitionDate ? img.acquisitionDate.slice(0, 10) : 'composite'}
                      </dd>
                    </div>
                    <div className="flex gap-1.5">
                      <dt className="text-ink-faint">Cloud</dt>
                      <dd className="text-ink-mute">
                        {img.cloudCover !== undefined ? `${img.cloudCover}%` : 'not reported'}
                      </dd>
                    </div>
                  </dl>
                  {img.sceneIds.length > 0 && (
                    <p className="mt-2 truncate font-mono text-[10px] text-ink-faint" title={img.sceneIds.join(', ')}>
                      {img.sceneIds[0]}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          </Section>
        )}

        {/* Statistics — real values only */}
        <Section
          icon={<Sigma className="h-3.5 w-3.5" strokeWidth={1.8} />}
          title="Statistics"
          badge={
            analysis && (
              <Badge tone="neutral" className="font-mono text-[9.5px] uppercase">
                {analysis.computedBy.includes('Statistics API') ? 'measured' : 'not computed'}
              </Badge>
            )
          }
        >
          {statistics.length > 0 ? (
            <ul className="space-y-2">
              {statistics.map((stat) => (
                <li
                  key={`${stat.label}-${stat.epoch}`}
                  className="flex items-baseline justify-between gap-3 rounded-lg border border-edge/50 bg-black/20 px-3 py-2"
                >
                  <span className="min-w-0 flex-1 truncate text-[12px] text-ink-mute">{stat.label}</span>
                  <span className="font-mono text-[12px] text-ink">{stat.mean ?? '—'}</span>
                  {stat.sampleCoverage !== undefined && (
                    <span className="font-mono text-[10px] text-ink-faint">
                      {Math.round(stat.sampleCoverage * 100)}% valid
                    </span>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <EmptyLine>
              {analysis?.message ??
                'No statistics were computed for this query.'}
            </EmptyLine>
          )}
          {analysis?.analysedAreaKm2 !== undefined && (
            <p className="mt-2.5 text-[11px] text-ink-faint">
              Analysed extent {analysis.analysedAreaKm2} km²
              {analysis.pixelSizeMeters ? ` at ${analysis.pixelSizeMeters} m per pixel` : ''}.
            </p>
          )}
        </Section>

        {/* Datasets discovered */}
        <Section icon={<Database className="h-3.5 w-3.5" strokeWidth={1.8} />} title="Datasets">
          {response.datasets.length > 0 ? (
            <ul className="space-y-2">
              {response.datasets.map((dataset) => (
                <li key={dataset.id} className="rounded-xl border border-edge/50 bg-black/20 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[12.5px] font-medium text-ink">{dataset.name}</span>
                    <Badge
                      tone={
                        dataset.status === 'available'
                          ? 'brand'
                          : dataset.status === 'error'
                            ? 'red'
                            : 'neutral'
                      }
                    >
                      {dataset.status === 'available'
                        ? `${dataset.matchCount} products`
                        : dataset.status.replace('_', ' ')}
                    </Badge>
                  </div>
                  <p className="mt-1 text-[11.5px] text-ink-dim">
                    {dataset.provider} · {dataset.purpose}
                  </p>
                  {dataset.indices.length > 0 && (
                    <p className="mt-1.5 font-mono text-[10.5px] text-ink-faint">
                      {dataset.indices.join(' · ')} — {dataset.bands.join(', ')}
                    </p>
                  )}
                  {dataset.message && (
                    <p className="mt-1.5 text-[11px] leading-relaxed text-amber-300/80">
                      {dataset.message}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <EmptyLine>No catalogue search ran for this query.</EmptyLine>
          )}
        </Section>

        {/* Timeline of available acquisitions */}
        <Section icon={<Clock className="h-3.5 w-3.5" strokeWidth={1.8} />} title="Timeline">
          {timeline.length > 0 ? (
            <ul className="sq-scroll max-h-52 space-y-1 overflow-y-auto pr-1">
              {timeline.map((entry) => (
                <li
                  key={`${entry.sceneId}-${entry.date}`}
                  className={cn(
                    'flex items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-[11.5px]',
                    entry.epoch ? 'bg-brand-500/[0.07] text-ink-soft' : 'text-ink-dim',
                  )}
                >
                  <span className="font-mono text-[11px]">{entry.date.slice(0, 10)}</span>
                  <span className="flex-1 truncate">{entry.label}</span>
                  {entry.cloudCover !== undefined && (
                    <span className="font-mono text-[10.5px] text-ink-faint">
                      {entry.cloudCover}%
                    </span>
                  )}
                  {entry.epoch && (
                    <Badge tone="brand" className="font-mono text-[9px] uppercase">
                      {entry.epoch}
                    </Badge>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <EmptyLine>No acquisitions were listed for this area and window.</EmptyLine>
          )}
        </Section>

        {/* Insights */}
        <Section icon={<Lightbulb className="h-3.5 w-3.5" strokeWidth={1.8} />} title="Insights">
          {response.workspace.insights.length > 0 ? (
            <ul className="space-y-2.5">
              {response.workspace.insights.map((insight) => (
                <li key={insight.id}>
                  <div className="flex items-center gap-2">
                    <span className="text-[12.5px] font-medium text-ink">{insight.title}</span>
                    <Badge
                      tone={insight.basis === 'measured' ? 'brand' : 'neutral'}
                      className="font-mono text-[9px] uppercase"
                    >
                      {insight.basis}
                    </Badge>
                  </div>
                  <p className="mt-1 text-[12px] leading-relaxed text-ink-mute">{insight.body}</p>
                </li>
              ))}
            </ul>
          ) : (
            <EmptyLine>No insights were produced for this run.</EmptyLine>
          )}
        </Section>

        {/* Warnings */}
        {response.warnings.length > 0 && (
          <section className="rounded-2xl border border-amber-400/25 bg-amber-400/[0.05] p-4">
            <div className="mb-2 flex items-center gap-2">
              <TriangleAlert className="h-4 w-4 text-amber-300" />
              <h3 className="text-[13px] font-semibold text-ink">Caveats</h3>
            </div>
            <ul className="space-y-1.5">
              {response.warnings.map((warning) => (
                <li key={warning} className="text-[12px] leading-relaxed text-amber-100/85">
                  {warning}
                </li>
              ))}
            </ul>
          </section>
        )}

        {/* Evidence */}
        <Section icon={<FileSearch className="h-3.5 w-3.5" strokeWidth={1.8} />} title="Evidence">
          {response.evidence.length > 0 ? (
            <>
              <p className="text-[12px] text-ink-mute">
                {response.evidence.length} entries, separated by what they are.
              </p>
              <Button
                variant="secondary"
                size="sm"
                className="mt-3"
                onClick={() => setEvidenceOpen((v) => !v)}
              >
                {evidenceOpen ? 'Hide evidence' : 'Show evidence'}
              </Button>

              {evidenceOpen && (
                <div className="mt-3 space-y-4">
                  {EVIDENCE_ORDER.filter((kind) => evidenceByKind.has(kind)).map((kind) => (
                    <div key={kind}>
                      <p className="mb-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-faint">
                        {EVIDENCE_LABEL[kind]}
                      </p>
                      <ul className="space-y-2">
                        {evidenceByKind.get(kind)!.map((item) => (
                          <li key={item.id} className="rounded-lg border border-edge/50 bg-black/20 p-2.5">
                            <p className="text-[12px] font-medium text-ink-soft">{item.title}</p>
                            <p className="mt-1 text-[11.5px] leading-relaxed text-ink-mute">
                              {item.body}
                            </p>
                            <p className="mt-1.5 text-[10.5px] text-ink-faint">{item.origin}</p>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              )}
            </>
          ) : (
            <EmptyLine>No evidence was recorded for this run.</EmptyLine>
          )}
        </Section>

        {/* Agent steps */}
        <Section icon={<Layers className="h-3.5 w-3.5" strokeWidth={1.8} />} title="Agent execution">
          <ul className="space-y-1.5">
            {response.agentSteps.map((agentStep, index) => (
              <li
                key={`${agentStep.node}-${index}`}
                className="rounded-lg border border-edge/50 bg-black/20 px-2.5 py-2"
              >
                <div className="flex items-center gap-2">
                  <span className="flex-1 truncate text-[12px] text-ink-soft">{agentStep.label}</span>
                  <Badge
                    tone={
                      agentStep.status === 'completed'
                        ? 'brand'
                        : agentStep.status === 'failed'
                          ? 'red'
                          : 'neutral'
                    }
                    className="font-mono text-[9px] uppercase"
                  >
                    {agentStep.status}
                  </Badge>
                  {agentStep.durationMs !== undefined && (
                    <span className="font-mono text-[10px] text-ink-faint">
                      {agentStep.durationMs}ms
                    </span>
                  )}
                </div>
                {(agentStep.detail || agentStep.error) && (
                  <p className="mt-1 text-[11px] leading-relaxed text-ink-dim">
                    {agentStep.error ?? agentStep.detail}
                  </p>
                )}
              </li>
            ))}
          </ul>
          {response.traceUrl && (
            <a
              href={response.traceUrl}
              target="_blank"
              rel="noreferrer"
              className="mt-3 inline-block text-[11.5px] text-brand-300 hover:text-brand-200"
            >
              Open the LangSmith trace →
            </a>
          )}
        </Section>

        <p className="pb-2 font-mono text-[10px] text-ink-faint">
          run {response.runId.slice(0, 8)} · {response.durationMs}ms ·{' '}
          {response.map?.attribution.join(' · ') ?? 'no imagery'}
        </p>
      </div>
    </section>
  );
}
