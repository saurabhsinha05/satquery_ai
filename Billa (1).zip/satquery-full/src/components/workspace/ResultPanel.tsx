import { useEffect, useRef, useState } from 'react';
import { Bookmark, Download, Maximize2, Minimize2, MoreVertical, RotateCcw, X } from 'lucide-react';
import { DemoBadge } from '@/components/ui/Badge';
import { IconButton } from '@/components/ui/Button';
import { Skeleton } from '@/components/ui/Skeleton';
import { Tooltip } from '@/components/ui/Tooltip';
import { DEMO_DISCLAIMER } from '@/lib/demoAgent';
import type { AnalysisResult } from '@/lib/types';
import { cn } from '@/lib/utils';
import { useWorkspace } from '@/state/WorkspaceContext';
import { INITIAL_MAP_STATE } from '@/state/workspaceReducer';
import { InsightsPanel } from './InsightsPanel';
import { LayerControl } from './LayerControl';
import { Legend } from './Legend';
import { MapView } from './MapView';
import { MetadataGrid } from './MetadataGrid';

function buildExport(result: AnalysisResult): string {
  return JSON.stringify(
    {
      _notice: DEMO_DISCLAIMER,
      title: result.title,
      area: result.place,
      period: result.period,
      index: result.metadata.find((m) => m.label === 'Primary Index')?.value,
      parameters: Object.fromEntries(result.metadata.map((m) => [m.label, m.value])),
      layers: result.layers.map((l) => ({ name: l.name, visible: l.visible })),
      legend: result.legend,
      insight: result.insight,
      details: result.insightBullets,
      report: result.report,
      generated: new Date().toISOString(),
      source: 'SatQuery AI frontend demo engine (local, no backend)',
    },
    null,
    2,
  );
}

export function ResultPanel({
  onClose,
  className,
}: {
  onClose?: () => void;
  className?: string;
}) {
  const { state, dispatch, saveCurrentResult, showToast } = useWorkspace();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const result = state.result;
  const working = state.agentStatus === 'working' || state.agentStatus === 'thinking';

  useEffect(() => {
    if (!menuOpen) return undefined;
    const onDown = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [menuOpen]);

  if (!result) return null;

  const download = () => {
    const blob = new Blob([buildExport(result)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `satquery-demo-${result.kind}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    showToast('Demo export downloaded (local file)', 'success');
  };

  const toggleFullscreen = () => dispatch({ type: 'set-fullscreen', on: !state.fullscreen });

  return (
    <section
      aria-label="Analysis result"
      className={cn('flex min-h-0 flex-col bg-panel/25', className)}
    >
      {/* Header */}
      <header className="flex h-[52px] shrink-0 items-center gap-2 border-b border-edge/60 px-3.5">
        <h2 className="text-[13.5px] font-semibold text-ink">Result</h2>
        <DemoBadge />

        <div className="ml-auto flex items-center gap-0.5">
          <Tooltip label="Download demo export">
            <IconButton label="Download" size="sm" onClick={download}>
              <Download className="h-4 w-4" strokeWidth={1.8} />
            </IconButton>
          </Tooltip>

          <Tooltip label={state.fullscreen ? 'Exit fullscreen' : 'Fullscreen'}>
            <IconButton
              label={state.fullscreen ? 'Exit fullscreen' : 'Fullscreen'}
              size="sm"
              onClick={toggleFullscreen}
            >
              {state.fullscreen ? (
                <Minimize2 className="h-4 w-4" strokeWidth={1.8} />
              ) : (
                <Maximize2 className="h-4 w-4" strokeWidth={1.8} />
              )}
            </IconButton>
          </Tooltip>

          <div className="relative" ref={menuRef}>
            <IconButton
              label="More actions"
              size="sm"
              active={menuOpen}
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen((v) => !v)}
            >
              <MoreVertical className="h-4 w-4" strokeWidth={1.8} />
            </IconButton>

            {menuOpen && (
              <div className="absolute right-0 top-[calc(100%+6px)] z-40 w-52 overflow-hidden rounded-xl border border-edge-strong/60 bg-[#0A1720]/97 p-1.5 shadow-lift backdrop-blur-xl animate-scale-in">
                <button
                  type="button"
                  onClick={() => {
                    saveCurrentResult();
                    setMenuOpen(false);
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12.5px] text-ink-mute transition-colors hover:bg-white/[0.05] hover:text-ink"
                >
                  <Bookmark className="h-3.5 w-3.5" />
                  Save to Saved Results
                </button>
                <button
                  type="button"
                  onClick={() => {
                    dispatch({ type: 'set-map', patch: INITIAL_MAP_STATE });
                    setMenuOpen(false);
                    showToast('Map view reset', 'info');
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12.5px] text-ink-mute transition-colors hover:bg-white/[0.05] hover:text-ink"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  Reset map view
                </button>
                <button
                  type="button"
                  onClick={() => {
                    dispatch({ type: 'set-report', on: true });
                    setMenuOpen(false);
                  }}
                  className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[12.5px] text-ink-mute transition-colors hover:bg-white/[0.05] hover:text-ink"
                >
                  <Download className="h-3.5 w-3.5 opacity-0" aria-hidden />
                  View full report
                </button>
              </div>
            )}
          </div>

          {onClose && (
            <IconButton label="Close result panel" size="sm" onClick={onClose} className="xl:hidden">
              <X className="h-4 w-4" />
            </IconButton>
          )}
        </div>
      </header>

      {/* Body */}
      <div className="sq-scroll min-h-0 flex-1 space-y-5 overflow-y-auto px-3.5 py-4">
        <div className="animate-fade-up">
          <h3 className="text-[14.5px] font-semibold tracking-[-0.01em] text-ink">{result.title}</h3>
        </div>

        <div className="relative animate-fade-up [animation-delay:60ms]">
          <MapView
            result={result}
            mapState={state.mapState}
            fullscreen={state.fullscreen}
            onToggleFullscreen={toggleFullscreen}
            className={cn(state.fullscreen ? 'h-[62vh]' : 'aspect-[4/3] xl:aspect-[5/4]')}
          />
          {working && (
            <div className="pointer-events-none absolute inset-0 overflow-hidden rounded-xl">
              <span className="absolute inset-x-0 h-24 bg-gradient-to-b from-transparent via-brand-400/[0.09] to-transparent animate-sweep-y" />
              <span className="absolute inset-x-0 top-3 mx-auto w-fit rounded-md border border-brand-500/25 bg-black/70 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-brand-300 backdrop-blur">
                Rendering…
              </span>
            </div>
          )}
        </div>

        <div className="animate-fade-up [animation-delay:100ms]">
          <Legend entries={result.legend} />
        </div>

        {working ? (
          <div className="grid grid-cols-2 gap-2 xl:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="rounded-xl border border-edge/60 bg-panel/40 px-3 py-2.5">
                <Skeleton className="h-2.5 w-16" />
                <Skeleton className="mt-2 h-3 w-12" />
              </div>
            ))}
          </div>
        ) : (
          <div className="animate-fade-up [animation-delay:140ms]">
            <MetadataGrid entries={result.metadata} />
          </div>
        )}

        <div className="animate-fade-up [animation-delay:180ms]">
          <LayerControl
            layers={result.layers}
            onToggle={(id) => dispatch({ type: 'toggle-layer', layerId: id })}
            onIsolate={(id) =>
              result.layers.forEach((l) =>
                dispatch({ type: 'toggle-layer', layerId: l.id, visible: l.id === id }),
              )
            }
            onShowAll={() =>
              result.layers.forEach((l) =>
                dispatch({ type: 'toggle-layer', layerId: l.id, visible: true }),
              )
            }
          />
        </div>

        {working ? (
          <div className="rounded-2xl border border-edge/60 bg-panel/40 p-4">
            <Skeleton className="h-3 w-24" />
            <Skeleton className="mt-3.5 h-3 w-full" />
            <Skeleton className="mt-2 h-3 w-5/6" />
          </div>
        ) : (
          <div className="animate-fade-up [animation-delay:220ms]">
            <InsightsPanel result={result} onOpenReport={() => dispatch({ type: 'set-report', on: true })} />
          </div>
        )}

        <p className="pb-2 text-[10.5px] leading-relaxed text-ink-faint">{DEMO_DISCLAIMER}</p>
      </div>
    </section>
  );
}
