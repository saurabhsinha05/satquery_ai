import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import {
  Eye,
  EyeOff,
  Layers,
  Maximize2,
  Minimize2,
  Minus,
  MoveHorizontal,
  Plus,
  RotateCcw,
  TriangleAlert,
} from 'lucide-react';
import { IconButton } from '@/components/ui/Button';
import { Tooltip } from '@/components/ui/Tooltip';
import { imageryUrl } from '@/lib/api';
import { MAPBOX_TOKEN, hasMapbox } from '@/lib/config';
import type { MapImagery, MapState } from '@/lib/contract';
import { cn } from '@/lib/utils';

/**
 * The real map.
 *
 * Two synchronised Mapbox instances with a draggable divider. Both are driven
 * from the same `MapState` the backend returned, and every raster is added as
 * an `image` source pinned to the exact bounding-box corners the backend
 * rendered it for — so a before/after pair is geographically identical by
 * construction. There is no code path that displays imagery for one extent
 * next to imagery for another.
 */

const BASE_STYLES = {
  satellite: 'mapbox://styles/mapbox/satellite-streets-v12',
  dark: 'mapbox://styles/mapbox/dark-v11',
} as const;

type BaseStyle = keyof typeof BASE_STYLES;

function cornersOf(bbox: [number, number, number, number]): [
  [number, number],
  [number, number],
  [number, number],
  [number, number],
] {
  const [w, s, e, n] = bbox;
  // Mapbox image coordinates: top-left, top-right, bottom-right, bottom-left.
  return [
    [w, n],
    [e, n],
    [e, s],
    [w, s],
  ];
}

interface RasterSpec {
  id: string;
  url: string;
  bbox: [number, number, number, number];
  opacity: number;
  visible: boolean;
}

/** Adds/updates image sources on one map instance. */
function syncRasters(map: mapboxgl.Map, rasters: RasterSpec[]): void {
  if (!map.isStyleLoaded()) return;

  const wanted = new Set(rasters.map((r) => `sq-${r.id}`));

  // Remove layers this map no longer needs.
  for (const layer of map.getStyle()?.layers ?? []) {
    if (layer.id.startsWith('sq-') && !wanted.has(layer.id)) {
      if (map.getLayer(layer.id)) map.removeLayer(layer.id);
      if (map.getSource(layer.id)) map.removeSource(layer.id);
    }
  }

  for (const raster of rasters) {
    const id = `sq-${raster.id}`;
    const existing = map.getSource(id) as mapboxgl.ImageSource | undefined;
    if (existing) {
      existing.updateImage({ url: raster.url, coordinates: cornersOf(raster.bbox) });
    } else {
      map.addSource(id, {
        type: 'image',
        url: raster.url,
        coordinates: cornersOf(raster.bbox),
      });
      map.addLayer({
        id,
        type: 'raster',
        source: id,
        paint: { 'raster-opacity': raster.opacity, 'raster-fade-duration': 220 },
      });
    }
    if (map.getLayer(id)) {
      map.setPaintProperty(id, 'raster-opacity', raster.visible ? raster.opacity : 0);
      map.setLayoutProperty(id, 'visibility', raster.visible ? 'visible' : 'none');
    }
  }
}

function syncVectors(map: mapboxgl.Map, mapState: MapState): void {
  if (!map.isStyleLoaded()) return;

  for (const boundary of mapState.boundaries) {
    const id = `sq-boundary-${boundary.id}`;
    const data = boundary.geojson as GeoJSON.Feature;
    const existing = map.getSource(id) as mapboxgl.GeoJSONSource | undefined;
    if (existing) {
      existing.setData(data);
    } else {
      map.addSource(id, { type: 'geojson', data });
      map.addLayer({
        id: `${id}-fill`,
        type: 'fill',
        source: id,
        paint: { 'fill-color': boundary.color, 'fill-opacity': 0.05 },
      });
      map.addLayer({
        id: `${id}-line`,
        type: 'line',
        source: id,
        paint: {
          'line-color': boundary.color,
          'line-width': 1.6,
          'line-dasharray': [3, 2],
          'line-opacity': 0.9,
        },
      });
    }
  }
}

export interface MapboxViewProps {
  mapState: MapState;
  className?: string;
  fullscreen?: boolean;
  onToggleFullscreen?: () => void;
}

export function MapboxView({
  mapState,
  className,
  fullscreen,
  onToggleFullscreen,
}: MapboxViewProps) {
  const beforeRef = useRef<HTMLDivElement>(null);
  const afterRef = useRef<HTMLDivElement>(null);
  const beforeMap = useRef<mapboxgl.Map | null>(null);
  const afterMap = useRef<mapboxgl.Map | null>(null);
  const syncing = useRef(false);
  const dragging = useRef(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  const [ready, setReady] = useState(false);
  const [split, setSplit] = useState(50);
  const [baseStyle, setBaseStyle] = useState<BaseStyle>('satellite');
  const [layerMenu, setLayerMenu] = useState(false);
  const [overlayOpacity, setOverlayOpacity] = useState(0.85);
  const [hidden, setHidden] = useState<Record<string, boolean>>({});
  const [probe, setProbe] = useState<{ lng: number; lat: number } | null>(null);

  const comparison = mapState.comparison.enabled && mapState.imagery.length > 1;
  const before = useMemo<MapImagery | undefined>(
    () => mapState.imagery.find((i) => i.epoch === 'before') ?? mapState.imagery[0],
    [mapState.imagery],
  );
  const after = useMemo<MapImagery | undefined>(
    () => mapState.imagery.find((i) => i.epoch === 'after'),
    [mapState.imagery],
  );

  const isHidden = useCallback((id: string) => Boolean(hidden[id]), [hidden]);

  /* ── Map creation ───────────────────────────────────────────────────────── */

  useEffect(() => {
    if (!hasMapbox() || !beforeRef.current) return undefined;
    mapboxgl.accessToken = MAPBOX_TOKEN;

    const common = {
      style: BASE_STYLES[baseStyle],
      center: mapState.center,
      zoom: mapState.zoom,
      attributionControl: true,
      cooperativeGestures: false,
    } as const;

    const left = new mapboxgl.Map({ container: beforeRef.current, ...common });
    beforeMap.current = left;

    let right: mapboxgl.Map | null = null;
    if (afterRef.current) {
      right = new mapboxgl.Map({ container: afterRef.current, ...common });
      afterMap.current = right;
    }

    // Synchronised cameras — one source of truth, mirrored instantly.
    const link = (a: mapboxgl.Map, b: mapboxgl.Map | null) => {
      if (!b) return;
      a.on('move', () => {
        if (syncing.current) return;
        syncing.current = true;
        b.jumpTo({
          center: a.getCenter(),
          zoom: a.getZoom(),
          bearing: a.getBearing(),
          pitch: a.getPitch(),
        });
        syncing.current = false;
      });
    };
    link(left, right);
    link(right as mapboxgl.Map, left);

    const onLoad = () => setReady(true);
    left.on('load', onLoad);

    const onClick = (e: mapboxgl.MapMouseEvent) => setProbe({ lng: e.lngLat.lng, lat: e.lngLat.lat });
    left.on('click', onClick);
    right?.on('click', onClick);

    return () => {
      setReady(false);
      left.remove();
      right?.remove();
      beforeMap.current = null;
      afterMap.current = null;
    };
    // Re-creating on style change is the simplest correct way to swap base maps.
  }, [baseStyle, mapState.center, mapState.zoom]);

  /* ── Camera follows the backend's plan ──────────────────────────────────── */

  useEffect(() => {
    if (!ready) return;
    const bounds = mapState.bounds;
    const fit: mapboxgl.LngLatBoundsLike = [
      [bounds[0], bounds[1]],
      [bounds[2], bounds[3]],
    ];
    beforeMap.current?.fitBounds(fit, { padding: 28, duration: 700 });
  }, [ready, mapState.bounds]);

  /* ── Rasters ────────────────────────────────────────────────────────────── */

  useEffect(() => {
    if (!ready) return;

    const overlays: RasterSpec[] = mapState.analysisLayers.map((layer) => ({
      id: layer.id,
      url: imageryUrl(layer.layerUrl ?? ''),
      bbox: layer.bbox,
      opacity: overlayOpacity,
      visible: layer.visible && !isHidden(layer.id),
    }));

    const leftRasters: RasterSpec[] = [];
    if (before) {
      leftRasters.push({
        id: before.id,
        url: imageryUrl(before.layerUrl),
        bbox: before.bbox,
        opacity: 1,
        visible: !isHidden(before.id),
      });
    }
    // Without a comparison the single map carries the overlay too.
    if (!comparison) leftRasters.push(...overlays);

    const rightRasters: RasterSpec[] = [];
    if (after) {
      rightRasters.push({
        id: after.id,
        url: imageryUrl(after.layerUrl),
        bbox: after.bbox,
        opacity: 1,
        visible: !isHidden(after.id),
      });
    }
    rightRasters.push(...overlays);

    const applyLeft = () => {
      if (!beforeMap.current) return;
      syncRasters(beforeMap.current, leftRasters);
      syncVectors(beforeMap.current, mapState);
    };
    const applyRight = () => {
      if (!afterMap.current) return;
      syncRasters(afterMap.current, rightRasters);
      syncVectors(afterMap.current, mapState);
    };

    if (beforeMap.current?.isStyleLoaded()) applyLeft();
    else beforeMap.current?.once('styledata', applyLeft);

    if (afterMap.current?.isStyleLoaded()) applyRight();
    else afterMap.current?.once('styledata', applyRight);
  }, [ready, mapState, before, after, comparison, overlayOpacity, isHidden]);

  /* ── Divider drag ───────────────────────────────────────────────────────── */

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      if (!dragging.current || !wrapRef.current) return;
      const rect = wrapRef.current.getBoundingClientRect();
      const pct = ((e.clientX - rect.left) / rect.width) * 100;
      setSplit(Math.max(4, Math.min(96, pct)));
    };
    const onUp = () => {
      dragging.current = false;
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
  }, []);

  const resetView = () => {
    const bounds = mapState.bounds;
    beforeMap.current?.fitBounds(
      [
        [bounds[0], bounds[1]],
        [bounds[2], bounds[3]],
      ],
      { padding: 28, duration: 600 },
    );
    setSplit(50);
  };

  /* ── Missing token: a clear configuration error, not a fake map ─────────── */

  if (!hasMapbox()) {
    return (
      <div
        className={cn(
          'flex flex-col items-center justify-center rounded-xl border border-amber-400/25 bg-amber-400/[0.05] p-6 text-center',
          className,
        )}
      >
        <TriangleAlert className="h-5 w-5 text-amber-300" />
        <p className="mt-3 text-[13px] font-medium text-ink">Map cannot be displayed</p>
        <p className="mt-1.5 max-w-sm text-[12.5px] leading-relaxed text-ink-mute">
          <code className="font-mono text-[11.5px] text-amber-200">VITE_MAPBOX_ACCESS_TOKEN</code>{' '}
          is not set, so Mapbox GL cannot initialise. The analysis below is unaffected.
        </p>
      </div>
    );
  }

  if (mapState.error) {
    return (
      <div
        className={cn(
          'flex flex-col items-center justify-center rounded-xl border border-amber-400/25 bg-amber-400/[0.05] p-6 text-center',
          className,
        )}
      >
        <TriangleAlert className="h-5 w-5 text-amber-300" />
        <p className="mt-3 text-[13px] font-medium text-ink">No imagery available</p>
        <p className="mt-1.5 max-w-sm text-[12.5px] leading-relaxed text-ink-mute">{mapState.error}</p>
      </div>
    );
  }

  const toggleLayer = (id: string) => setHidden((h) => ({ ...h, [id]: !h[id] }));

  return (
    <div
      ref={wrapRef}
      className={cn('group relative overflow-hidden rounded-xl border border-edge/70 bg-[#04090D]', className)}
    >
      {/* Before / single */}
      <div ref={beforeRef} className="absolute inset-0" />

      {/* After, clipped by the divider */}
      {comparison && (
        <div
          ref={afterRef}
          className="absolute inset-0"
          style={{ clipPath: `inset(0 0 0 ${split}%)` }}
        />
      )}

      {/* Divider */}
      {comparison && (
        <>
          <div
            className="pointer-events-none absolute inset-y-0 z-20 w-px bg-white/70 shadow-[0_0_12px_rgba(255,255,255,0.5)]"
            style={{ left: `${split}%` }}
          />
          <button
            type="button"
            aria-label="Drag to compare before and after"
            onPointerDown={(e) => {
              e.preventDefault();
              dragging.current = true;
            }}
            className="absolute top-1/2 z-30 -translate-x-1/2 -translate-y-1/2 cursor-ew-resize rounded-full border border-white/40 bg-[#0A1720]/95 p-2 text-ink shadow-lift backdrop-blur"
            style={{ left: `${split}%` }}
          >
            <MoveHorizontal className="h-4 w-4" />
          </button>
          <span
            className="pointer-events-none absolute left-3 top-3 z-20 rounded-md border border-edge-strong/50 bg-black/65 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-soft backdrop-blur"
          >
            {mapState.comparison.beforeLabel}
          </span>
          <span
            className="pointer-events-none absolute right-3 top-3 z-20 rounded-md border border-edge-strong/50 bg-black/65 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-soft backdrop-blur"
          >
            {mapState.comparison.afterLabel}
          </span>
        </>
      )}

      {!comparison && before && (
        <span className="pointer-events-none absolute left-3 top-3 z-20 rounded-md border border-edge-strong/50 bg-black/65 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-soft backdrop-blur">
          {before.label} · {before.source}
        </span>
      )}

      {/* Controls */}
      <div className="absolute right-2.5 top-2.5 z-30 flex flex-col items-end gap-1.5">
        {mapState.controls.layerToggle && (
          <div className="relative">
            <IconButton
              label="Layers"
              size="sm"
              active={layerMenu}
              onClick={() => setLayerMenu((v) => !v)}
              className="border border-edge-strong/50 bg-black/70 backdrop-blur hover:bg-black/85"
            >
              <Layers className="h-3.5 w-3.5" />
            </IconButton>

            {layerMenu && (
              <div className="absolute right-0 top-[calc(100%+6px)] z-40 w-64 overflow-hidden rounded-xl border border-edge-strong/60 bg-[#0A1720]/97 shadow-lift backdrop-blur-xl">
                <p className="border-b border-edge/60 px-3 py-2 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-dim">
                  Layers
                </p>
                <ul className="p-1.5">
                  {[...mapState.imagery, ...mapState.analysisLayers].map((layer) => {
                    const id = layer.id;
                    const label = 'label' in layer ? layer.label : id;
                    const visible = !isHidden(id);
                    return (
                      <li key={id}>
                        <button
                          type="button"
                          onClick={() => toggleLayer(id)}
                          aria-pressed={visible}
                          className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[12px] text-ink-mute transition-colors hover:bg-white/[0.05] hover:text-ink"
                        >
                          {visible ? (
                            <Eye className="h-3.5 w-3.5 shrink-0 text-brand-300" />
                          ) : (
                            <EyeOff className="h-3.5 w-3.5 shrink-0 text-ink-faint" />
                          )}
                          <span className="truncate">{label}</span>
                        </button>
                      </li>
                    );
                  })}
                </ul>

                {mapState.controls.opacity && mapState.analysisLayers.length > 0 && (
                  <div className="border-t border-edge/60 px-3 py-2.5">
                    <label className="block text-[11px] text-ink-dim" htmlFor="sq-opacity">
                      Overlay opacity — {Math.round(overlayOpacity * 100)}%
                    </label>
                    <input
                      id="sq-opacity"
                      type="range"
                      min={0}
                      max={100}
                      value={Math.round(overlayOpacity * 100)}
                      onChange={(e) => setOverlayOpacity(Number(e.target.value) / 100)}
                      className="mt-2 w-full accent-brand-400"
                    />
                  </div>
                )}

                {mapState.controls.baseMapToggle && (
                  <div className="border-t border-edge/60 p-1.5">
                    {(Object.keys(BASE_STYLES) as BaseStyle[]).map((style) => (
                      <button
                        key={style}
                        type="button"
                        onClick={() => setBaseStyle(style)}
                        className={cn(
                          'block w-full rounded-lg px-2.5 py-1.5 text-left text-[12px] capitalize transition-colors',
                          baseStyle === style
                            ? 'bg-brand-500/12 text-brand-200'
                            : 'text-ink-mute hover:bg-white/[0.05] hover:text-ink',
                        )}
                      >
                        {style} base map
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        <div className="flex flex-col overflow-hidden rounded-lg border border-edge-strong/50 bg-black/70 backdrop-blur">
          <IconButton
            label="Zoom in"
            size="sm"
            onClick={() => beforeMap.current?.zoomIn()}
            className="rounded-none hover:bg-white/10"
          >
            <Plus className="h-3.5 w-3.5" />
          </IconButton>
          <span className="h-px w-full bg-edge/60" aria-hidden />
          <IconButton
            label="Zoom out"
            size="sm"
            onClick={() => beforeMap.current?.zoomOut()}
            className="rounded-none hover:bg-white/10"
          >
            <Minus className="h-3.5 w-3.5" />
          </IconButton>
        </div>

        <Tooltip label="Reset to the analysed area" side="left">
          <IconButton
            label="Reset view"
            size="sm"
            onClick={resetView}
            className="border border-edge-strong/50 bg-black/70 backdrop-blur hover:bg-black/85"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </IconButton>
        </Tooltip>

        {onToggleFullscreen && mapState.controls.fullscreen && (
          <Tooltip label={fullscreen ? 'Exit fullscreen' : 'Fullscreen'} side="left">
            <IconButton
              label={fullscreen ? 'Exit fullscreen' : 'Fullscreen'}
              size="sm"
              onClick={onToggleFullscreen}
              className="border border-edge-strong/50 bg-black/70 backdrop-blur hover:bg-black/85"
            >
              {fullscreen ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
            </IconButton>
          </Tooltip>
        )}
      </div>

      {/* Click read-out — only values the backend actually produced */}
      {probe && (
        <div className="absolute bottom-3 left-3 z-30 max-w-[280px] rounded-xl border border-edge-strong/60 bg-[#0A1720]/95 p-3 shadow-lift backdrop-blur">
          <div className="flex items-start justify-between gap-3">
            <p className="font-mono text-[10.5px] text-ink-dim">
              {probe.lat.toFixed(5)}, {probe.lng.toFixed(5)}
            </p>
            <button
              type="button"
              onClick={() => setProbe(null)}
              className="text-[11px] text-ink-faint hover:text-ink"
            >
              close
            </button>
          </div>
          {mapState.analysisLayers[0] ? (
            <p className="mt-2 text-[11.5px] leading-relaxed text-ink-mute">
              {mapState.analysisLayers[0].description}
            </p>
          ) : (
            <p className="mt-2 text-[11.5px] leading-relaxed text-ink-mute">
              No analysis layer is loaded for this point — this view is imagery only.
            </p>
          )}
          {mapState.legend[0]?.entries.length ? (
            <ul className="mt-2.5 space-y-1">
              {mapState.legend[0].entries.map((entry) => (
                <li key={entry.label} className="flex items-center gap-2 text-[11px] text-ink-mute">
                  <span
                    className="h-2 w-2 shrink-0 rounded-[2px]"
                    style={{ backgroundColor: entry.color }}
                  />
                  <span className="flex-1 truncate">{entry.label}</span>
                  {entry.areaKm2 !== undefined && (
                    <span className="font-mono text-[10.5px] text-ink-dim">{entry.areaKm2} km²</span>
                  )}
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      )}

      <span className="pointer-events-none absolute bottom-1 right-1 z-20 rounded border border-white/[0.07] bg-black/55 px-1.5 py-0.5 font-mono text-[9px] text-ink-faint backdrop-blur">
        {mapState.attribution.join(' · ')}
      </span>
    </div>
  );
}
