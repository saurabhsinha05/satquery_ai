import { useMemo, useState } from 'react';
import { Crosshair, Eye, EyeOff, Layers, Maximize2, Minimize2, Minus, Plus, RotateCcw } from 'lucide-react';
import { SceneCanvas } from '@/components/map/SceneCanvas';
import { IconButton } from '@/components/ui/Button';
import { Tooltip } from '@/components/ui/Tooltip';
import type { AnalysisResult, MapState } from '@/lib/types';
import { clamp, cn } from '@/lib/utils';
import { useWorkspace } from '@/state/WorkspaceContext';
import { INITIAL_MAP_STATE } from '@/state/workspaceReducer';

function visibilityOf(result: AnalysisResult) {
  const on = (id: string) => result.layers.find((l) => l.id === id)?.visible ?? false;
  return {
    change: on('change'),
    target: on('target'),
    baseline: on('baseline'),
    basemap: on('basemap'),
  };
}

export function MapView({
  result,
  mapState,
  fullscreen,
  onToggleFullscreen,
  className,
}: {
  result: AnalysisResult;
  mapState: MapState;
  fullscreen?: boolean;
  onToggleFullscreen?: () => void;
  className?: string;
}) {
  const { dispatch } = useWorkspace();
  const [layerMenu, setLayerMenu] = useState(false);

  const visibility = useMemo(() => visibilityOf(result), [result]);

  const setZoom = (next: number) =>
    dispatch({ type: 'set-map', patch: { zoom: clamp(next, 1, 6) } });

  const scaleLabel = useMemo(() => {
    // Purely illustrative — the scene has no geodetic basis.
    const km = Math.round((28 / mapState.zoom) * 10) / 10;
    return km >= 1 ? `${km} km` : `${Math.round(km * 1000)} m`;
  }, [mapState.zoom]);

  return (
    <div
      className={cn(
        'group relative overflow-hidden rounded-xl border border-edge/70 bg-[#04090D]',
        className,
      )}
    >
      <SceneCanvas
        seed={result.seed}
        kind={result.kind}
        palette={result.palette}
        visibility={visibility}
        mapState={mapState}
        interactive
        ariaLabel={`${result.title} — illustrative demo visualization, not real satellite imagery`}
        onCameraChange={(patch) => dispatch({ type: 'set-map', patch })}
      />

      {/* Corner reticles */}
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        {[
          'left-2 top-2 border-l border-t',
          'right-2 top-2 border-r border-t',
          'left-2 bottom-2 border-b border-l',
          'right-2 bottom-2 border-b border-r',
        ].map((pos) => (
          <span key={pos} className={cn('absolute h-3.5 w-3.5 border-white/15', pos)} />
        ))}
      </div>

      {/* Context label */}
      <div className="pointer-events-none absolute left-3 top-3 flex flex-col gap-1.5">
        <span className="inline-flex w-fit items-center gap-1.5 rounded-md border border-edge-strong/50 bg-black/55 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-mute backdrop-blur">
          <Crosshair className="h-2.5 w-2.5" />
          {result.place}
        </span>
        {mapState.highOnly && (
          <span className="inline-flex w-fit items-center rounded-md border border-heat-high/30 bg-black/55 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-heat-high backdrop-blur">
            High class only
          </span>
        )}
        {mapState.baselineYear && (
          <span className="inline-flex w-fit items-center rounded-md border border-edge-strong/50 bg-black/55 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-mute backdrop-blur">
            + {mapState.baselineYear} baseline
          </span>
        )}
      </div>

      {/* Controls */}
      <div className="absolute right-2.5 top-2.5 flex flex-col items-end gap-1.5">
        <div className="relative">
          <IconButton
            label="Layers"
            size="sm"
            active={layerMenu}
            onClick={() => setLayerMenu((v) => !v)}
            className="border border-edge-strong/50 bg-black/60 backdrop-blur hover:bg-black/75"
          >
            <Layers className="h-3.5 w-3.5" />
          </IconButton>

          {layerMenu && (
            <div className="absolute right-0 top-[calc(100%+6px)] z-20 w-56 overflow-hidden rounded-xl border border-edge-strong/60 bg-[#0A1720]/96 shadow-lift backdrop-blur-xl animate-scale-in">
              <p className="border-b border-edge/60 px-3 py-2 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-dim">
                Layers
              </p>
              <ul className="p-1.5">
                {result.layers.map((layer) => (
                  <li key={layer.id}>
                    <button
                      type="button"
                      onClick={() => dispatch({ type: 'toggle-layer', layerId: layer.id })}
                      aria-pressed={layer.visible}
                      className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left text-[12px] text-ink-mute transition-colors hover:bg-white/[0.05] hover:text-ink"
                    >
                      {layer.visible ? (
                        <Eye className="h-3.5 w-3.5 text-brand-300" />
                      ) : (
                        <EyeOff className="h-3.5 w-3.5 text-ink-faint" />
                      )}
                      <span className="flex-1 truncate">{layer.name}</span>
                      {layer.swatch && (
                        <span
                          className="h-2 w-2 shrink-0 rounded-sm"
                          style={{ backgroundColor: layer.swatch, opacity: layer.visible ? 1 : 0.3 }}
                        />
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="flex flex-col overflow-hidden rounded-lg border border-edge-strong/50 bg-black/60 backdrop-blur">
          <IconButton
            label="Zoom in"
            size="sm"
            onClick={() => setZoom(mapState.zoom * 1.35)}
            className="rounded-none hover:bg-white/10"
          >
            <Plus className="h-3.5 w-3.5" />
          </IconButton>
          <span className="h-px w-full bg-edge/60" aria-hidden />
          <IconButton
            label="Zoom out"
            size="sm"
            onClick={() => setZoom(mapState.zoom / 1.35)}
            className="rounded-none hover:bg-white/10"
          >
            <Minus className="h-3.5 w-3.5" />
          </IconButton>
        </div>

        <Tooltip label="Reset view" side="left">
          <IconButton
            label="Reset view"
            size="sm"
            onClick={() => dispatch({ type: 'set-map', patch: INITIAL_MAP_STATE })}
            className="border border-edge-strong/50 bg-black/60 backdrop-blur hover:bg-black/75"
          >
            <RotateCcw className="h-3.5 w-3.5" />
          </IconButton>
        </Tooltip>

        {onToggleFullscreen && (
          <Tooltip label={fullscreen ? 'Exit fullscreen' : 'Fullscreen'} side="left">
            <IconButton
              label={fullscreen ? 'Exit fullscreen' : 'Fullscreen'}
              size="sm"
              onClick={onToggleFullscreen}
              className="border border-edge-strong/50 bg-black/60 backdrop-blur hover:bg-black/75"
            >
              {fullscreen ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
            </IconButton>
          </Tooltip>
        )}
      </div>

      {/* Scale bar */}
      <div className="pointer-events-none absolute bottom-3 left-3 flex items-center gap-2">
        <div className="flex flex-col gap-1">
          <span className="font-mono text-[10px] text-ink-dim">{scaleLabel}</span>
          <span className="relative block h-1.5 w-16 border-x border-b border-ink-dim/50" />
        </div>
      </div>

      {/* Demo watermark */}
      <span className="pointer-events-none absolute bottom-3 right-3 rounded border border-white/[0.07] bg-black/45 px-1.5 py-0.5 font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-faint backdrop-blur">
        Demo visualization
      </span>

      {/* Drag hint, fades once the user interacts */}
      <span className="pointer-events-none absolute inset-x-0 bottom-9 mx-auto w-fit rounded-full border border-edge-strong/40 bg-black/55 px-2.5 py-1 text-[10.5px] text-ink-faint opacity-0 backdrop-blur transition-opacity duration-300 group-hover:opacity-100">
        Drag to pan · scroll to zoom
      </span>
    </div>
  );
}
