import { ArrowRight, Lightbulb } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import type { AnalysisResult } from '@/lib/types';

export function InsightsPanel({
  result,
  onOpenReport,
}: {
  result: AnalysisResult;
  onOpenReport: () => void;
}) {
  return (
    <section
      aria-label="Insights"
      className="rounded-2xl border border-edge/60 bg-panel/40 p-4 transition-colors duration-200 hover:border-edge-strong/60"
    >
      <div className="flex items-center gap-2.5">
        <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-500/[0.1] text-brand-300">
          <Lightbulb className="h-3.5 w-3.5" strokeWidth={1.8} />
        </span>
        <h3 className="text-[13px] font-semibold text-ink">Insights</h3>
        <Badge tone="neutral" className="font-mono uppercase tracking-wider">
          Demo
        </Badge>
      </div>

      <p className="mt-3 text-[13px] leading-relaxed text-ink-soft text-pretty">{result.insight}</p>

      {result.insightBullets.length > 0 && (
        <ul className="mt-3 space-y-2">
          {result.insightBullets.map((bullet) => (
            <li key={bullet} className="flex gap-2.5 text-[12.5px] leading-relaxed text-ink-mute">
              <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-brand-400/70" aria-hidden />
              <span className="text-pretty">{bullet}</span>
            </li>
          ))}
        </ul>
      )}

      <button
        type="button"
        onClick={onOpenReport}
        className="group mt-4 inline-flex items-center gap-1.5 rounded-lg text-[12.5px] font-medium text-brand-300 transition-colors duration-200 hover:text-brand-200"
      >
        View Full Report
        <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 ease-premium group-hover:translate-x-0.5" />
      </button>
    </section>
  );
}
