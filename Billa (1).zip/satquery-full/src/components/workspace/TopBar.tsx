import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bell, ChevronDown, CircleHelp, Home, LogOut, Menu, Settings as SettingsIcon } from 'lucide-react';
import { Badge, StatusDot } from '@/components/ui/Badge';
import { IconButton } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { Tooltip } from '@/components/ui/Tooltip';
import { DEMO_USER } from '@/lib/demoData';
import { DEMO_DISCLAIMER } from '@/lib/demoAgent';
import type { WorkspaceView } from '@/lib/types';
import { cn } from '@/lib/utils';
import { useWorkspace } from '@/state/WorkspaceContext';
import { latestMessage } from '@/lib/liveSteps';

const TITLES: Record<WorkspaceView, string> = {
  workspace: 'Workspace',
  history: 'History',
  saved: 'Saved Results',
  datasets: 'Datasets',
  aoi: 'Areas of Interest',
  alerts: 'Alerts',
  settings: 'Settings',
};

const WORKSPACE_SUBTITLE = 'Your geospatial agent is ready.';

function plural(count: number, one: string, many = `${one}s`): string {
  return `${count} ${count === 1 ? one : many}`;
}

export function TopBar({ onOpenMobileNav }: { onOpenMobileNav: () => void }) {
  const { state, goToView } = useWorkspace();
  const [menuOpen, setMenuOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const unread = state.alerts.filter((a) => a.unread).length;

  useEffect(() => {
    if (!menuOpen) return undefined;
    const onDown = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [menuOpen]);

  const COUNTS: Record<Exclude<WorkspaceView, 'workspace'>, string> = {
    history: plural(state.history.length, 'conversation'),
    saved: plural(state.savedResults.length, 'saved analysis', 'saved analyses'),
    datasets: '6 reference sources',
    aoi: plural(state.aois.length, 'area'),
    alerts: unread > 0 ? `${unread} unread` : plural(state.alerts.length, 'alert'),
    settings: 'Session preferences',
  };

  // While a live run is in flight the status line is the backend's own most
  // recent message — never a hardcoded loading string.
  const liveMessage =
    state.backend.mode === 'live' && state.backend.events.length > 0
      ? latestMessage(state.backend.events)
      : null;

  const status =
    state.view !== 'workspace'
      ? COUNTS[state.view]
      : liveMessage && (state.agentStatus === 'thinking' || state.agentStatus === 'working')
        ? liveMessage
        : state.agentStatus === 'thinking'
          ? 'Interpreting your question…'
          : state.agentStatus === 'working'
            ? 'Running the analysis…'
            : state.agentStatus === 'complete'
              ? 'Analysis complete — ask a follow-up any time.'
              : state.agentStatus === 'error'
                ? 'Something went wrong. Try again.'
                : state.backend.mode === 'live'
                  ? 'Connected to the SatQuery agent backend.'
                  : state.backend.mode === 'demo'
                    ? 'Local demo engine — no backend connected.'
                    : WORKSPACE_SUBTITLE;

  const statusTone =
    state.agentStatus === 'working' || state.agentStatus === 'thinking'
      ? 'amber'
      : state.agentStatus === 'error'
        ? 'red'
        : 'brand';

  return (
    <>
      <header className="flex h-[68px] shrink-0 items-center gap-3 border-b border-edge/60 bg-panel/30 px-4 backdrop-blur-xl sm:px-5">
        <IconButton label="Open navigation" className="lg:hidden" onClick={onOpenMobileNav}>
          <Menu className="h-5 w-5" />
        </IconButton>

        <div className="min-w-0 flex-1">
          <h1 className="flex items-center gap-2 text-[15px] font-semibold tracking-[-0.01em] text-ink">
            <span className="truncate">{TITLES[state.view]}</span>
            {state.view === 'workspace' && (
              <StatusDot tone={statusTone} pulse={state.agentStatus !== 'idle'} />
            )}
          </h1>
          <p className="mt-0.5 truncate text-[12.5px] text-ink-dim">{status}</p>
        </div>

        <div className="flex shrink-0 items-center gap-1">
          <Tooltip label="Help">
            <IconButton label="Help" onClick={() => setHelpOpen(true)}>
              <CircleHelp className="h-[18px] w-[18px]" strokeWidth={1.7} />
            </IconButton>
          </Tooltip>

          <Tooltip label={unread > 0 ? `${unread} unread alerts` : 'Alerts'}>
            <IconButton label="Notifications" onClick={() => goToView('alerts')} className="relative">
              <Bell className="h-[18px] w-[18px]" strokeWidth={1.7} />
              {unread > 0 && (
                <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-brand-400 ring-2 ring-[#0A141C]" />
              )}
            </IconButton>
          </Tooltip>

          <div className="relative ml-1" ref={menuRef}>
            <button
              type="button"
              onClick={() => setMenuOpen((v) => !v)}
              aria-haspopup="menu"
              aria-expanded={menuOpen}
              className="flex items-center gap-2 rounded-xl border border-edge/60 py-1 pl-1 pr-2 transition-colors duration-200 hover:border-edge-strong/70 hover:bg-white/[0.03]"
            >
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-sheen text-[12px] font-bold text-[#04120C]">
                {DEMO_USER.initials}
              </span>
              <span className="hidden text-[13px] text-ink-soft sm:block">{DEMO_USER.name}</span>
              <ChevronDown
                className={cn(
                  'h-3.5 w-3.5 text-ink-dim transition-transform duration-200',
                  menuOpen && 'rotate-180',
                )}
              />
            </button>

            {menuOpen && (
              <div
                role="menu"
                className="absolute right-0 top-[calc(100%+8px)] z-50 w-60 overflow-hidden rounded-xl border border-edge-strong/60 bg-[#0A1720]/97 shadow-lift backdrop-blur-xl animate-scale-in"
              >
                <div className="border-b border-edge/60 px-4 py-3">
                  <p className="text-[13px] font-medium text-ink">{DEMO_USER.name}</p>
                  <p className="mt-0.5 text-[11.5px] text-ink-dim">{DEMO_USER.email}</p>
                  <Badge tone="neutral" className="mt-2">
                    Demo account
                  </Badge>
                </div>
                <div className="p-1.5">
                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      goToView('settings');
                      setMenuOpen(false);
                    }}
                    className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] text-ink-soft transition-colors hover:bg-white/[0.05] hover:text-ink"
                  >
                    <SettingsIcon className="h-4 w-4 text-ink-dim" strokeWidth={1.7} />
                    Settings
                  </button>
                  <Link
                    to="/"
                    role="menuitem"
                    className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] text-ink-soft transition-colors hover:bg-white/[0.05] hover:text-ink"
                  >
                    <Home className="h-4 w-4 text-ink-dim" strokeWidth={1.7} />
                    Back to landing page
                  </Link>
                  <Link
                    to="/"
                    role="menuitem"
                    className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13px] text-ink-mute transition-colors hover:bg-white/[0.05] hover:text-ink"
                  >
                    <LogOut className="h-4 w-4 text-ink-dim" strokeWidth={1.7} />
                    Sign out
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      <Modal
        open={helpOpen}
        onClose={() => setHelpOpen(false)}
        title="About this build"
        description="What works, and what is illustrative."
      >
        <div className="space-y-4 text-[13.5px] leading-relaxed text-ink-mute">
          <p>
            SatQuery AI is a frontend prototype. The whole experience — the agent, the plan, the
            map, the datasets, the alerts — runs locally in your browser.
          </p>
          <div className="rounded-xl border border-edge/70 bg-black/25 p-4">
            <p className="text-[12.5px] text-ink-dim">{DEMO_DISCLAIMER}</p>
          </div>
          <div>
            <p className="mb-2 font-medium text-ink-soft">Things worth trying</p>
            <ul className="space-y-1.5 text-[13px]">
              <li>· Ask one of the four example questions from the empty state.</li>
              <li>· Follow up with “show only the areas with high expansion”.</li>
              <li>· Follow up with “zoom into the eastern region” or “compare this with 2019”.</li>
              <li>· Toggle layers in the result panel and watch the map respond.</li>
              <li>· Draw an area on the map, or attach a KML/GeoJSON file.</li>
            </ul>
          </div>
          <div>
            <p className="mb-2 font-medium text-ink-soft">Keyboard</p>
            <ul className="space-y-1.5 text-[13px]">
              <li>
                · <kbd className="rounded border border-edge px-1.5 py-0.5 font-mono text-[11px]">Enter</kbd>{' '}
                sends, <kbd className="rounded border border-edge px-1.5 py-0.5 font-mono text-[11px]">Shift</kbd>{' '}
                +{' '}
                <kbd className="rounded border border-edge px-1.5 py-0.5 font-mono text-[11px]">Enter</kbd>{' '}
                adds a line.
              </li>
              <li>
                · <kbd className="rounded border border-edge px-1.5 py-0.5 font-mono text-[11px]">Esc</kbd>{' '}
                closes dialogs and leaves draw mode.
              </li>
            </ul>
          </div>
        </div>
      </Modal>
    </>
  );
}
