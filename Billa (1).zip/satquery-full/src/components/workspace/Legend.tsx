import type { LegendEntry } from '@/lib/types';

export function Legend({ entries }: { entries: LegendEntry[] }) {
  return (
    <ul className="flex flex-wrap items-center gap-x-3.5 gap-y-2" aria-label="Map legend">
      {entries.map((entry) => (
        <li key={entry.label} className="flex items-center gap-1.5">
          <span
            className="h-2.5 w-2.5 shrink-0 rounded-[3px]"
            style={{ backgroundColor: entry.color, boxShadow: `0 0 10px -2px ${entry.color}` }}
            aria-hidden
          />
          <span className="whitespace-nowrap text-[11px] text-ink-mute">{entry.label}</span>
        </li>
      ))}
    </ul>
  );
}
