import { useEffect, useRef, useState } from 'react';
import { Eye, EyeOff, MoreVertical } from 'lucide-react';
import type { MapLayer } from '@/lib/types';
import { cn } from '@/lib/utils';

export function LayerControl({
  layers,
  onToggle,
  onIsolate,
  onShowAll,
}: {
  layers: MapLayer[];
  onToggle: (id: string) => void;
  onIsolate: (id: string) => void;
  onShowAll: () => void;
}) {
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!openMenu) return undefined;
    const onDown = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setOpenMenu(null);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpenMenu(null);
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [openMenu]);

  return (
    <section aria-label="Map layers" ref={wrapRef}>
      <h3 className="mb-2.5 text-[13px] font-semibold text-ink">Layers</h3>

      <ul className="space-y-1">
        {layers.map((layer) => (
          <li
            key={layer.id}
            className="group relative flex items-center gap-2.5 rounded-xl border border-edge/50 bg-panel/40 px-2.5 py-2 transition-colors duration-200 hover:border-edge-strong/60 hover:bg-panel-raised/50"
          >
            <button
              type="button"
              onClick={() => onToggle(layer.id)}
              aria-pressed={layer.visible}
              aria-label={`${layer.visible ? 'Hide' : 'Show'} ${layer.name}`}
              className={cn(
                'flex h-6 w-6 shrink-0 items-center justify-center rounded-md transition-colors duration-200',
                layer.visible
                  ? 'text-brand-300 hover:bg-brand-500/12'
                  : 'text-ink-faint hover:bg-white/[0.06]',
              )}
            >
              {layer.visible ? <Eye className="h-3.5 w-3.5" /> : <EyeOff className="h-3.5 w-3.5" />}
            </button>

            {layer.swatch && (
              <span
                className="h-2 w-2 shrink-0 rounded-sm transition-opacity duration-200"
                style={{ backgroundColor: layer.swatch, opacity: layer.visible ? 1 : 0.28 }}
                aria-hidden
              />
            )}

            <span
              className={cn(
                'flex-1 truncate text-[12.5px] transition-colors duration-200',
                layer.visible ? 'text-ink-soft' : 'text-ink-faint',
              )}
              title={layer.name}
            >
              {layer.name}
            </span>

            <button
              type="button"
              aria-label={`Options for ${layer.name}`}
              aria-expanded={openMenu === layer.id}
              onClick={() => setOpenMenu((v) => (v === layer.id ? null : layer.id))}
              className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md text-ink-faint opacity-0 transition-all duration-200 hover:bg-white/[0.06] hover:text-ink-mute focus-visible:opacity-100 group-hover:opacity-100"
            >
              <MoreVertical className="h-3.5 w-3.5" />
            </button>

            {openMenu === layer.id && (
              <div className="absolute right-2 top-[calc(100%-2px)] z-30 w-44 overflow-hidden rounded-xl border border-edge-strong/60 bg-[#0A1720]/97 p-1.5 shadow-lift backdrop-blur-xl animate-scale-in">
                <MenuItem
                  onClick={() => {
                    onToggle(layer.id);
                    setOpenMenu(null);
                  }}
                >
                  {layer.visible ? 'Hide layer' : 'Show layer'}
                </MenuItem>
                <MenuItem
                  onClick={() => {
                    onIsolate(layer.id);
                    setOpenMenu(null);
                  }}
                >
                  Isolate this layer
                </MenuItem>
                <MenuItem
                  onClick={() => {
                    onShowAll();
                    setOpenMenu(null);
                  }}
                >
                  Show all layers
                </MenuItem>
              </div>
            )}
          </li>
        ))}
      </ul>
    </section>
  );
}

function MenuItem({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="block w-full rounded-lg px-2.5 py-1.5 text-left text-[12.5px] text-ink-mute transition-colors hover:bg-white/[0.05] hover:text-ink"
    >
      {children}
    </button>
  );
}
