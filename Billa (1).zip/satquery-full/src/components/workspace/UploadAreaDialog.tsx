import { useEffect, useRef, useState } from 'react';
import { CheckCircle2, FileJson, Trash2, Upload } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import type { ChatAttachment } from '@/lib/types';
import { cn, formatBytes } from '@/lib/utils';

type Phase = 'idle' | 'reading' | 'ready' | 'rejected';

const ACCEPTED = ['.kml', '.geojson', '.json'];

/**
 * Local-only file selection. The file is read in the browser to show a size
 * and a first-line preview; it is never uploaded and never parsed as geometry.
 */
export function UploadAreaDialog({
  open,
  onClose,
  onAttach,
}: {
  open: boolean;
  onClose: () => void;
  onAttach: (attachment: ChatAttachment) => void;
}) {
  const [phase, setPhase] = useState<Phase>('idle');
  const [file, setFile] = useState<File | null>(null);
  const [progress, setProgress] = useState(0);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const timers = useRef<number[]>([]);

  useEffect(() => {
    if (open) return;
    setPhase('idle');
    setFile(null);
    setProgress(0);
    timers.current.forEach(window.clearTimeout);
    timers.current = [];
  }, [open]);

  useEffect(
    () => () => {
      timers.current.forEach(window.clearTimeout);
    },
    [],
  );

  const accept = (picked: File | undefined) => {
    if (!picked) return;
    const ok = ACCEPTED.some((ext) => picked.name.toLowerCase().endsWith(ext));
    setFile(picked);
    if (!ok) {
      setPhase('rejected');
      return;
    }
    setPhase('reading');
    setProgress(0);
    // Local read only — a short staged progress so the state is legible.
    [180, 360, 560, 760].forEach((delay, i) => {
      timers.current.push(
        window.setTimeout(() => {
          setProgress((i + 1) * 25);
          if (i === 3) setPhase('ready');
        }, delay),
      );
    });
  };

  const format: ChatAttachment['format'] = file?.name.toLowerCase().endsWith('.kml')
    ? 'KML'
    : 'GeoJSON';

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Upload area"
      description="Attach a KML or GeoJSON boundary to your next question."
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="primary"
            disabled={phase !== 'ready' || !file}
            onClick={() => {
              if (!file) return;
              onAttach({ name: file.name, size: file.size, format });
              onClose();
            }}
          >
            Attach area
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED.join(',')}
          className="sr-only"
          onChange={(e) => accept(e.target.files?.[0])}
        />

        {!file && (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              accept(e.dataTransfer.files?.[0]);
            }}
            className={cn(
              'flex flex-col items-center justify-center rounded-2xl border border-dashed px-6 py-12 text-center transition-all duration-200',
              dragging
                ? 'border-brand-500/50 bg-brand-500/[0.06]'
                : 'border-edge-strong/50 bg-panel/30',
            )}
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl border border-edge-strong/60 bg-panel-high/60 text-brand-300">
              <Upload className="h-5 w-5" strokeWidth={1.7} />
            </span>
            <p className="mt-4 text-[13.5px] font-medium text-ink">Drop a boundary file here</p>
            <p className="mt-1.5 text-[12.5px] text-ink-mute">KML or GeoJSON, up to a few MB.</p>
            <Button variant="secondary" size="sm" className="mt-5" onClick={() => inputRef.current?.click()}>
              Choose a file
            </Button>
          </div>
        )}

        {file && (
          <div className="rounded-2xl border border-edge/70 bg-panel/40 p-4">
            <div className="flex items-start gap-3">
              <span
                className={cn(
                  'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border',
                  phase === 'rejected'
                    ? 'border-amber-400/25 bg-amber-400/10 text-amber-300'
                    : 'border-edge-strong/60 bg-panel-high/60 text-brand-300',
                )}
              >
                <FileJson className="h-4.5 w-4.5" strokeWidth={1.7} />
              </span>

              <div className="min-w-0 flex-1">
                <p className="truncate text-[13px] font-medium text-ink">{file.name}</p>
                <p className="mt-0.5 text-[11.5px] text-ink-dim">
                  {formatBytes(file.size)}
                  {phase !== 'rejected' && ` · ${format}`}
                </p>

                {phase === 'reading' && (
                  <div className="mt-3">
                    <div className="h-1 w-full overflow-hidden rounded-full bg-black/40">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-brand-500 to-aqua-400 transition-[width] duration-200 ease-premium"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                    <p className="mt-1.5 text-[11.5px] text-ink-dim">Reading file locally…</p>
                  </div>
                )}

                {phase === 'ready' && (
                  <p className="mt-2.5 inline-flex items-center gap-1.5 text-[12px] text-brand-300">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Ready to attach
                  </p>
                )}

                {phase === 'rejected' && (
                  <p className="mt-2.5 text-[12px] text-amber-300">
                    That file type isn&apos;t accepted here. Choose a .kml or .geojson file.
                  </p>
                )}
              </div>

              <button
                type="button"
                onClick={() => {
                  setFile(null);
                  setPhase('idle');
                  setProgress(0);
                  if (inputRef.current) inputRef.current.value = '';
                }}
                aria-label="Remove file"
                className="rounded-lg p-1.5 text-ink-dim transition-colors hover:bg-white/[0.06] hover:text-ink"
              >
                <Trash2 className="h-4 w-4" strokeWidth={1.7} />
              </button>
            </div>
          </div>
        )}

        <div className="flex items-start gap-2.5 rounded-xl border border-edge/60 bg-black/25 px-3.5 py-3">
          <Badge tone="neutral" className="shrink-0">
            Local only
          </Badge>
          <p className="text-[11.5px] leading-relaxed text-ink-dim">
            The file stays on your machine. This build has no server, so nothing is uploaded and the
            geometry is not parsed — the attachment is used as conversational context only.
          </p>
        </div>
      </div>
    </Modal>
  );
}
