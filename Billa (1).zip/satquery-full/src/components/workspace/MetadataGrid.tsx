import { Info } from 'lucide-react';
import { Tooltip } from '@/components/ui/Tooltip';
import { DEMO_DISCLAIMER_SHORT } from '@/lib/demoAgent';
import type { MetadataEntry } from '@/lib/types';

export function MetadataGrid({ entries }: { entries: MetadataEntry[] }) {
  return (
    <section aria-label="Analysis parameters">
      <div className="mb-2 flex items-center gap-1.5">
        <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-dim">
          Demo analysis
        </span>
        <Tooltip label={DEMO_DISCLAIMER_SHORT} side="top">
          <span className="text-ink-faint">
            <Info className="h-3 w-3" />
          </span>
        </Tooltip>
      </div>

      <dl className="grid grid-cols-2 gap-2 min-[1700px]:grid-cols-4">
        {entries.map((entry) => (
          <div
            key={entry.label}
            className="rounded-xl border border-edge/60 bg-panel/40 px-3 py-2.5 transition-colors duration-200 hover:border-edge-strong/60"
          >
            <dt className="text-[10.5px] leading-tight text-ink-faint">{entry.label}</dt>
            <dd className="mt-1 text-[12.5px] font-medium leading-snug text-ink-soft">
              {entry.value}
            </dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
