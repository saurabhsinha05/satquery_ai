import { Link } from 'react-router-dom';
import {
  Bell,
  ChevronRight,
  Clock,
  Database,
  LayoutGrid,
  Lightbulb,
  MapPin,
  Bookmark,
  Plus,
  Settings as SettingsIcon,
  X,
} from 'lucide-react';
import { Logo } from '@/components/brand/Logo';
import { Badge } from '@/components/ui/Badge';
import { IconButton } from '@/components/ui/Button';
import { useWorkspace } from '@/state/WorkspaceContext';
import type { WorkspaceView } from '@/lib/types';
import { cn } from '@/lib/utils';

const NAV: Array<{ view: WorkspaceView; label: string; icon: typeof LayoutGrid }> = [
  { view: 'workspace', label: 'Workspace', icon: LayoutGrid },
  { view: 'history', label: 'History', icon: Clock },
  { view: 'saved', label: 'Saved Results', icon: Bookmark },
  { view: 'datasets', label: 'Datasets', icon: Database },
  { view: 'aoi', label: 'Areas of Interest', icon: MapPin },
  { view: 'alerts', label: 'Alerts', icon: Bell },
  { view: 'settings', label: 'Settings', icon: SettingsIcon },
];

export function Sidebar({
  mobileOpen,
  onCloseMobile,
}: {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}) {
  const { state, dispatch, goToView, resetWorkspace } = useWorkspace();
  const unread = state.alerts.filter((a) => a.unread).length;

  const handleNav = (view: WorkspaceView) => {
    goToView(view);
    onCloseMobile();
  };

  const content = (
    <div className="flex h-full flex-col gap-4 p-4">
      <div className="flex items-center justify-between lg:hidden">
        <Link to="/" aria-label="SatQuery AI home">
          <Logo size="sm" />
        </Link>
        <IconButton label="Close navigation" onClick={onCloseMobile}>
          <X className="h-4 w-4" />
        </IconButton>
      </div>

      <button
        type="button"
        onClick={() => {
          resetWorkspace();
          onCloseMobile();
        }}
        className={cn(
          'group flex w-full items-center gap-2.5 rounded-xl border border-brand-500/25 bg-brand-500/[0.07]',
          'px-3.5 py-3 text-[13.5px] font-medium text-brand-200',
          'transition-all duration-200 ease-premium hover:border-brand-500/45 hover:bg-brand-500/[0.12]',
        )}
      >
        <span className="flex h-5 w-5 items-center justify-center rounded-full border border-brand-400/40 text-brand-300 transition-transform duration-200 ease-premium group-hover:rotate-90">
          <Plus className="h-3 w-3" strokeWidth={2.6} />
        </span>
        New Query
      </button>

      <nav aria-label="Workspace sections">
        <ul className="space-y-1">
          {NAV.map(({ view, label, icon: Icon }) => {
            const active = state.view === view;
            return (
              <li key={view}>
                <button
                  type="button"
                  onClick={() => handleNav(view)}
                  aria-current={active ? 'page' : undefined}
                  className={cn(
                    'group relative flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-[13.5px]',
                    'transition-all duration-200 ease-premium',
                    active
                      ? 'bg-white/[0.055] font-medium text-ink'
                      : 'text-ink-mute hover:bg-white/[0.03] hover:text-ink-soft',
                  )}
                >
                  {active && (
                    <span
                      className="absolute left-0 top-1/2 h-5 w-[2.5px] -translate-y-1/2 rounded-r-full bg-brand-400"
                      aria-hidden
                    />
                  )}
                  <Icon
                    className={cn(
                      'h-[17px] w-[17px] shrink-0 transition-colors',
                      active ? 'text-brand-300' : 'text-ink-dim group-hover:text-ink-mute',
                    )}
                    strokeWidth={1.7}
                  />
                  <span className="truncate">{label}</span>
                  {view === 'alerts' && unread > 0 && (
                    <Badge tone="brand" className="ml-auto shrink-0">
                      New
                    </Badge>
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="mt-auto">
        <button
          type="button"
          onClick={() => {
            dispatch({ type: 'set-examples', on: true });
            onCloseMobile();
          }}
          className="group flex w-full items-center gap-3 rounded-xl border border-edge/70 bg-panel-raised/50 px-3.5 py-3 text-left transition-all duration-200 ease-premium hover:border-brand-500/25 hover:bg-panel-high/60"
        >
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-500/[0.1] text-brand-300">
            <Lightbulb className="h-4 w-4" strokeWidth={1.7} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[12.5px] font-medium text-ink-soft">Need inspiration?</span>
            <span className="mt-0.5 flex items-center gap-1 text-[12px] text-brand-300">
              View Examples
              <ChevronRight className="h-3 w-3 transition-transform duration-200 ease-premium group-hover:translate-x-0.5" />
            </span>
          </span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop rail */}
      <aside className="hidden w-[236px] shrink-0 border-r border-edge/60 bg-panel/40 lg:block">
        {content}
      </aside>

      {/* Mobile drawer */}
      <div
        className={cn(
          'fixed inset-0 z-50 lg:hidden',
          mobileOpen ? 'pointer-events-auto' : 'pointer-events-none',
        )}
        aria-hidden={!mobileOpen}
      >
        <button
          type="button"
          tabIndex={mobileOpen ? 0 : -1}
          aria-label="Close navigation"
          onClick={onCloseMobile}
          className={cn(
            'absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity duration-300',
            mobileOpen ? 'opacity-100' : 'opacity-0',
          )}
        />
        <aside
          className={cn(
            'absolute inset-y-0 left-0 w-[276px] max-w-[84vw] border-r border-edge/70 bg-[#07121A]/97',
            'shadow-lift backdrop-blur-2xl transition-transform duration-300 ease-premium',
            mobileOpen ? 'translate-x-0' : '-translate-x-full',
          )}
        >
          {content}
        </aside>
      </div>
    </>
  );
}
