import { useNavigate } from 'react-router-dom';
import { Compass } from 'lucide-react';
import { Button } from '@/components/ui/Button';

export default function NotFoundPage() {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-full items-center justify-center bg-void px-6 py-24">
      <div className="w-full max-w-md text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-edge-strong/60 bg-panel-high/60 text-brand-300">
          <Compass className="h-6 w-6" strokeWidth={1.6} />
        </span>
        <p className="mt-6 font-mono text-[12px] uppercase tracking-[0.2em] text-ink-dim">404</p>
        <h1 className="mt-3 text-2xl font-bold tracking-[-0.02em]">Off the map.</h1>
        <p className="mt-3 text-[14px] leading-relaxed text-ink-mute">
          That page isn&apos;t part of this build. The workspace is where everything happens.
        </p>
        <div className="mt-8 flex justify-center gap-2.5">
          <Button variant="primary" onClick={() => navigate('/workspace')}>
            Return to workspace
          </Button>
          <Button variant="secondary" onClick={() => navigate('/')}>
            Back home
          </Button>
        </div>
      </div>
    </div>
  );
}
