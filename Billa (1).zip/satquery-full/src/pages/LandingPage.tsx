import { useEffect } from 'react';
import { Features } from '@/components/landing/Features';
import { FinalCta } from '@/components/landing/FinalCta';
import { Footer } from '@/components/landing/Footer';
import { Hero } from '@/components/landing/Hero';
import { HowItWorks } from '@/components/landing/HowItWorks';
import { ResultShowcase } from '@/components/landing/ResultShowcase';
import { Navbar } from '@/components/landing/Navbar';
import { UseCases } from '@/components/landing/UseCases';

export default function LandingPage() {
  useEffect(() => {
    document.title = 'SatQuery AI — Ask Earth Anything';
  }, []);

  return (
    <div className="relative min-h-full overflow-x-hidden bg-void">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[80] focus:rounded-lg focus:bg-brand-500 focus:px-4 focus:py-2 focus:text-[13px] focus:font-semibold focus:text-[#04120C]"
      >
        Skip to content
      </a>

      <Navbar />

      {/* Headline → product demo → workflow → use cases → CTA */}
      <main id="main">
        <Hero />
        <HowItWorks />
        <ResultShowcase />
        <Features />
        <UseCases />
        <FinalCta />
      </main>

      <Footer />
    </div>
  );
}
