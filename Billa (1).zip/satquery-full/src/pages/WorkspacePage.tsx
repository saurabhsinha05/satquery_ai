import { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { MessageSquare, PanelRight } from 'lucide-react';
import { AlertsView } from '@/components/views/AlertsView';
import { AoiView } from '@/components/views/AoiView';
import { DatasetsView } from '@/components/views/DatasetsView';
import { HistoryView } from '@/components/views/HistoryView';
import { SavedResultsView } from '@/components/views/SavedResultsView';
import { SettingsView } from '@/components/views/SettingsView';
import { ChatInput } from '@/components/workspace/ChatInput';
import { ChatPanel } from '@/components/workspace/ChatPanel';
import { DrawAreaDialog } from '@/components/workspace/DrawAreaDialog';
import { ExamplesDialog } from '@/components/workspace/ExamplesDialog';
import { ReportDialog } from '@/components/workspace/ReportDialog';
import { ResultPanel } from '@/components/workspace/ResultPanel';
import { LiveResultPanel } from '@/components/workspace/LiveResultPanel';
import { Sidebar } from '@/components/workspace/Sidebar';
import { TopBar } from '@/components/workspace/TopBar';
import { UploadAreaDialog } from '@/components/workspace/UploadAreaDialog';
import { ToastHost } from '@/components/ui/Toast';
import { DEMO_QUERY } from '@/lib/demoAgent';
import { cn } from '@/lib/utils';
import { WorkspaceProvider, useWorkspace } from '@/state/WorkspaceContext';

export default function WorkspacePage() {
  useEffect(() => {
    document.title = 'Workspace — SatQuery AI';
  }, []);

  return (
    <WorkspaceProvider>
      <WorkspaceShell />
    </WorkspaceProvider>
  );
}

function WorkspaceShell() {
  const { state, dispatch, submitQuery, attachFile, confirmDrawnArea } = useWorkspace();
  const [searchParams, setSearchParams] = useSearchParams();
  const [navOpen, setNavOpen] = useState(false);
  const [drawOpen, setDrawOpen] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const demoFired = useRef(false);

  // Deep links from the landing page:
  //   ?demo=1        → run the flagship demo query
  //   ?q=<question>  → run the question a use-case card carried in
  useEffect(() => {
    if (demoFired.current) return;
    const deepLink = searchParams.get('q');
    const isDemo = searchParams.get('demo') === '1';
    if (!deepLink && !isDemo) return;

    demoFired.current = true;
    dispatch({ type: 'set-demo-mode', on: true });
    const query = deepLink?.slice(0, 400) || DEMO_QUERY;
    const timer = window.setTimeout(() => {
      submitQuery(query);
      setSearchParams({}, { replace: true });
    }, 650);
    return () => window.clearTimeout(timer);
  }, [dispatch, searchParams, setSearchParams, submitQuery]);

  // Escape leaves fullscreen.
  useEffect(() => {
    if (!state.fullscreen) return undefined;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') dispatch({ type: 'set-fullscreen', on: false });
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [dispatch, state.fullscreen]);

  const liveResponse = state.backend.response;
  const showResult =
    state.backend.mode === 'live'
      ? Boolean(liveResponse?.map || liveResponse?.analysis)
      : state.resultVisible && Boolean(state.result);

  /**
   * One panel, two sources. When a backend answered, its response is the only
   * thing rendered; the local demo panel is used only when no backend exists.
   */
  const renderPanel = (panelClass: string, onClose?: () => void) =>
    liveResponse ? (
      <LiveResultPanel response={liveResponse} className={panelClass} onClose={onClose} />
    ) : (
      <ResultPanel className={panelClass} onClose={onClose} />
    );
  const isWorkspace = state.view === 'workspace';

  return (
    <div className="flex h-full min-h-0 overflow-hidden bg-void">
      <Sidebar mobileOpen={navOpen} onCloseMobile={() => setNavOpen(false)} />

      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar onOpenMobileNav={() => setNavOpen(true)} />

        {isWorkspace ? (
          <div className="flex min-h-0 flex-1">
            {/* Chat column */}
            <div
              className={cn(
                'flex min-w-0 flex-1 flex-col',
                showResult && state.mobilePane === 'result' && 'hidden xl:flex',
              )}
            >
              {showResult && (
                <MobilePaneTabs
                  pane={state.mobilePane}
                  onChange={(pane) => dispatch({ type: 'set-mobile-pane', pane })}
                />
              )}
              <ChatPanel />
              <ChatInput
                onOpenExamples={() => dispatch({ type: 'set-examples', on: true })}
                onOpenDraw={() => setDrawOpen(true)}
                onOpenUpload={() => setUploadOpen(true)}
              />
            </div>

            {/* Result column */}
            {showResult && (
              <div
                className={cn(
                  'min-w-0 border-l border-edge/60 animate-slide-in-right',
                  'xl:flex xl:w-[392px] xl:shrink-0 2xl:w-[440px]',
                  state.mobilePane === 'result' ? 'flex flex-1' : 'hidden',
                )}
              >
                {state.mobilePane === 'result' && (
                  <div className="flex min-h-0 w-full flex-col xl:hidden">
                    <MobilePaneTabs
                      pane={state.mobilePane}
                      onChange={(pane) => dispatch({ type: 'set-mobile-pane', pane })}
                    />
                    {renderPanel('flex-1', () =>
                      dispatch({ type: 'set-mobile-pane', pane: 'chat' }),
                    )}
                  </div>
                )}
                {renderPanel('hidden w-full xl:flex')}
              </div>
            )}
          </div>
        ) : (
          <div className="flex min-h-0 flex-1 flex-col">
            {state.view === 'history' && <HistoryView />}
            {state.view === 'saved' && <SavedResultsView />}
            {state.view === 'datasets' && <DatasetsView />}
            {state.view === 'aoi' && <AoiView />}
            {state.view === 'alerts' && <AlertsView />}
            {state.view === 'settings' && <SettingsView />}
          </div>
        )}
      </div>

      {/* Fullscreen result */}
      {state.fullscreen && (state.result || liveResponse) && (
        <div className="fixed inset-0 z-[65] flex bg-void/95 backdrop-blur-xl animate-fade-in">
          <div className="mx-auto flex w-full max-w-[1100px] flex-col p-3 sm:p-6">
            {renderPanel(
              'min-h-0 flex-1 overflow-hidden rounded-2xl border border-edge/70 bg-panel/60',
              () => dispatch({ type: 'set-fullscreen', on: false }),
            )}
          </div>
        </div>
      )}

      <ExamplesDialog
        open={state.examplesOpen}
        onClose={() => dispatch({ type: 'set-examples', on: false })}
        onPick={submitQuery}
      />
      <DrawAreaDialog
        open={drawOpen}
        onClose={() => setDrawOpen(false)}
        onConfirm={confirmDrawnArea}
        seed={state.result?.seed ?? 'urban-ranchi'}
      />
      <UploadAreaDialog
        open={uploadOpen}
        onClose={() => setUploadOpen(false)}
        onAttach={attachFile}
      />
      <ReportDialog
        open={state.reportOpen}
        onClose={() => dispatch({ type: 'set-report', on: false })}
        result={state.result}
      />

      <ToastHost toast={state.toast} />
    </div>
  );
}

function MobilePaneTabs({
  pane,
  onChange,
}: {
  pane: 'chat' | 'result';
  onChange: (pane: 'chat' | 'result') => void;
}) {
  return (
    <div
      className="flex shrink-0 items-center gap-1 border-b border-edge/60 px-3 py-2 xl:hidden"
      role="tablist"
      aria-label="Workspace panes"
    >
      {(
        [
          { id: 'chat' as const, label: 'Chat', icon: MessageSquare },
          { id: 'result' as const, label: 'Result', icon: PanelRight },
        ]
      ).map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          type="button"
          role="tab"
          aria-selected={pane === id}
          onClick={() => onChange(id)}
          className={cn(
            'inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-[12.5px] transition-colors duration-200',
            pane === id
              ? 'bg-white/[0.06] font-medium text-ink'
              : 'text-ink-mute hover:bg-white/[0.03] hover:text-ink-soft',
          )}
        >
          <Icon className="h-3.5 w-3.5" />
          {label}
        </button>
      ))}
    </div>
  );
}
